package topcreator.qrcode.barcode.scanner.reader.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ScanDataDao {
    @Query("SELECT * from scan_data_bookmark where scannedCode LIKE :str")
    List<ScanDataEntity> checkBookMark(String str);

    @Query("SELECT * from card_bookmark_data where cardId LIKE :i")
    List<CardDataEntity> checkCardBookMark(int i);

    @Query("SELECT * from card_bookmark_data where cardId LIKE :str")
    List<CardBookmarkDataEntity> checkCardBookMark(String str);

    @Query("SELECT * from generate_bookmark_data where scannedCode LIKE :str")
    List<GenerateBookmarkDataEntity> checkGenBookMark(String str);

    @Query("SELECT * FROM scan_data where scannedCode LIKE :str")
    List<ScanDataEntity> checkItem(String str);

    @Query("DELETE FROM scan_data")
    void deleteAll();

    @Query("DELETE FROM scan_data_bookmark")
    void deleteAllBookmark();

    @Query("DELETE FROM generate_bookmark_data")
    void deleteAllBookmarkGenerate();

    @Query("DELETE FROM card_data")
    void deleteAllCard();

    @Query("DELETE FROM generate_data")
    void deleteAllGenerate();

    @Query("DELETE FROM card_bookmark_data WHERE bookmarkCardId LIKE :str")
    void deleteCardItemBookmark(String str);

    @Query("DELETE FROM generate_bookmark_data WHERE scannedCode LIKE :str")
    void deleteGenItemBookmark(String str);

    @Query("DELETE FROM scan_data_bookmark WHERE scannedCode LIKE :str")
    void deleteItemBookmark(String str);

    @Query("SELECT * from scan_data_bookmark group by date")
    List<ScanDataEntity> getAllBookmarkNonDuplicate();

    @Query("SELECT * from card_bookmark_data group by sqlDate")
    List<CardBookmarkDataEntity> getAllCardBookmarkNonDuplicate();

    @Query("SELECT * from card_data where cardType LIKE :str group by sqlDate")
    List<CardDataEntity> getAllCardFilterNonDuplicate(String str);

    @Query("SELECT * from scan_data_bookmark where scannedType LIKE :str group by date")
    List<ScanDataEntity> getAllFilterBookmarkNonDuplicate(String str);

    @Query("SELECT * from card_bookmark_data where cardType LIKE :str group by sqlDate")
    List<CardBookmarkDataEntity> getAllFilterCardBookmarkNonDuplicate(String str);

    @Query("SELECT * from generate_bookmark_data where scannedType LIKE :str group by sqlDate")
    List<GenerateDataEntity> getAllFilterGenBookmarkNonDuplicate(String str);

    @Query("SELECT * from scan_data where scannedType LIKE :str group by date")
    List<ScanDataEntity> getAllFilterNonDuplicate(String str);

    @Query("SELECT * from generate_bookmark_data group by sqlDate")
    List<GenerateBookmarkDataEntity> getAllGenBookmarkNonDuplicate();

    @Query("SELECT * from generate_data")
    List<GenerateDataEntity> getAllGenerateData();

    @Query("SELECT * from generate_data where scannedType LIKE :str group by sqlDate")
    List<GenerateDataEntity> getAllGenerateFilterNonDuplicate(String str);

    @Query("SELECT * from scan_data group by date")
    List<ScanDataEntity> getAllNonDuplicate();

    @Query("SELECT * from scan_data")
    List<ScanDataEntity> getAllWords();

    @Query("SELECT * from scan_data_bookmark")
    List<ScanDataEntity> getBookmarkData();

    @Query("SELECT * FROM scan_data WHERE sqlDate >= date('now','start of month','-1 month')AND sqlDate < date('now','start of month')")
    List<ScanDataEntity> getByMonth();

    @Query("SELECT * from card_data group by sqlDate")
    List<CardDataEntity> getCardAllNonDuplicate();

    @Query("SELECT * from card_bookmark_data where sqlDate = date('now') AND cardType LIKE :str")
    List<CardBookmarkDataEntity> getCardBookmarkDayFilterData(String str);

    @Query("SELECT * from card_bookmark_data where strftime('%m',sqlDate) LIKE :str AND strftime('%Y',sqlDate) LIKE :str2 AND cardType LIKE :str3")
    List<CardBookmarkDataEntity> getCardBookmarkGenericFilerDataList(String str, String str2, String str3);

    @Query("SELECT * FROM card_bookmark_data WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day') AND cardType LIKE :str")
    List<CardBookmarkDataEntity> getCardBookmarkMonthFilterData(String str);

    @Query("SELECT * FROM card_bookmark_data WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')  AND cardType LIKE :str")
    List<CardBookmarkDataEntity> getCardBookmarkWeekData(String str);

    @Query("SELECT * from card_bookmark_data where sqlDate = date('now','-1 day') AND cardType LIKE :str")
    List<CardBookmarkDataEntity> getCardBookmarkYesterdayFilterDataList(String str);

    @Query("SELECT * from card_data where sqlDate = date('now') ")
    List<CardDataEntity> getCardDayData();

    @Query("SELECT * from card_data where sqlDate = date('now') AND cardType LIKE :str")
    List<CardDataEntity> getCardDayFilterData(String str);

    @Query("SELECT * from card_bookmark_data where strftime('%m',sqlDate) LIKE :str AND strftime('%Y',sqlDate) LIKE :str2")
    List<CardBookmarkDataEntity> getCardGenBookmarkDataList(String str, String str2);

    @Query("SELECT * from card_data where strftime('%m',sqlDate) LIKE :str AND strftime('%Y',sqlDate) LIKE :str2")
    List<CardDataEntity> getCardGenericDataList(String str, String str2);

    @Query("SELECT * from card_data where strftime('%m',sqlDate) LIKE :str AND strftime('%Y',sqlDate) LIKE :str2 AND cardType LIKE :str3")
    List<CardDataEntity> getCardGenericFilerDataList(String str, String str2, String str3);

    @Query("SELECT * FROM card_data WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<CardDataEntity> getCardMonthData();

    @Query("SELECT * FROM card_data WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day') AND cardType LIKE :str")
    List<CardDataEntity> getCardMonthFilterData(String str);

    @Query("SELECT * FROM card_data WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<CardDataEntity> getCardWeekData();

    @Query("SELECT * FROM card_data WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')  AND cardType LIKE :str")
    List<CardDataEntity> getCardWeekData(String str);

    @Query("SELECT * from card_data where sqlDate = date('now','-1 day')")
    List<CardDataEntity> getCardYesterdayDataList();

    @Query("SELECT * from card_data where sqlDate = date('now','-1 day') AND cardType LIKE :str")
    List<CardDataEntity> getCardYesterdayFilterDataList(String str);

    @Query("SELECT * from scan_data_bookmark where sqlDate = date('now') AND scannedType LIKE :str")
    List<ScanDataEntity> getDayBookmarkFilterData(String str);

    @Query("SELECT * from scan_data where sqlDate = date('now') ")
    List<ScanDataEntity> getDayData();

    @Query("SELECT * from scan_data_bookmark where sqlDate = date('now');")
    List<ScanDataEntity> getDayDataBookmark();

    @Query("SELECT * from card_bookmark_data where sqlDate = date('now');")
    List<CardBookmarkDataEntity> getDayDataCardBookmark();

    @Query("SELECT * from generate_bookmark_data where sqlDate = date('now');")
    List<GenerateDataEntity> getDayDataGenBookmark();

    @Query("SELECT * from scan_data where sqlDate = date('now') AND scannedType LIKE :str")
    List<ScanDataEntity> getDayFilterData(String str);

    @Query("SELECT * from generate_data group by sqlDate")
    List<GenerateDataEntity> getGenerateAllNonDuplicate();

    @Query("SELECT * from generate_bookmark_data where sqlDate = date('now') AND scannedType LIKE :str")
    List<GenerateDataEntity> getGenerateBookmarkDayFilterData(String str);

    @Query("SELECT * from generate_bookmark_data where strftime('%m',sqlDate) LIKE :str AND strftime('%Y',sqlDate) LIKE :str2 AND scannedType LIKE :str3")
    List<GenerateDataEntity> getGenerateBookmarkGenericFilerDataList(String str, String str2, String str3);

    @Query("SELECT * FROM generate_bookmark_data WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day') AND scannedType LIKE :str")
    List<GenerateDataEntity> getGenerateBookmarkMonthFilterData(String str);

    @Query("SELECT * FROM generate_bookmark_data WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')  AND scannedType LIKE :str")
    List<GenerateDataEntity> getGenerateBookmarkWeekData(String str);

    @Query("SELECT * from generate_bookmark_data where sqlDate = date('now','-1 day') AND scannedType LIKE :str")
    List<GenerateDataEntity> getGenerateBookmarkYesterdayFilterDataList(String str);

    @Query("SELECT * from generate_data where sqlDate = date('now') ")
    List<GenerateDataEntity> getGenerateDayData();

    @Query("SELECT * from generate_data where sqlDate = date('now') AND scannedType LIKE :str")
    List<GenerateDataEntity> getGenerateDayFilterData(String str);

    @Query("SELECT * from generate_data where strftime('%m',sqlDate) LIKE :str AND strftime('%Y',sqlDate) LIKE :str2")
    List<GenerateDataEntity> getGenerateGenericDataList(String str, String str2);

    @Query("SELECT * from generate_data where strftime('%m',sqlDate) LIKE :str AND strftime('%Y',sqlDate) LIKE :str2 AND scannedType LIKE :str3")
    List<GenerateDataEntity> getGenerateGenericFilerDataList(String str, String str2, String str3);

    @Query("SELECT * FROM generate_data WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<GenerateDataEntity> getGenerateMonthData();

    @Query("SELECT * FROM generate_data WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day') AND scannedType LIKE :str")
    List<GenerateDataEntity> getGenerateMonthFilterData(String str);

    @Query("SELECT * FROM generate_data WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<GenerateDataEntity> getGenerateWeekData();

    @Query("SELECT * FROM generate_data WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')  AND scannedType LIKE :str")
    List<GenerateDataEntity> getGenerateWeekData(String str);

    @Query("SELECT * from generate_data where sqlDate = date('now','-1 day')")
    List<GenerateDataEntity> getGenerateYesterdayDataList();

    @Query("SELECT * from generate_data where sqlDate = date('now','-1 day') AND scannedType LIKE :str")
    List<GenerateDataEntity> getGenerateYesterdayFilterDataList(String str);

    @Query("SELECT * from scan_data_bookmark where strftime('%m',sqlDate) LIKE :str AND strftime('%Y',sqlDate) LIKE :str2")
    List<ScanDataEntity> getGenericBookmarkDataList(String str, String str2);

    @Query("SELECT * from scan_data_bookmark where strftime('%m',sqlDate) LIKE :str AND strftime('%Y',sqlDate) LIKE :str2 AND scannedType LIKE :str3")
    List<ScanDataEntity> getGenericBookmarkFilerDataList(String str, String str2, String str3);

    @Query("SELECT * from scan_data_bookmark where strftime('%d',sqlDate) LIKE :str AND strftime('%m',sqlDate) LIKE :str2 AND strftime('%Y',sqlDate) LIKE :str3 AND scannedType LIKE :str4")
    List<ScanDataEntity> getGenericBookmarkTimeDataList(String str, String str2, String str3, String str4);

    @Query("SELECT * from scan_data where strftime('%m',sqlDate) LIKE :month AND strftime('%Y',sqlDate) LIKE :year")
    List<ScanDataEntity> getGenericDataList(String month, String year);

    @Query("SELECT * from scan_data where strftime('%m',sqlDate) LIKE :month AND strftime('%Y',sqlDate) LIKE :year AND scannedType LIKE :type")
    List<ScanDataEntity> getGenericFilerDataList(String month, String year, String type);

    @Query("SELECT * from generate_bookmark_data where strftime('%m',sqlDate) LIKE :month AND strftime('%Y',sqlDate) LIKE :year")
    List<GenerateDataEntity> getGenericGenBookmarkDataList(String month, String year);

    @Query("SELECT * from scan_data where strftime('%d',sqlDate) LIKE :date AND strftime('%m',sqlDate) LIKE :month AND strftime('%Y',sqlDate) LIKE :year AND scannedType LIKE :type")
    List<ScanDataEntity> getGenericTimeDataList(String date, String month, String year, String type);

    @Query("SELECT * FROM card_data ORDER BY cardId DESC LIMIT 1")
    List<CardDataEntity> getLastCardRow();

    @Query("SELECT * FROM scan_data_bookmark WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day') AND scannedType LIKE :type")
    List<ScanDataEntity> getMonthBookmarkFilterData(String type);

    @Query("SELECT * FROM scan_data WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<ScanDataEntity> getMonthData();

    @Query("SELECT * FROM scan_data_bookmark WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<ScanDataEntity> getMonthDataBookmark();

    @Query("SELECT * FROM card_bookmark_data WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<CardBookmarkDataEntity> getMonthDataCardBookmark();

    @Query("SELECT * FROM generate_bookmark_data WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<GenerateDataEntity> getMonthDataGenBookmark();

    @Query("SELECT * FROM scan_data WHERE strftime('%W',sqlDate) != strftime('%W',date('now')) AND strftime('%Y',sqlDate) = strftime('%Y',date('now')) AND  strftime('%m',sqlDate) = strftime('%m',date('now')) AND DATE(sqlDate) != DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day') AND scannedType LIKE :type")
    List<ScanDataEntity> getMonthFilterData(String type);

    @Query("SELECT * FROM scan_data_bookmark WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<ScanDataEntity> getWeekBookmarkData();

    @Query("SELECT * FROM scan_data_bookmark WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')  AND scannedType LIKE :type")
    List<ScanDataEntity> getWeekBookmarkData(String type);

    @Query("SELECT * FROM card_bookmark_data WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<CardBookmarkDataEntity> getWeekCardBookmarkData();

    @Query("SELECT * FROM scan_data WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<ScanDataEntity> getWeekData();

    @Query("SELECT * FROM scan_data WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')  AND scannedType LIKE :type")
    List<ScanDataEntity> getWeekData(String type);

    @Query("SELECT * FROM scan_data_bookmark WHERE strftime('%W',sqlDate) = strftime('%W',date('now'))")
    List<ScanDataEntity> getWeekDataBookmark();

    @Query("SELECT * FROM generate_bookmark_data WHERE DATE(sqlDate) >= DATE('now', 'weekday 0', '-7 days')  AND DATE(sqlDate) != DATE('now')  AND DATE(sqlDate) != DATE('now','-1 day')")
    List<GenerateDataEntity> getWeekGenBookmarkData();

    @Query("SELECT * FROM scan_data WHERE strftime('%Y',sqlDate) = strftime('%Y',date('now'))")
    List<ScanDataEntity> getYearData();

    @Query("SELECT * FROM scan_data_bookmark WHERE strftime('%Y',sqlDate) = strftime('%Y',date('now'))")
    List<ScanDataEntity> getYearDataBookmark();

    @Query("SELECT * FROM card_bookmark_data WHERE strftime('%Y',sqlDate) = strftime('%Y',date('now'))")
    List<CardBookmarkDataEntity> getYearDataCardBookmark();

    @Query("SELECT * FROM generate_bookmark_data WHERE strftime('%Y',sqlDate) = strftime('%Y',date('now'))")
    List<GenerateDataEntity> getYearDataGenBookmark();

    @Query("SELECT * from scan_data_bookmark where sqlDate = date('now','-1 day') AND scannedType LIKE :str")
    List<ScanDataEntity> getYesterdayBookmarkFilterDataList(String str);

    @Query("SELECT * from scan_data where sqlDate = date('now','-1 day')")
    List<ScanDataEntity> getYesterdayDataList();

    @Query("SELECT * from scan_data where sqlDate = date('now','-1 day') AND scannedType LIKE :str")
    List<ScanDataEntity> getYesterdayFilterDataList(String str);

    @Insert
    void insert(CardBookmarkDataEntity cardBookmarkDataEntity);

    @Insert
    void insert(CardDataEntity cardDataEntity);

    @Insert(onConflict = 1)
    void insert(GenerateBookmarkDataEntity generateBookmarkDataEntity);

    @Insert(onConflict = 1)
    void insert(GenerateDataEntity generateDataEntity);

    @Insert(onConflict = 1)
    void insert(ScanDataBookmarkEntity scanDataBookmarkEntity);

    @Insert(onConflict = 1)
    void insert(ScanDataEntity scanDataEntity);
}
