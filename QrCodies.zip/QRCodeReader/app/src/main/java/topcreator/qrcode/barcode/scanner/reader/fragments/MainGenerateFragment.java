package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.adapter.ViewPagerAdapter;
import com.google.android.material.tabs.TabLayout;

import topcreator.qrcode.barcode.scanner.reader.splashexit.Splash_Activity;

public class MainGenerateFragment extends Fragment {
    private Activity activity;
    ViewPagerAdapter adapter;
    private Handler handler;
    /* access modifiers changed from: private */
    public ProgressBar mLoadingPb;
    private TabLayout mMainTab;
    /* access modifiers changed from: private */
    public ViewPager mMainVp;
    /* access modifiers changed from: private */
    public int[] navIcons = {R.drawable.uic_qr_icon_non, R.drawable.uic_barcode_icon_non};
    /* access modifiers changed from: private */
    public int[] navIconsActive = {R.drawable.uic_qr_icon, R.drawable.uic_barcode_icon};
    private int[] navLabels = {R.string.tab_qr_code, R.string.tab_barcode};
    private Runnable runnable;
    private FrameLayout adMobView;

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (MainActivity) context;
        }
    }

    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_generate_code, viewGroup, false);
        this.activity.getWindow().clearFlags(1024);
        init(inflate);

        adMobView = (FrameLayout) inflate.findViewById(R.id.adMobView);
        showBanner();

        ProgressBar progressBar = this.mLoadingPb;
        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
        this.handler = new Handler();
        this.runnable = new Runnable() {
            public void run() {
                if (mLoadingPb != null) {
                    mLoadingPb.setVisibility(View.GONE);
                }
                MainGenerateFragment mainGenerateFragment = MainGenerateFragment.this;
                mainGenerateFragment.setupViewPager(mainGenerateFragment.mMainVp);
                iconTabLayout();
            }
        };
        this.handler.postDelayed(this.runnable, 1500);
        return inflate;
    }

    /* access modifiers changed from: private */
    public void iconTabLayout() {
        for (int i = 0; i < this.mMainTab.getTabCount(); i++) {
            LinearLayout linearLayout = (LinearLayout) LayoutInflater.from(this.activity).inflate(R.layout.nav_item_layout, null);
            TextView textView = (TextView) linearLayout.findViewById(R.id.nav_label);
            ImageView imageView = (ImageView) linearLayout.findViewById(R.id.nav_icon);
            textView.setText(getResources().getString(this.navLabels[i]));
            if (i == 0) {
                textView.setTextColor(getResources().getColor(R.color.white));
                imageView.setImageResource(this.navIconsActive[i]);
            } else {
                imageView.setImageResource(this.navIcons[i]);
            }
            TabLayout.Tab tabAt = this.mMainTab.getTabAt(i);
            if (tabAt != null) {
                tabAt.setCustomView((View) linearLayout);
            }
        }
        this.mMainTab.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            public void onTabReselected(TabLayout.Tab tab) {
            }

            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                if (customView != null) {
                    ((TextView) customView.findViewById(R.id.nav_label)).setTextColor(getResources().getColor(R.color.white));
                    ((ImageView) customView.findViewById(R.id.nav_icon)).setImageResource(navIconsActive[tab.getPosition()]);
                }
            }

            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                if (customView != null) {
                    ((TextView) customView.findViewById(R.id.nav_label)).setTextColor(getResources().getColor(R.color.non_selected_tab));
                    ((ImageView) customView.findViewById(R.id.nav_icon)).setImageResource(navIcons[tab.getPosition()]);
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public void setupViewPager(ViewPager viewPager) {
        this.adapter = new ViewPagerAdapter(((MainActivity) this.activity).getSupportFragmentManager());
        this.adapter.addFragment(new QRGenerateListFragment(), "GONE");
        this.adapter.addFragment(new BarcodeGenerateListFragment(), "GTWO");
        viewPager.setAdapter(this.adapter);
        viewPager.setSaveFromParentEnabled(false);
        this.mMainTab.setupWithViewPager(viewPager);
    }

    private void init(View view) {
        this.mMainVp = (ViewPager) view.findViewById(R.id.main_vp);
        this.mMainTab = (TabLayout) view.findViewById(R.id.main_tab);
        this.mLoadingPb = (ProgressBar) view.findViewById(R.id.loading_pb);
    }

    public void onDestroy() {
        super.onDestroy();
        for (Fragment remove : ((MainActivity) this.activity).getSupportFragmentManager().getFragments()) {
            ((MainActivity) this.activity).getSupportFragmentManager().beginTransaction().remove(remove).commitAllowingStateLoss();
        }
        Handler handler2 = this.handler;
        if (handler2 != null) {
            Runnable runnable2 = this.runnable;
            if (runnable2 != null) {
                handler2.removeCallbacks(runnable2);
            }
        }
    }

    private void showBanner() {
        final AdView mAdView = new AdView(getActivity());
        mAdView.setAdSize(getAdSize());
        mAdView.setAdUnitId(Splash_Activity.adModel.getAdMobBanner());
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                if (adMobView != null) {
                    adMobView.removeAllViews();
                }
                adMobView.addView(mAdView);
            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        if (adMobView != null) {
            adMobView.removeAllViews();
        }
    }

    private com.google.android.gms.ads.AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = getActivity().getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(getActivity(), adWidth);
    }
}
