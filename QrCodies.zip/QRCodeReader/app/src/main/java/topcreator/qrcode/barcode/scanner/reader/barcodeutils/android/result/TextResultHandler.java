package topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.result;

import android.app.Activity;
import topcreator.qrcode.barcode.scanner.reader.R;
import com.google.zxing.Result;
import com.google.zxing.client.result.ParsedResult;

public final class TextResultHandler extends ResultHandler {
    public int getButtonCount() {
        return 1;
    }

    public int getButtonText(int i) {
        return 0;
    }

    public int getDisplayTitle() {
        return R.string.result_text;
    }

    public TextResultHandler(Activity activity, ParsedResult parsedResult, Result result) {
        super(activity, parsedResult, result);
    }

    public void handleButtonPress(int i) {
        String displayResult = getResult().getDisplayResult();
        switch (i) {
            case 0:
                webSearch(displayResult);
                return;
            case 1:
                shareByEmail(displayResult);
                return;
            case 2:
                shareBySMS(displayResult);
                return;
            case 3:
                openURL(fillInCustomSearchURL(displayResult));
                return;
            default:
                return;
        }
    }
}
