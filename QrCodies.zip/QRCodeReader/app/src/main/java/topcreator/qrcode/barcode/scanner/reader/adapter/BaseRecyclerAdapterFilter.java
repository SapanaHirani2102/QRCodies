package topcreator.qrcode.barcode.scanner.reader.adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import topcreator.qrcode.barcode.scanner.reader.holder.BaseItemHolder;
import java.util.ArrayList;
import java.util.List;

public class BaseRecyclerAdapterFilter<T, D extends BaseItemHolder> extends RecyclerView.Adapter<D> {
    protected final Class<? extends BaseItemHolder> mHolderClass;
    protected final int mLayout;
    protected List<T> mList = new ArrayList();

    public int getItemViewType(int i) {
        return i;
    }

    public BaseRecyclerAdapterFilter(@LayoutRes int i, Class<? extends BaseItemHolder> cls) {
        this.mLayout = i;
        this.mHolderClass = cls;
    }

    public D onCreateViewHolder(ViewGroup viewGroup, int i) {
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(this.mLayout, viewGroup, false);
        try {
            return (D) this.mHolderClass.getConstructor(new Class[]{View.class}).newInstance(new Object[]{inflate});
        } catch (Exception e) {
            Log.e("Generic adapter error", e + "");
            return null;
        }
    }

    public void onBindViewHolder(BaseItemHolder baseItemHolder, int i) {
        baseItemHolder.bindData(this.mList.get(i), i, this.mList.size());
    }

    public int getItemCount() {
        return this.mList.size();
    }

    public void setData(@NonNull List<T> list) {
        this.mList = list;
        notifyDataSetChanged();
    }
}
