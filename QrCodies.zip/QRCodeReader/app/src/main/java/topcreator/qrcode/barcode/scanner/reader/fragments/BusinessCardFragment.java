package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.adapter.ViewPagerAdapter;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.Intents;
import topcreator.qrcode.barcode.scanner.reader.splashexit.Splash_Activity;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import com.google.android.material.tabs.TabLayout;

public class BusinessCardFragment extends Fragment {
    private Activity activity;
    ViewPagerAdapter adapter;
    private Handler handler;
    public ProgressBar mLoadingPb;
    private TabLayout mMainHistoryTab;
    public ViewPager mMainHistoryVp;
    public int[] navIcons = {R.drawable.ii_add_un, R.drawable.ii_url_un, R.drawable.icb_wifi_un, R.drawable.icb_email_un, R.drawable.icb_product_un, R.drawable.icb_sms_un, R.drawable.icb_text_un, R.drawable.icb_contact_un, R.drawable.icb_geo_un, R.drawable.icb_isbn_un};
    public int[] navIconsActive = {R.drawable.ii_add1, R.drawable.ii_url1, R.drawable.ii_wifi1, R.drawable.ii_email1, R.drawable.ii_product1, R.drawable.ii_msg1, R.drawable.ii_text1, R.drawable.ii_call1, R.drawable.ii_loc1, R.drawable.ii_isbn1};
    private int[] navLabels = {R.string.string_address, R.string.string_url, R.string.string_wifi, R.string.string_email, R.string.string_product, R.string.string_sms, R.string.string_text, R.string.string_contact, R.string.string_geo, R.string.string_isbn};
    private Runnable runnable;
    private FrameLayout adMobView;

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (Activity) context;
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.activity.getWindow().clearFlags(1024);
        View inflate = layoutInflater.inflate(R.layout.fragment_bussiness_card, viewGroup, false);
        initView(inflate);

        adMobView = (FrameLayout) inflate.findViewById(R.id.adMobView);
        showBanner();



        ProgressBar progressBar = this.mLoadingPb;
        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
        this.handler = new Handler();
        this.runnable = new Runnable() {
            public void run() {
                BusinessCardFragment businessCardFragment = BusinessCardFragment.this;
                businessCardFragment.setupViewPager(businessCardFragment.mMainHistoryVp);
                iconTabLayout();
                if (mLoadingPb != null) {
                    mLoadingPb.setVisibility(View.GONE);
                }
            }
        };
        this.handler.postDelayed(this.runnable, 3000);
        return inflate;
    }

    private void initView(View view) {
        this.mMainHistoryVp = (ViewPager) view.findViewById(R.id.main_card_vp);
        this.mMainHistoryTab = (TabLayout) view.findViewById(R.id.main_card_tab);
        this.mLoadingPb = (ProgressBar) view.findViewById(R.id.loading_pb);
    }

    /* access modifiers changed from: private */
    public void setupViewPager(ViewPager viewPager) {
        this.adapter = new ViewPagerAdapter(((MainActivity) this.activity).getSupportFragmentManager());
        this.adapter.addFragment(getCurrentFragment(Constants.TYPE_ADDRESSBOOK), "CONE");
        this.adapter.addFragment(getCurrentFragment(Constants.TYPE_URI), "CTWO");
        this.adapter.addFragment(getCurrentFragment(Constants.TYPE_WIFI), "CTWO1");
        this.adapter.addFragment(getCurrentFragment(Constants.TYPE_EMAIL_ADDRESS), "CTWO2");
        this.adapter.addFragment(getCurrentFragment(Constants.TYPE_PRODUCT), "CTWO3");
        this.adapter.addFragment(getCurrentFragment(Constants.TYPE_SMS), "CTWO4");
        this.adapter.addFragment(getCurrentFragment(Constants.TYPE_TEXT), "CTWO5");
        this.adapter.addFragment(getCurrentFragment(Constants.TYPE_TEL), "CTWO6");
        this.adapter.addFragment(getCurrentFragment(Constants.TYPE_GEO), "CTWO7");
        this.adapter.addFragment(getCurrentFragment("ISBN"), "CTWO8");
        viewPager.setAdapter(this.adapter);
        viewPager.setSaveFromParentEnabled(false);
        viewPager.setOffscreenPageLimit(2);
        this.mMainHistoryTab.setupWithViewPager(viewPager);
    }

    private BusinessCardGenerator getCurrentFragment(String str) {
        BusinessCardGenerator businessCardGenerator = new BusinessCardGenerator();
        Bundle bundle = new Bundle();
        bundle.putString(Intents.WifiConnect.TYPE, str);
        businessCardGenerator.setArguments(bundle);
        return businessCardGenerator;
    }

    /* access modifiers changed from: private */
    public void iconTabLayout() {
        for (int i = 0; i < this.mMainHistoryTab.getTabCount(); i++) {
            final LinearLayout linearLayout = (LinearLayout) LayoutInflater.from(this.activity).inflate(R.layout.nav_item_layout, null);
            TextView textView = (TextView) linearLayout.findViewById(R.id.nav_label);
            ImageView imageView = (ImageView) linearLayout.findViewById(R.id.nav_icon);
            textView.setText(getResources().getString(this.navLabels[i]));
            if (i == 0) {
                textView.setTextColor(getResources().getColor(R.color.white));
                imageView.setImageResource(this.navIconsActive[i]);
            } else {
                imageView.setImageResource(this.navIcons[i]);
            }
            final TabLayout.Tab tabAt = this.mMainHistoryTab.getTabAt(i);
            if (tabAt != null) {
                this.activity.runOnUiThread(new Runnable() {
                    public final void run() {
                        tabAt.setCustomView((View)linearLayout);
                    }
                });
            }
        }
        this.mMainHistoryTab.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            public void onTabReselected(TabLayout.Tab tab) {
            }

            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                if (customView != null) {
                    ((TextView) customView.findViewById(R.id.nav_label)).setTextColor(getResources().getColor(R.color.white));
                    ((ImageView) customView.findViewById(R.id.nav_icon)).setImageResource(navIconsActive[tab.getPosition()]);
                }
            }

            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                if (customView != null) {
                    ((TextView) customView.findViewById(R.id.nav_label)).setTextColor(getResources().getColor(R.color.non_selected_tab));
                    ((ImageView) customView.findViewById(R.id.nav_icon)).setImageResource(navIcons[tab.getPosition()]);
                }
            }
        });
    }

    public void onDestroy() {
        super.onDestroy();
        for (Fragment remove : ((MainActivity) this.activity).getSupportFragmentManager().getFragments()) {
            ((MainActivity) this.activity).getSupportFragmentManager().beginTransaction().remove(remove).commitAllowingStateLoss();
        }
        Handler handler2 = this.handler;
        if (handler2 != null) {
            Runnable runnable2 = this.runnable;
            if (runnable2 != null) {
                handler2.removeCallbacks(runnable2);
            }
        }
    }

    private void showBanner() {
        final AdView mAdView = new AdView(getActivity());
        mAdView.setAdSize(getAdSize());
        mAdView.setAdUnitId(Splash_Activity.adModel.getAdMobBanner());
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                if (adMobView != null) {
                    adMobView.removeAllViews();
                }
                adMobView.addView(mAdView);
            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        if (adMobView != null) {
            adMobView.removeAllViews();
        }
    }

    private com.google.android.gms.ads.AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = getActivity().getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(getActivity(), adWidth);
    }
}
