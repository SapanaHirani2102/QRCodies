package topcreator.qrcode.barcode.scanner.reader.database;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "generate_data")
public class GenerateDataEntity {
    private String generateImgPath;
    @NonNull
    @PrimaryKey
    private String scannedCode;
    private String scannedType;
    private String sqlDate;
    private String time;

    public GenerateDataEntity(@NonNull String str, String str2, String str3, String str4) {
        this.scannedCode = str;
        this.scannedType = str2;
        this.time = str3;
        this.sqlDate = str4;
    }

    public GenerateDataEntity() {

    }

    public String getGenerateImgPath() {
        return this.generateImgPath;
    }

    public void setGenerateImgPath(String str) {
        this.generateImgPath = str;
    }

    @NonNull
    public String getScannedCode() {
        return this.scannedCode;
    }

    public void setScannedCode(@NonNull String str) {
        this.scannedCode = str;
    }

    public String getScannedType() {
        return this.scannedType;
    }

    public void setScannedType(String str) {
        this.scannedType = str;
    }

    public String getTime() {
        return this.time;
    }

    public void setTime(String str) {
        this.time = str;
    }

    public String getSqlDate() {
        return this.sqlDate;
    }

    public void setSqlDate(String str) {
        this.sqlDate = str;
    }
}
