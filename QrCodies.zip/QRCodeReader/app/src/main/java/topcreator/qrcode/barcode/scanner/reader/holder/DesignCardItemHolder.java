package topcreator.qrcode.barcode.scanner.reader.holder;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.GenerateInfoActivity;
import topcreator.qrcode.barcode.scanner.reader.model.DesignCardItemModel;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;

public class DesignCardItemHolder extends BaseItemHolder<DesignCardItemModel> {
    private ImageView imageView;

    public DesignCardItemHolder(View view) {
        super(view);
        this.imageView = (ImageView) view.findViewById(R.id.card_img);
    }

    public void bindData(final DesignCardItemModel designCardItemModel, final int i, int i2) {
        super.bindData(designCardItemModel, i, i2);
        this.imageView.setImageResource(designCardItemModel.getCardImage());
        this.itemView.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                DesignCardItemHolder.lambda$bindData$0(DesignCardItemHolder.this,designCardItemModel,i, view);
            }
        });
        if (i + 1 == i2) {
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMargins(0, 0, 0, 100);
            this.itemView.setLayoutParams(layoutParams);
        }
    }

    public static /* synthetic */ void lambda$bindData$0(DesignCardItemHolder designCardItemHolder, DesignCardItemModel designCardItemModel, int i, View view) {
        Bundle bundle = new Bundle();
        bundle.putString(Constants.FILTER_TYPE, designCardItemModel.getType());
        bundle.putString(Constants.CARD_TYPE, designCardItemModel.getType());
        bundle.putInt(Constants.CARD_POSITION, i);
        bundle.putString(Constants.GENERATE_TYPE, Constants.CARD_TYPE);
        GenerateInfoActivity.start(designCardItemHolder.itemView.getContext(), bundle);
    }
}
