package topcreator.qrcode.barcode.scanner.reader.activities;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.ItemTouchHelper;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.ScannedResultManager;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDataBookmarkEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.splashexit.BaseSplashActivity;
import topcreator.qrcode.barcode.scanner.reader.splashexit.Splash_Activity;
import topcreator.qrcode.barcode.scanner.reader.utils.CodeUtils;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.ImageSaver;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import topcreator.qrcode.barcode.scanner.reader.utils.TouchyWebView;
import com.google.gson.Gson;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.google.zxing.client.result.ParsedResult;
import com.google.zxing.client.result.ResultParser;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.Callable;

public class ScannedBarcodeInfo extends BaseSplashActivity {
    public static final int AZTEC = 4096;
    public static final int CODABAR = 8;
    public static final int CODE_128 = 1;
    public static final int CODE_39 = 2;
    public static final int CODE_93 = 4;
    public static final int DATA_MATRIX = 16;
    public static final int EAN_13 = 32;
    public static final int EAN_8 = 64;
    public static final int ITF = 128;
    public static final int PDF417 = 2048;
    public static final int QR_CODE = 256;
    public static final int UPC_A = 512;
    public static final int UPC_E = 1024;
    public static final String URL = "https://www.google.com/search?q=";
    private String TAG = "scannedInfo";
    private boolean isScanActivity = false;
    private RelativeLayout mBookmarkLayout;
    private CardView mBottomCardLayout;
    private CardView mCardLayout;
    private ImageView mCopyImg;
    private RelativeLayout mCopyLayout;
    private RelativeLayout mHistoryLayout;
    private ImageView mProductTypeImg;
    private RelativeLayout mScanLayout;
    private ImageView mScannedImg;
    private RelativeLayout mScannedLayout;
    private TextView mScannedTxt;
    /* access modifiers changed from: private */
    public ScrollView mScrollLayout;
    private ImageView mSearchImg;
    private RelativeLayout mSearchLayout;
    private ImageView mShareImg;
    private RelativeLayout mShareLayout;
    private TextView mTimeTxt;
    private TextView mTypeTxt;
    private View mViewOffsetHelper;
    /* access modifiers changed from: private */
    public CardView mWebCardLayout;
    /* access modifiers changed from: private */
    public ProgressBar mWebProBar;
    private TouchyWebView mWebView;
    private ParsedResult parsedResult;
    private ScanDatabase scanDatabase;
    private ScannedResultManager scannedResultManager;
    private TinyDB tinyDB;
    private FrameLayout adMobView;

    public static void start(Activity activity, Bundle bundle) {
        Intent intent = new Intent(activity, ScannedBarcodeInfo.class);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        activity.startActivity(intent);
    }

    public static boolean isNetworkStatusAvialable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivityManager != null) {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_scanned_barcode_info);
        initView();
        getBundle();
        adMobView = (FrameLayout) findViewById(R.id.adMobView);
        showBanner();
        clickListeners();
    }

    private void clickListeners() {
        this.mScannedTxt.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScannedBarcodeInfo.lambda$clickListeners$0(ScannedBarcodeInfo.this, view);
            }
        });
        this.mSearchLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScannedBarcodeInfo.lambda$clickListeners$1(ScannedBarcodeInfo.this, view);
            }
        });
        this.mCopyLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScannedBarcodeInfo.lambda$clickListeners$2(ScannedBarcodeInfo.this, view);
            }
        });
        this.mShareLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScannedBarcodeInfo.lambda$clickListeners$3(ScannedBarcodeInfo.this, view);
            }
        });
    }

    public static /* synthetic */ void lambda$clickListeners$0(ScannedBarcodeInfo scannedBarcodeInfo, View view) {
        if (scannedBarcodeInfo.mTypeTxt.getText().toString().equals("Weblink")) {
            scannedBarcodeInfo.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(scannedBarcodeInfo.mScannedTxt.getText().toString())));
        }
    }

    public static /* synthetic */ void lambda$clickListeners$1(ScannedBarcodeInfo scannedBarcodeInfo, View view) {
        if (scannedBarcodeInfo.mTypeTxt.getText().toString().equals("Weblink")) {
            scannedBarcodeInfo.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(scannedBarcodeInfo.mScannedTxt.getText().toString())));
            return;
        }
        scannedBarcodeInfo.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://www.google.com/search?q=" + scannedBarcodeInfo.mScannedTxt.getText().toString())));
    }

    public static /* synthetic */ void lambda$clickListeners$2(ScannedBarcodeInfo scannedBarcodeInfo, View view) {
        ClipboardManager clipboardManager = (ClipboardManager) scannedBarcodeInfo.getSystemService("clipboard");
        ClipData newPlainText = ClipData.newPlainText("label", scannedBarcodeInfo.mScannedTxt.getText().toString());
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(newPlainText);
            Toast makeText = Toast.makeText(scannedBarcodeInfo.getApplicationContext(), "Copied to clipboard", Toast.LENGTH_SHORT);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        }
    }

    public static /* synthetic */ void lambda$clickListeners$3(ScannedBarcodeInfo scannedBarcodeInfo, View view) {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.TEXT", scannedBarcodeInfo.mScannedTxt.getText().toString());
        intent.setType("text/plain");
        scannedBarcodeInfo.startActivity(intent);
    }

    private boolean insertBookMarkScanData(ScanDataBookmarkEntity scanDataBookmarkEntity) {
        this.scanDatabase.scanDataDao().insert(scanDataBookmarkEntity);
        return true;
    }

    private boolean insertScanData(ScanDataEntity scanDataEntity) {
        this.scanDatabase.scanDataDao().insert(scanDataEntity);
        return true;
    }

    private void getBundle() {
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            mainCalculations();
        } else if (extras.getString(Constants.GENERATE_TYPE).equals("GenerateItem")) {
            setViewVisible(extras.getString(Constants.SCANNED_TYPE), extras);
        } else {
            this.mTimeTxt.setText(extras.getString(Constants.SCANNED_TIME, ""));
            if (extras.getString(Constants.SCANNED_TYPE, "").equals(Constants.TYPE_URI)) {
                SpannableString spannableString = new SpannableString(extras.getString(Constants.SCANNED_TXT, ""));
                spannableString.setSpan(new UnderlineSpan(), 0, spannableString.length(), 0);
                this.mScannedTxt.setText(spannableString);
            } else {
                this.mScannedTxt.setText(extras.getString(Constants.SCANNED_TXT, ""));
            }
            this.mScannedImg.setImageBitmap(getImage(this, extras.getString(Constants.SCANNED_IMG, "")));
            this.parsedResult = ResultParser.parseResult((Result) new Gson().fromJson(extras.getString(Constants.SCANNED_RESULT, ""), Result.class));
            setViewVisible(this.parsedResult.getType().toString());
            this.mScanLayout.setVisibility(View.GONE);
            this.mBookmarkLayout.setVisibility(View.GONE);
            this.isScanActivity = true;
        }
    }

    private BarcodeFormat getBarcodeFormat(int i) {
        switch (i) {
            case 1:
                return BarcodeFormat.CODE_128;
            case 2:
                return BarcodeFormat.CODE_39;
            case 4:
                return BarcodeFormat.CODE_93;
            case 8:
                return BarcodeFormat.CODABAR;
            case 16:
                return BarcodeFormat.DATA_MATRIX;
            case 32:
                return BarcodeFormat.EAN_13;
            case 64:
                return BarcodeFormat.EAN_8;
            case 128:
                return BarcodeFormat.ITF;
            case 256:
                return BarcodeFormat.QR_CODE;
            case 512:
                return BarcodeFormat.UPC_A;
            case 1024:
                return BarcodeFormat.UPC_E;
            case 2048:
                return BarcodeFormat.PDF_417;
            case 4096:
                return BarcodeFormat.AZTEC;
            default:
                return BarcodeFormat.QR_CODE;
        }
    }

    private boolean mainCalculations() {
        String string = this.tinyDB.getString(Constants.BARCODE_RAW_VALUE);
        int i = this.tinyDB.getInt(Constants.BARCODE_VALUE);
        Result result = new Result(string, null, null, getBarcodeFormat(i));
        String json = new Gson().toJson((Object) result);
        Bitmap createBarCode = CodeUtils.createBarCode(string, getBarcodeFormat(i), 300, 300);
        this.parsedResult = ResultParser.parseResult(result);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ssa", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        String format = simpleDateFormat.format(Long.valueOf(result.getTimestamp()));
        String format2 = simpleDateFormat2.format(Long.valueOf(result.getTimestamp()));
        SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        String str = "image-" + result.getTimestamp() + ".jpg";
        new ImageSaver(this).setFileName(str).setDirectoryName(Constants.SAVE_DIR_NAME).save(createBarCode);
        this.mTimeTxt.setText(format);
        setViewVisible(this.parsedResult.getType().toString());
        this.mScannedImg.setImageBitmap(createBarCode);
        this.isScanActivity = false;
        final ScanDataEntity scanDataEntity = new ScanDataEntity(result.getText(), this.parsedResult.getType().toString(), str, format, format2, json, simpleDateFormat3.format(Long.valueOf(result.getTimestamp())));
        Single.fromCallable(new Callable() {
            public final Object call() {
                return Boolean.valueOf(ScannedBarcodeInfo.this.insertScanData(scanDataEntity));
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer() {
            public final void accept(Object obj) {
                ScannedBarcodeInfo.lambda$mainCalculations$5(ScannedBarcodeInfo.this, (Boolean) obj);
            }
        }, new Consumer() {
            public final void accept(Object obj) {
                ScannedBarcodeInfo.lambda$mainCalculations$6(ScannedBarcodeInfo.this, (Throwable) obj);
            }
        });
        return true;
    }

    public static /* synthetic */ void lambda$mainCalculations$5(ScannedBarcodeInfo scannedBarcodeInfo, Boolean bool) {
        bool.toString();
        String str = scannedBarcodeInfo.TAG;
        Log.e(str, "Data Inserted: " + bool);
    }

    public static /* synthetic */ void lambda$mainCalculations$6(ScannedBarcodeInfo scannedBarcodeInfo, Throwable th)  {
        String str = scannedBarcodeInfo.TAG;
        Log.e(str, "barcodeResult: " + th.getMessage());
    }

    private void webView() {
        if (isNetworkStatusAvialable(getApplicationContext())) {
            WebSettings settings = this.mWebView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setLoadWithOverviewMode(true);
            settings.setUseWideViewPort(true);
            settings.setSupportZoom(true);
            settings.setBuiltInZoomControls(true);
            settings.setDisplayZoomControls(false);
            this.mWebView.setScrollBarStyle(33554432);
            this.mWebView.setScrollbarFadingEnabled(false);
            this.mWebView.setOnScrollChangedCallback(new TouchyWebView.OnScrollChangedCallback() {
                public final void onScroll(int i, int i2, int i3, int i4) {
                    ScannedBarcodeInfo.lambda$webView$8(ScannedBarcodeInfo.this, i, i2, i3, i4);
                }
            });
            runOnUiThread(new Runnable() {
                public final void run() {
                    ScannedBarcodeInfo.lambda$webView$9(ScannedBarcodeInfo.this);
                }
            });
        }
    }

    public static /* synthetic */ void lambda$null$7(ScannedBarcodeInfo scannedBarcodeInfo) {
        ScrollView scrollView = scannedBarcodeInfo.mScrollLayout;
        scrollView.scrollTo(0, scrollView.getBottom() / 2);
    }

    public static /* synthetic */ void lambda$webView$8(final ScannedBarcodeInfo scannedBarcodeInfo, int i, int i2, int i3, int i4) {
        if (i2 == 0) {
            scannedBarcodeInfo.mScrollLayout.post(new Runnable() {
                public final void run() {
                    ScannedBarcodeInfo.lambda$null$7(scannedBarcodeInfo);
                }
            });
        }
    }

    public static /* synthetic */ void lambda$webView$9(ScannedBarcodeInfo scannedBarcodeInfo) {
        char c;
        String charSequence = scannedBarcodeInfo.mTypeTxt.getText().toString();
        int hashCode = charSequence.hashCode();
        if (hashCode == 84303) {
            if (charSequence.equals("URL")) {
                c = 3;
                switch (c) {
                    case 0:
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                }
            }
        } else if (hashCode == 2256630) {
            if (charSequence.equals("ISBN")) {
                c = 0;
                switch (c) {
                    case 0:
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                }
            }
        } else if (hashCode == 2603341) {
            if (charSequence.equals("Text")) {
                c = 2;
                switch (c) {
                    case 0:
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                }
            }
        } else if (hashCode == 1355179215 && charSequence.equals("Product")) {
            c = 1;
            switch (c) {
                case 0:
                    scannedBarcodeInfo.loadWebPage("https://www.google.com/search?q=" + scannedBarcodeInfo.mScannedTxt.getText().toString());
                    return;
                case 1:
                    scannedBarcodeInfo.loadWebPage("https://www.google.com/search?q=" + scannedBarcodeInfo.mScannedTxt.getText().toString());
                    return;
                case 2:
                    scannedBarcodeInfo.loadWebPage("https://www.google.com/search?q=" + scannedBarcodeInfo.mScannedTxt.getText().toString());
                    return;
                case 3:
                    scannedBarcodeInfo.loadWebPage(scannedBarcodeInfo.mScannedTxt.getText().toString());
                    return;
                default:
                    return;
            }
        }
        c = 65535;
        switch (c) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
        }
    }

    private void initView() {
        this.mSearchImg = (ImageView) findViewById(R.id.search_img);
        this.mCopyImg = (ImageView) findViewById(R.id.copy_img);
        this.mScannedTxt = (TextView) findViewById(R.id.scanned_txt);
        this.mViewOffsetHelper = findViewById(R.id.view_offset_helper);
        this.mProductTypeImg = (ImageView) findViewById(R.id.product_type_img);
        this.mTimeTxt = (TextView) findViewById(R.id.time_txt);
        this.mScannedImg = (ImageView) findViewById(R.id.scanned_img);
        this.mShareImg = (ImageView) findViewById(R.id.share_img);
        this.mTypeTxt = (TextView) findViewById(R.id.type_txt);
        this.mWebProBar = (ProgressBar) findViewById(R.id.web_pro_bar);
        this.mCopyLayout = (RelativeLayout) findViewById(R.id.copy_layout);
        this.mScannedLayout = (RelativeLayout) findViewById(R.id.scanned_layout);
        this.mSearchLayout = (RelativeLayout) findViewById(R.id.search_layout);
        this.mShareLayout = (RelativeLayout) findViewById(R.id.share_layout);
        this.mWebView = (TouchyWebView) findViewById(R.id.web_view);
        this.mScrollLayout = (ScrollView) findViewById(R.id.scroll_layout);
        this.mWebCardLayout = (CardView) findViewById(R.id.web_card_layout);
        this.scannedResultManager = new ScannedResultManager(this);
        this.scanDatabase = ScanDatabase.getInstance(this);
        this.tinyDB = TinyDB.getInstance(this);
    }

    private void setViewVisible(String str) {
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            findViewById(R.id.address_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Address Book");
            this.mProductTypeImg.setImageResource(R.drawable.ii_add1);
            this.mProductTypeImg.setBackground(getResources().getDrawable(R.drawable.bg_addressbook));
            this.mScannedTxt.setText(this.scannedResultManager.addressResultContent(this.parsedResult));
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            findViewById(R.id.calender_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Calender");
            this.mProductTypeImg.setImageResource(R.drawable.ii_calendar);
            this.mProductTypeImg.setBackground(getResources().getDrawable(R.drawable.bg_calender));
            this.mScannedTxt.setText(this.scannedResultManager.calenderResultContent(this.parsedResult));
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            findViewById(R.id.email_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Mail");
            this.mProductTypeImg.setImageResource(R.drawable.ii_email1);
            this.mProductTypeImg.setBackground(getResources().getDrawable(R.drawable.bg_email));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
        } else if (Constants.TYPE_GEO.equals(str)) {
            findViewById(R.id.geo_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Geo Location");
            this.mProductTypeImg.setImageResource(R.drawable.ii_loc1);
            this.mProductTypeImg.setBackground(getResources().getDrawable(R.drawable.bg_geo));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
        } else if ("ISBN".equals(str)) {
            findViewById(R.id.isbn_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("ISBN");
            this.mProductTypeImg.setImageResource(R.drawable.ii_isbn1);
            this.mProductTypeImg.setBackground(getResources().getDrawable(R.drawable.bg_isbn));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            webView();
        } else if (Constants.TYPE_WIFI.equals(str)) {
            findViewById(R.id.wifi_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Wifi");
            this.mProductTypeImg.setImageResource(R.drawable.ii_wifi1);
            this.mProductTypeImg.setBackground(getResources().getDrawable(R.drawable.bg_wifi));
            this.mScannedTxt.setText(this.scannedResultManager.wifiResultContent(this.parsedResult));
        }
    }

    private String getFormattedDate(String str) {
        return new SimpleDateFormat("dd MMM yyyy,  hh:mm a", Locale.ENGLISH).format(new Date(new Timestamp(Long.parseLong(str)).getTime()));
    }

    private void setViewVisible(String str, Bundle bundle) {
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            String string = bundle.getString(Constants.SCANNED_TXT);
            findViewById(R.id.address_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Address Book");
            this.mProductTypeImg.setImageResource(R.drawable.i_add);
            this.parsedResult = ResultParser.parseResult(new Result(string, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.scannedResultManager.addressResultContent(this.parsedResult));
            this.mScannedImg.setImageBitmap(CodeUtils.createBarCode(string, BarcodeFormat.QR_CODE, 500, 500));
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            findViewById(R.id.calender_layout).setVisibility(View.VISIBLE);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.mTypeTxt.setText("Calender");
            this.mProductTypeImg.setImageResource(R.drawable.i_cal1);
            this.mProductTypeImg.setBackground(getResources().getDrawable(R.drawable.bg_calender));
            this.mScannedTxt.setText(this.scannedResultManager.calenderResultContent(this.parsedResult));
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            String string2 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string2, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode = CodeUtils.createBarCode(string2, BarcodeFormat.QR_CODE, 500, 500);
            findViewById(R.id.email_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Mail");
            this.mProductTypeImg.setImageResource(R.drawable.i_email);
            this.mScannedImg.setImageBitmap(createBarCode);
        } else if (Constants.TYPE_GEO.equals(str)) {
            String string3 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string3, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode2 = CodeUtils.createBarCode(string3, BarcodeFormat.QR_CODE, 500, 500);
            findViewById(R.id.geo_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Geo Location");
            this.mProductTypeImg.setImageResource(R.drawable.i_loc);
            this.mScannedImg.setImageBitmap(createBarCode2);
        } else if ("ISBN".equals(str)) {
            String string4 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string4, null, null, BarcodeFormat.EAN_13));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode3 = CodeUtils.createBarCode(string4, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            findViewById(R.id.isbn_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("ISBN");
            this.mProductTypeImg.setImageResource(R.drawable.i_isbn);
            webView();
            this.mScannedImg.setImageBitmap(createBarCode3);
        } else if (Constants.TYPE_PRODUCT.equals(str)) {
            String string5 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string5, null, null, BarcodeFormat.EAN_13));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode4 = CodeUtils.createBarCode(string5, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            findViewById(R.id.product_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Product");
            this.mProductTypeImg.setImageResource(R.drawable.i_product);
            webView();
            this.mScannedImg.setImageBitmap(createBarCode4);
        } else if (Constants.TYPE_SMS.equals(str)) {
            String string6 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string6, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.scannedResultManager.smsResultContent(this.parsedResult));
            Bitmap createBarCode5 = CodeUtils.createBarCode(string6, BarcodeFormat.QR_CODE, 500, 500);
            findViewById(R.id.sms_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText(Constants.TYPE_SMS);
            this.mProductTypeImg.setImageResource(R.drawable.i_msgs);
            this.mScannedImg.setImageBitmap(createBarCode5);
        } else if (Constants.TYPE_TEL.equals(str)) {
            String string7 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string7, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.scannedResultManager.telResultContent(this.parsedResult));
            Bitmap createBarCode6 = CodeUtils.createBarCode(string7, BarcodeFormat.QR_CODE, 500, 500);
            findViewById(R.id.contact_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Contact");
            this.mProductTypeImg.setImageResource(R.drawable.i_call);
            this.mScannedImg.setImageBitmap(createBarCode6);
        } else if (Constants.TYPE_TEXT.equals(str)) {
            String string8 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string8, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode7 = CodeUtils.createBarCode(string8, BarcodeFormat.QR_CODE, 500, 500);
            findViewById(R.id.product_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Text");
            this.mProductTypeImg.setImageResource(R.drawable.i_text);
            webView();
            this.mScannedImg.setImageBitmap(createBarCode7);
        } else if (Constants.TYPE_URI.equals(str)) {
            String string9 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string9, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode8 = CodeUtils.createBarCode(string9, BarcodeFormat.QR_CODE, 500, 500);
            findViewById(R.id.product_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("URL");
            this.mProductTypeImg.setImageResource(R.drawable.i_url);
            webView();
            this.mScannedImg.setImageBitmap(createBarCode8);
        } else if (Constants.TYPE_WIFI.equals(str)) {
            String string10 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string10, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.scannedResultManager.wifiResultContent(this.parsedResult));
            Bitmap createBarCode9 = CodeUtils.createBarCode(string10, BarcodeFormat.QR_CODE, 500, 500);
            findViewById(R.id.wifi_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Wifi");
            this.mProductTypeImg.setImageResource(R.drawable.i_wifi);
            this.mScannedImg.setImageBitmap(createBarCode9);
        }
    }

    public void buttonClick(View view) {
        switch (view.getId()) {
            case R.id.address_add_layout:
                this.scannedResultManager.addressBookResult(this.parsedResult, 0);
                break;
            case R.id.address_dial_layout:
                this.scannedResultManager.addressBookResult(this.parsedResult, 2);
                break;
            case R.id.address_mail_layout:
                this.scannedResultManager.addressBookResult(this.parsedResult, 3);
                break;
            case R.id.address_view_layout:
                this.scannedResultManager.addressBookResult(this.parsedResult, 1);
                break;
            case R.id.cal_event_layout:
                this.scannedResultManager.calenderResult(this.parsedResult);
                break;
            case R.id.contact_add_layout:
                this.scannedResultManager.contactResult(this.parsedResult, 1);
                break;
            case R.id.contact_dial_layout:
                this.scannedResultManager.contactResult(this.parsedResult, 0);
                break;
            case R.id.copy_layout:
                ClipboardManager clipboardManager = (ClipboardManager) getSystemService("clipboard");
                ClipData newPlainText = ClipData.newPlainText("label", this.mScannedTxt.getText().toString());
                if (clipboardManager != null) {
                    clipboardManager.setPrimaryClip(newPlainText);
                    Toast makeText = Toast.makeText(getApplicationContext(), "Copied to clipboard", Toast.LENGTH_SHORT);
                    makeText.setGravity(17, 0, 0);
                    makeText.show();
                    break;
                } else {
                    return;
                }
            case R.id.email_add_layout:
                this.scannedResultManager.emailResult(this.parsedResult, 1);
                break;
            case R.id.email_send_layout:
                this.scannedResultManager.emailResult(this.parsedResult, 0);
                break;
            case R.id.geo_direction_layout:
                this.scannedResultManager.geoResult(this.parsedResult, 1);
                break;
            case R.id.geo_map_layout:
                this.scannedResultManager.geoResult(this.parsedResult, 0);
                break;
            case R.id.isbn_book_layout:
                this.scannedResultManager.isbnResult(this.parsedResult, 1);
                break;
            case R.id.isbn_search_layout:
                this.scannedResultManager.isbnResult(this.parsedResult, 0);
                break;
            case R.id.search_layout:
                if (!this.mTypeTxt.getText().toString().equals("Weblink")) {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://www.google.com/search?q=" + this.mScannedTxt.getText().toString())));
                    break;
                } else {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse(this.mScannedTxt.getText().toString())));
                    break;
                }
            case R.id.share_layout:
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.putExtra("android.intent.extra.TEXT", this.mScannedTxt.getText().toString());
                intent.setType("text/plain");
                startActivity(intent);
                break;
            case R.id.sms_send_layout:
                this.scannedResultManager.smsResult(this.parsedResult, 0);
                break;
            case R.id.wifi_connect_layout:
                this.scannedResultManager.wifiResult(this.parsedResult);
                break;
        }
    }

    private void loadWebPage(String str) {
        this.mWebView.loadUrl(str);
        this.mWebProBar.setVisibility(View.VISIBLE);
        this.mWebView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                webView.loadUrl(str);
                ScannedBarcodeInfo.this.mWebProBar.setVisibility(View.VISIBLE);
                return false;
            }

            public void onPageFinished(WebView webView, String str) {
                super.onPageFinished(webView, str);
                ScannedBarcodeInfo.this.mWebProBar.setVisibility(View.GONE);
                ScannedBarcodeInfo.this.mWebCardLayout.setVisibility(View.VISIBLE);
                ScannedBarcodeInfo.this.mScrollLayout.post(new Runnable() {
                    public final void run() {
                        ScannedBarcodeInfo.this.mScrollLayout.scrollTo(0, ScannedBarcodeInfo.this.mScrollLayout.getBottom() / 2);
                    }
                });
            }
        });
    }

    private Bitmap getImage(Context context, String str) {
        return new ImageSaver(context).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(str).load();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        if (!this.isScanActivity) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
        finish();
        return true;
    }

    public void onBackPressed() {
        super.onBackPressed();
        if (!this.isScanActivity) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
        finish();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (i != 4 || !this.mWebView.canGoBack()) {
            return super.onKeyDown(i, keyEvent);
        }
        this.mWebView.goBack();
        return true;
    }

    private void showBanner() {
        final AdView mAdView = new AdView(this);
        mAdView.setAdSize(getAdSize());
        mAdView.setAdUnitId(Splash_Activity.adModel.getAdMobBanner());
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                if (adMobView != null) {
                    adMobView.removeAllViews();
                }
                adMobView.addView(mAdView);
            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        if (adMobView != null) {
            adMobView.removeAllViews();
        }
    }

    private com.google.android.gms.ads.AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }
}
