package topcreator.qrcode.barcode.scanner.reader.holder;

import android.view.View;
import android.widget.ImageView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.events.AdvanceQrEvent;
import topcreator.qrcode.barcode.scanner.reader.model.AdvanceQrModel;
import org.greenrobot.eventbus.EventBus;

public class AdvanceQrHolder extends BaseItemHolder<AdvanceQrModel> {
    private ImageView logoImg;
    private View viewEnd;
    private View viewStart;

    public AdvanceQrHolder(View view) {
        super(view);
        this.logoImg = (ImageView) view.findViewById(R.id.logo_img);
        this.viewStart = view.findViewById(R.id.view_start);
        this.viewEnd = view.findViewById(R.id.view_end);
    }

    public void bindData(final AdvanceQrModel advanceQrModel, int i, int i2) {
        super.bindData(advanceQrModel, i, i2);
        if (i == 0) {
            this.viewStart.setVisibility(0);
        }
        this.logoImg.setImageResource(advanceQrModel.getLogo());
        if (!advanceQrModel.getType().equals("style")) {
            this.logoImg.setBackground(this.itemView.getResources().getDrawable(advanceQrModel.getStyle()));
        } else {
            this.logoImg.setBackground(this.itemView.getResources().getDrawable(R.drawable.bg_play));
        }
        this.itemView.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                EventBus.getDefault().post(new AdvanceQrEvent(advanceQrModel));
            }
        });
    }
}
