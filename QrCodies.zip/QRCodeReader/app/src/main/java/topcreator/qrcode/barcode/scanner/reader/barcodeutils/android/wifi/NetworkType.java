package topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.wifi;

enum NetworkType {
    WEP,
    WPA,
    NO_PASSWORD,
    WPA2_EAP;

    static NetworkType forIntentValue(String str) {
        if (str == null) {
            return NO_PASSWORD;
        }
        char c = 65535;
        switch (str.hashCode()) {
            case -1039816366:
                if (str.equals("nopass")) {
                    c = 4;
                    break;
                }
                break;
            case 85826:
                if (str.equals("WEP")) {
                    c = 3;
                    break;
                }
                break;
            case 86152:
                if (str.equals("WPA")) {
                    c = 0;
                    break;
                }
                break;
            case 2670762:
                if (str.equals("WPA2")) {
                    c = 1;
                    break;
                }
                break;
            case 1194974097:
                if (str.equals("WPA2-EAP")) {
                    c = 2;
                    break;
                }
                break;
        }
        switch (c) {
            case 0:
            case 1:
                return WPA;
            case 2:
                return WPA2_EAP;
            case 3:
                return WEP;
            case 4:
                return NO_PASSWORD;
            default:
                throw new IllegalArgumentException(str);
        }
    }
}
