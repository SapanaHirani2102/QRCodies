package topcreator.qrcode.barcode.scanner.reader.activities;

import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;
import org.greenrobot.eventbus.EventBus;

public class TestDate {
    String[] days = new String[7];

    public static void main(String[] strArr) {
        ArrayList arrayList = new ArrayList();
        arrayList.add("7-1-2019");
        arrayList.add("7-1-2019");
        arrayList.add("7-1-2019");
        arrayList.add("6-1-2019");
        arrayList.add("6-1-2019");
        arrayList.add("6-1-2019");
        arrayList.add("4-1-2019");
        arrayList.add("3-1-2019");
        arrayList.add("3-1-2019");
        arrayList.add("2-1-2019");
        arrayList.add("1-1-2019");
        arrayList.add("31-12-2018");
        arrayList.add("28-12-2018");
        arrayList.add("25-12-2018");
        arrayList.add("25-12-2018");
        arrayList.add("25-12-2018");
        arrayList.add("15-12-2018");
        arrayList.add("15-12-2018");
        arrayList.add("12-12-2018");
        arrayList.add("10-12-2018");
        arrayList.add("5-12-2018");
        arrayList.add("1-12-2018");
        arrayList.add("23-11-2018");
        arrayList.add("23-11-2018");
        arrayList.add("23-11-2018");
        arrayList.add("22-12-2018");
        arrayList.add("11-12-2018");
        arrayList.add("9-12-2018");
        arrayList.add("2-12-2018");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        Calendar instance = Calendar.getInstance();
        instance.set(7, 1);
        String format = simpleDateFormat.format(instance.getTime());
        instance.set(7, 7);
        simpleDateFormat.format(instance.getTime());
        instance.set(5, 1);
        String format2 = simpleDateFormat.format(instance.getTime());
        Calendar instance2 = Calendar.getInstance();
        String format3 = simpleDateFormat.format(instance2.getTime());
        instance2.add(5, -1);
        Iterator it = arrayList.iterator();
        String str = null;
        String str2 = null;
        String str3 = null;
        while (it.hasNext()) {
            String str4 = (String) it.next();
            if (str4.equals(format3)) {
                Log.e(EventBus.TAG, "main: Current date ");
            } else {
                instance2.add(5, -1);
                str = simpleDateFormat.format(instance2.getTime());
            }
            if (str4.equals(str)) {
                Log.e(EventBus.TAG, "main: Previous date ");
            } else {
                instance2.add(5, -1);
                str2 = simpleDateFormat.format(instance2.getTime());
            }
            if (str4.equals(str2)) {
                Log.e(EventBus.TAG, "main: Previous Week ");
            } else if (!str4.equals(format)) {
                instance2.add(5, -1);
                str2 = simpleDateFormat.format(instance2.getTime());
            } else {
                instance2.add(5, -1);
                str3 = simpleDateFormat.format(instance2.getTime());
            }
            if (str4.equals(str3)) {
                Log.e(EventBus.TAG, "main: Previous month ");
            }
            if (!str4.equals(format2)) {
                instance2.add(5, -1);
                str3 = simpleDateFormat.format(instance2.getTime());
            } else {
                instance2.add(2, -1);
                str3 = simpleDateFormat.format(instance2.getTime());
            }
        }
    }
}
