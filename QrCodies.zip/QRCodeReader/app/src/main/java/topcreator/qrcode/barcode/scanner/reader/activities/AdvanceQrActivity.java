package topcreator.qrcode.barcode.scanner.reader.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.adapter.BaseRecyclerAdapterFilter;
import topcreator.qrcode.barcode.scanner.reader.events.AdvanceQrEvent;
import topcreator.qrcode.barcode.scanner.reader.holder.AdvanceQrHolder;
import topcreator.qrcode.barcode.scanner.reader.model.AdvanceQrModel;
import topcreator.qrcode.barcode.scanner.reader.model.AdvanceQrStyleModel;
import topcreator.qrcode.barcode.scanner.reader.splashexit.BaseSplashActivity;
import topcreator.qrcode.barcode.scanner.reader.utils.CodeUtils;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.CreateDCode;
import com.google.android.gms.measurement.api.AppMeasurementSdk;
import com.google.zxing.BarcodeFormat;
import com.kizitonwose.colorpreference.ColorDialog;
import com.kizitonwose.colorpreference.ColorShape;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class AdvanceQrActivity extends AppCompatActivity implements ColorDialog.OnColorSelectedListener {
    private boolean check = false;
    private int colorOne = -1;
    private int colorTwo = -1;
    private String content;
    private int defColor = -16750849;
    private Bundle globalBundle;
    Bitmap logo = null;
    private BaseRecyclerAdapterFilter<AdvanceQrModel, AdvanceQrHolder> mAdapter;
    private RecyclerView mAdvanceQrColorRv;
    private RecyclerView mAdvanceQrScannedRv;
    private RecyclerView mAdvanceQrStyleRv;
    private ImageView mBackBtn;
    private View mCenterView;
    private ImageView mColorImg;
    private RelativeLayout mColorLayout;
    private LinearLayout mColorLayoutQr;
    private TextView mColorNewTxt;
    private TextView mColorOne;
    private TextView mColorTwo;
    private TextView mColorTxt;
    private ImageView mFirstColor;
    private RelativeLayout mFirstColorLayout;
    private TextView mGradColorTxt;
    private ImageView mImageView4;
    private ImageView mLogoImg;
    private RelativeLayout mLogoLayout;
    private TextView mLogoTxt;
    private ImageView mNonColorImg;
    private ImageView mQrImg;
    private ImageView mQrImg4;
    private LinearLayout mQrImgLayout;
    private RadioGroup mRadioGroup;
    private ImageView mSaveBtn;
    private ImageView mSecondColor;
    private RelativeLayout mSecondColorLayout;
    private TextView mSingleColorTxt;
    private ImageView mStyleImg;
    private RelativeLayout mStyleLayout;
    private TextView mStyleTxt;
    private int selectedStyle = -1;
    private int simple = 1;


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(AdvanceQrStyleModel advanceQrStyleModel) {
    }

    public static void start(Context context, Bundle bundle) {
        Intent intent = new Intent(context, AdvanceQrActivity.class);
        intent.putExtra(Constants.GENERATE_INFO, bundle);
        context.startActivity(intent);
        BaseSplashActivity.showadd();
    }

    public static Bitmap getBitmapFromVectorDrawable(Context context, int i) {
        Drawable drawable = ContextCompat.getDrawable(context, i);
        if (Build.VERSION.SDK_INT < 21) {
            drawable = DrawableCompat.wrap(drawable).mutate();
        }
        Bitmap createBitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return createBitmap;
    }

    public static Bitmap loadBitmapFromView(View view) {
        Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        view.draw(new Canvas(createBitmap));
        return createBitmap;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_advance_qr);
        statusBarSet();
        initView();

        this.mColorTwo.setVisibility(8);
        final Bundle bundleExtra = getIntent().getBundleExtra(Constants.GENERATE_INFO);
        if (bundleExtra != null) {
            this.globalBundle = bundleExtra;
            String string = bundleExtra.getString(Constants.FILTER_TYPE);
            String string2 = bundleExtra.getString(Constants.GENERATE_TYPE);
            if (string2 == null || !string2.equals(Constants.CARD_TYPE)) {
                showResultData(string, bundleExtra);
                this.mQrImg.setImageBitmap(CreateDCode.CreateQRCodeSmooth(this.content, 1000, 0.2f, this.colorOne, this.colorTwo));
                this.mQrImgLayout.setBackground(getResources().getDrawable(R.drawable.bg_play));
            } else {
                showResultCard(bundleExtra.getString(Constants.CARD_TYPE), bundleExtra);
                this.mQrImg.setImageBitmap(CreateDCode.CreateQRCodeSmooth(this.content, 1000, 0.2f, this.colorOne, this.colorTwo));
                this.mQrImgLayout.setBackground(getResources().getDrawable(R.drawable.bg_play));
            }
        }
        this.mAdapter = new BaseRecyclerAdapterFilter<>(R.layout.advance_qr_item, AdvanceQrHolder.class);
        this.mAdvanceQrScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 0));
        this.mAdvanceQrScannedRv.setAdapter(this.mAdapter);
        this.mAdapter.setData(filterStyleData());
        this.mColorLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.lambda$onCreate$0(AdvanceQrActivity.this, view);
            }
        });
        this.mLogoLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.lambda$onCreate$1(AdvanceQrActivity.this, view);
            }
        });
        this.mStyleLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.lambda$onCreate$3(AdvanceQrActivity.this, view);
            }
        });
        this.mSingleColorTxt.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.lambda$onCreate$4(AdvanceQrActivity.this, view);
            }
        });
        this.mGradColorTxt.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.lambda$onCreate$5(AdvanceQrActivity.this, view);
            }
        });
        this.mNonColorImg.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.lambda$onCreate$6(AdvanceQrActivity.this, view);
            }
        });
        this.mFirstColor.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.this.colorPicker(0);
            }
        });
        this.mSecondColor.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.this.colorPicker(1);
            }
        });
        this.mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public final void onCheckedChanged(RadioGroup radioGroup, int i) {
                AdvanceQrActivity.lambda$onCreate$9(AdvanceQrActivity.this, radioGroup, i);
            }
        });
        this.mColorOne.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.this.colorPicker(0);
            }
        });
        this.mColorTwo.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.this.colorPicker(1);
            }
        });
        this.mSaveBtn.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.lambda$onCreate$12(AdvanceQrActivity.this, bundleExtra, view);
            }
        });
        this.mBackBtn.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                AdvanceQrActivity.this.finish();
            }
        });
        mStyleImg.setColorFilter(ContextCompat.getColor(this, R.color.main_btn_end));
        mStyleTxt.setTextColor(getResources().getColor(R.color.main_btn_end));

    }

    public static /* synthetic */ void lambda$onCreate$0(AdvanceQrActivity advanceQrActivity, View view) {
        advanceQrActivity.mAdapter.setData(advanceQrActivity.filterData());
        advanceQrActivity.mColorImg.setColorFilter(ContextCompat.getColor(advanceQrActivity, R.color.main_btn_end));
        advanceQrActivity.mStyleImg.setColorFilter(ContextCompat.getColor(advanceQrActivity, R.color.contect_background_color));
        advanceQrActivity.mLogoImg.setColorFilter(ContextCompat.getColor(advanceQrActivity, R.color.contect_background_color));
        advanceQrActivity.mLogoTxt.setTextColor(advanceQrActivity.getResources().getColor(R.color.contect_background_color));
        advanceQrActivity.mColorTxt.setTextColor(advanceQrActivity.getResources().getColor(R.color.main_btn_end));
        advanceQrActivity.mStyleTxt.setTextColor(advanceQrActivity.getResources().getColor(R.color.contect_background_color));
        advanceQrActivity.mAdvanceQrScannedRv.setVisibility(8);
        advanceQrActivity.mColorLayoutQr.setVisibility(0);
        advanceQrActivity.mFirstColorLayout.setVisibility(8);
        advanceQrActivity.mSecondColorLayout.setVisibility(8);
    }

    public static /* synthetic */ void lambda$onCreate$1(AdvanceQrActivity advanceQrActivity, View view) {
        advanceQrActivity.mColorNewTxt.setText("");
        advanceQrActivity.mColorImg.setColorFilter(ContextCompat.getColor(advanceQrActivity, R.color.contect_background_color));
        advanceQrActivity.mStyleImg.setColorFilter(ContextCompat.getColor(advanceQrActivity, R.color.contect_background_color));
        advanceQrActivity.mLogoImg.setColorFilter(ContextCompat.getColor(advanceQrActivity, R.color.main_btn_end));
        advanceQrActivity.mLogoTxt.setTextColor(advanceQrActivity.getResources().getColor(R.color.main_btn_end));
        advanceQrActivity.mColorTxt.setTextColor(advanceQrActivity.getResources().getColor(R.color.contect_background_color));
        advanceQrActivity.mStyleTxt.setTextColor(advanceQrActivity.getResources().getColor(R.color.contect_background_color));
        advanceQrActivity.mAdapter.setData(advanceQrActivity.filterData());
        advanceQrActivity.mAdvanceQrScannedRv.setVisibility(0);
        advanceQrActivity.mColorLayoutQr.setVisibility(8);
        advanceQrActivity.mFirstColorLayout.setVisibility(8);
        advanceQrActivity.mSecondColorLayout.setVisibility(8);
    }

    public static /* synthetic */ void lambda$onCreate$3(AdvanceQrActivity advanceQrActivity, View view) {
        advanceQrActivity.mColorNewTxt.setText("");
        advanceQrActivity.mColorImg.setColorFilter(ContextCompat.getColor(advanceQrActivity, R.color.contect_background_color));
        advanceQrActivity.mLogoImg.setColorFilter(ContextCompat.getColor(advanceQrActivity, R.color.contect_background_color));
        advanceQrActivity.mStyleImg.setColorFilter(ContextCompat.getColor(advanceQrActivity, R.color.main_btn_end));
        advanceQrActivity.mLogoTxt.setTextColor(advanceQrActivity.getResources().getColor(R.color.contect_background_color));
        advanceQrActivity.mColorTxt.setTextColor(advanceQrActivity.getResources().getColor(R.color.contect_background_color));
        advanceQrActivity.mStyleTxt.setTextColor(advanceQrActivity.getResources().getColor(R.color.main_btn_end));
        advanceQrActivity.mAdapter.setData(advanceQrActivity.filterStyleData());
        advanceQrActivity.mAdvanceQrScannedRv.setVisibility(0);
        advanceQrActivity.mColorLayoutQr.setVisibility(8);
        advanceQrActivity.mFirstColorLayout.setVisibility(8);
        advanceQrActivity.mSecondColorLayout.setVisibility(8);
    }

    public static /* synthetic */ void lambda$onCreate$4(AdvanceQrActivity advanceQrActivity, View view) {
        advanceQrActivity.mFirstColorLayout.setVisibility(0);
        advanceQrActivity.mSecondColorLayout.setVisibility(8);
        advanceQrActivity.mCenterView.setVisibility(8);
        if (advanceQrActivity.colorOne == -1) {
            advanceQrActivity.colorOne = ViewCompat.MEASURED_STATE_MASK;
        }
        advanceQrActivity.colorTwo = -1;
        advanceQrActivity.setQrStyle(advanceQrActivity.selectedStyle, advanceQrActivity.colorOne, -1);
        advanceQrActivity.mColorNewTxt.setText("Select Single Color");
    }

    public static /* synthetic */ void lambda$onCreate$5(AdvanceQrActivity advanceQrActivity, View view) {
        advanceQrActivity.mCenterView.setVisibility(0);
        advanceQrActivity.mFirstColorLayout.setVisibility(0);
        advanceQrActivity.mSecondColorLayout.setVisibility(0);
        advanceQrActivity.setQrStyle(advanceQrActivity.selectedStyle, advanceQrActivity.colorOne, advanceQrActivity.colorTwo);
        advanceQrActivity.mColorNewTxt.setText("Select Any Two Colors");
    }

    public static /* synthetic */ void lambda$onCreate$6(AdvanceQrActivity advanceQrActivity, View view) {
        advanceQrActivity.mColorNewTxt.setText("");
        advanceQrActivity.colorOne = -1;
        advanceQrActivity.colorTwo = -1;
        advanceQrActivity.setQrStyle(advanceQrActivity.selectedStyle, advanceQrActivity.colorOne, advanceQrActivity.colorTwo);
        Drawable background = advanceQrActivity.mFirstColor.getBackground();
        if (background instanceof ShapeDrawable) {
            ((ShapeDrawable) background).getPaint().setColor(ViewCompat.MEASURED_STATE_MASK);
        } else if (background instanceof GradientDrawable) {
            ((GradientDrawable) background).setColor(ViewCompat.MEASURED_STATE_MASK);
        } else if (background instanceof ColorDrawable) {
            ((ColorDrawable) background).setColor(ViewCompat.MEASURED_STATE_MASK);
        }
        Drawable background2 = advanceQrActivity.mSecondColor.getBackground();
        if (background2 instanceof ShapeDrawable) {
            ((ShapeDrawable) background2).getPaint().setColor(ViewCompat.MEASURED_STATE_MASK);
        } else if (background2 instanceof GradientDrawable) {
            ((GradientDrawable) background2).setColor(ViewCompat.MEASURED_STATE_MASK);
        } else if (background2 instanceof ColorDrawable) {
            ((ColorDrawable) background2).setColor(ViewCompat.MEASURED_STATE_MASK);
        }
        advanceQrActivity.mFirstColorLayout.setVisibility(8);
        advanceQrActivity.mSecondColorLayout.setVisibility(8);
    }

    public static /* synthetic */ void lambda$onCreate$9(AdvanceQrActivity advanceQrActivity, RadioGroup radioGroup, int i) {
        if (i != -1) {
            switch (i) {
                case R.id.radioButton:
                    advanceQrActivity.mColorTwo.setVisibility(8);
                    advanceQrActivity.check = false;
                    return;
                case R.id.radioButton2:
                    advanceQrActivity.mColorTwo.setVisibility(0);
                    advanceQrActivity.check = true;
                    return;
                default:
                    return;
            }
        }
    }

    public static /* synthetic */ void lambda$onCreate$12(AdvanceQrActivity advanceQrActivity, Bundle bundle, View view) {
        if (bundle != null) {
            Bitmap loadBitmapFromView = loadBitmapFromView(advanceQrActivity.mQrImgLayout);
            String string = bundle.getString(Constants.GENERATE_TYPE);
            if (string == null || !string.equals(Constants.CARD_TYPE)) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                loadBitmapFromView.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
                bundle.putByteArray("customQr", byteArrayOutputStream.toByteArray());
                GenerateResultActivity.start(advanceQrActivity, bundle);
                advanceQrActivity.finish();
                return;
            }
            ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
            loadBitmapFromView.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream2);
            bundle.putByteArray("customQr", byteArrayOutputStream2.toByteArray());
            GenerateCardResultActivity.start(advanceQrActivity, bundle);
            advanceQrActivity.finish();
        }
    }

    private List<AdvanceQrModel> filterData() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new AdvanceQrModel(R.drawable.non, "logo", R.drawable.bg_play));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_apps_store_icon, "logo", R.drawable.bg_addressbook));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_bit_coin_icon, "logo", R.drawable.bg_email));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_calender_icon, "logo", R.drawable.bg_geo));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_ducoments_icon, "logo", R.drawable.bg_isbn));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_facebook_icon, "logo", R.drawable.bg_product));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_gmail_icon, "logo", R.drawable.bg_play));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_gplus_icon, "logo", R.drawable.bg_sms));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_icon, "logo", R.drawable.bg_text));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_instagram_icon, "logo", R.drawable.bg_url));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_linkedin_icon, "logo", R.drawable.bg_wifi));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_pinterest_icon, "logo", R.drawable.bg_social));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_play_store_icon, "logo", R.drawable.bg_play));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_twitter_icon, "logo", R.drawable.bg_twitter));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_youtube_icon, "logo", R.drawable.bg_calender));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_whats_app_icon, "logo", R.drawable.bg_isbn));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_soundcloud_icon, "logo", R.drawable.bg_cloud));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_share_icon, "logo", R.drawable.bg_share));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_vk, "logo", R.drawable.bg_vk));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_vimeo_icon, "logo", R.drawable.bg_vimo));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_viber_icon, "logo", R.drawable.bg_url));
        arrayList.add(new AdvanceQrModel(R.drawable.icl_wifi_icon, "logo", R.drawable.bg_wifi_2));
        return arrayList;
    }

    private List<AdvanceQrModel> filterStyleData() {
        ArrayList arrayList1 = new ArrayList();
        arrayList1.add(new AdvanceQrModel(R.drawable.non, "style", 11));
//        arrayList1.add(new AdvanceQrModel(R.drawable.icst_1, "style", 1));
        arrayList1.add(new AdvanceQrModel(R.drawable.icst_2, "style", 2));
        arrayList1.add(new AdvanceQrModel(R.drawable.icst_3, "style", 3));
        arrayList1.add(new AdvanceQrModel(R.drawable.icst_4, "style", 4));
        arrayList1.add(new AdvanceQrModel(R.drawable.icst_5, "style", 5));
//        arrayList1.add(new AdvanceQrModel(R.drawable.icst_6, "style", 6));
//        arrayList1.add(new AdvanceQrModel(R.drawable.icst_7, "style", 7));
//        arrayList1.add(new AdvanceQrModel(R.drawable.icst_8, "style", 8));
//        arrayList1.add(new AdvanceQrModel(R.drawable.icst_9, "style", 9));
        arrayList1.add(new AdvanceQrModel(R.drawable.icst_10, "style", 10));
        return arrayList1;
    }

    private void initView() {
        this.mAdvanceQrScannedRv = (RecyclerView) findViewById(R.id.advance_qr_scanned_rv);
        this.mQrImg = (ImageView) findViewById(R.id.qr_img);
        this.mColorTwo = (TextView) findViewById(R.id.color_two);
        this.mColorOne = (TextView) findViewById(R.id.color_one);
        this.mRadioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        this.mColorLayout = (RelativeLayout) findViewById(R.id.color_layout);
        this.mLogoLayout = (RelativeLayout) findViewById(R.id.logo_layout);
        this.mStyleLayout = (RelativeLayout) findViewById(R.id.style_layout);
        this.mSecondColor = (ImageView) findViewById(R.id.second_color);
        this.mFirstColor = (ImageView) findViewById(R.id.first_color);
        this.mSingleColorTxt = (TextView) findViewById(R.id.single_color_txt);
        this.mGradColorTxt = (TextView) findViewById(R.id.grad_color_txt);
        this.mColorLayoutQr = (LinearLayout) findViewById(R.id.color_layout_qr);
        this.mSecondColorLayout = (RelativeLayout) findViewById(R.id.second_color_layout);
        this.mFirstColorLayout = (RelativeLayout) findViewById(R.id.first_color_layout);
        this.mStyleImg = (ImageView) findViewById(R.id.style_img);
        this.mColorImg = (ImageView) findViewById(R.id.color_img);
        this.mLogoImg = (ImageView) findViewById(R.id.logo_img);
        this.mLogoTxt = (TextView) findViewById(R.id.logo_txt);
        this.mColorTxt = (TextView) findViewById(R.id.color_txt);
        this.mStyleTxt = (TextView) findViewById(R.id.style_txt);
        this.mQrImgLayout = (LinearLayout) findViewById(R.id.qr_img_layout);
        this.mSaveBtn = (ImageView) findViewById(R.id.save_btn);
        this.mBackBtn = (ImageView) findViewById(R.id.back_btn);
        this.mCenterView = findViewById(R.id.center_view);
        this.mNonColorImg = (ImageView) findViewById(R.id.non_color_img);
        this.mColorNewTxt = (TextView) findViewById(R.id.color_new_txt);
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(AdvanceQrEvent advanceQrEvent) {
        char c;
        String type = advanceQrEvent.getAdvanceQrModel().getType();
        int hashCode = type.hashCode();
       /* if (hashCode == -1332194002) {
            if (type.equals("background")) {
                c = 2;
                switch (c) {
                    case 0:
                        if (advanceQrEvent.getAdvanceQrModel().getLogo() != R.drawable.non) {
                            this.logo = null;
                            setQrStyle(this.selectedStyle, this.colorOne, this.colorTwo);
                            return;
                        }
                        this.logo = getBitmapFromVectorDrawable(this, advanceQrEvent.getAdvanceQrModel().getLogo());
                        setQrStyle(this.selectedStyle, this.colorOne, this.colorTwo);
                        return;
                    case 1:
                        setQrStyle(advanceQrEvent.getAdvanceQrModel().getStyle(), this.colorOne, this.colorTwo);
                        return;
                    case 2:
                        if (advanceQrEvent.getAdvanceQrModel().getLogo() != R.drawable.non) {
                            this.mQrImgLayout.setBackground(getResources().getDrawable(R.drawable.bg_play));
                            return;
                        } else {
                            this.mQrImgLayout.setBackground(getResources().getDrawable(advanceQrEvent.getAdvanceQrModel().getStyle()));
                            return;
                        }
                    default:
                        return;
                }
            }
        } else */if (hashCode == 3327403) {
            if (type.equals("logo")) {
                c = 0;
                switch (c) {
                    case 0:
                        if (advanceQrEvent.getAdvanceQrModel().getLogo() != R.drawable.non) {
                            this.logo = getBitmapFromVectorDrawable(this, advanceQrEvent.getAdvanceQrModel().getLogo());
                            setQrStyle(this.selectedStyle, this.colorOne, this.colorTwo);
                            return;
                        }
                        this.logo = null;
                        setQrStyle(this.selectedStyle, this.colorOne, this.colorTwo);
                        return;
                    case 1:
                        setQrStyle(advanceQrEvent.getAdvanceQrModel().getStyle(), this.colorOne, this.colorTwo);
                        return;
                    case 2:
                        if (advanceQrEvent.getAdvanceQrModel().getLogo() != R.drawable.non) {
                            this.mQrImgLayout.setBackground(getResources().getDrawable(advanceQrEvent.getAdvanceQrModel().getLogo()));
                            return;
                        } else {
                            this.mQrImgLayout.setBackground(getResources().getDrawable(R.drawable.bg_play));
                            return;
                        }
                    default:
                        return;
                }
            }
        } else if (hashCode == 109780401 && type.equals("style")) {
            c = 1;
            switch (c) {
                case 0:
                    if (advanceQrEvent.getAdvanceQrModel().getLogo() == R.drawable.non) {
                        this.logo = null;
                        setQrStyle(this.selectedStyle, this.colorOne, this.colorTwo);
                        return;
                    }
                    this.logo = getBitmapFromVectorDrawable(this, advanceQrEvent.getAdvanceQrModel().getLogo());
                    setQrStyle(this.selectedStyle, this.colorOne, this.colorTwo);
                    return;
                case 1:
                    setQrStyle(advanceQrEvent.getAdvanceQrModel().getStyle(), this.colorOne, this.colorTwo);
                    return;
                case 2:
                    if (advanceQrEvent.getAdvanceQrModel().getLogo() == R.drawable.non) {
                        this.mQrImgLayout.setBackground(getResources().getDrawable(R.drawable.bg_play));
                        return;
                    } else {
                        this.mQrImgLayout.setBackground(getResources().getDrawable(advanceQrEvent.getAdvanceQrModel().getLogo()));
                        return;
                    }
                default:
                    return;
            }
        }
        c = 65535;
        switch (c) {
            case 0:
                if (advanceQrEvent.getAdvanceQrModel().getLogo() != R.drawable.non) {
                    this.logo = getBitmapFromVectorDrawable(this, advanceQrEvent.getAdvanceQrModel().getLogo());
                    setQrStyle(this.selectedStyle, this.colorOne, this.colorTwo);
                    return;
                }
                this.logo = null;
                setQrStyle(this.selectedStyle, this.colorOne, this.colorTwo);
                return;
            case 1:
                setQrStyle(advanceQrEvent.getAdvanceQrModel().getStyle(), this.colorOne, this.colorTwo);
                return;
            case 2:
                if (advanceQrEvent.getAdvanceQrModel().getLogo() != R.drawable.non) {
                    this.mQrImgLayout.setBackground(getResources().getDrawable(advanceQrEvent.getAdvanceQrModel().getLogo()));
                    return;
                } else {
                    this.mQrImgLayout.setBackground(getResources().getDrawable(R.drawable.bg_play));
                    return;
                }
            default:
                return;
        }
    }


    private void setQrStyle(int i, int i2, int i3) {
        Bitmap bitmap;
        if (i != -1) {
            switch (i) {
                case 1:
                    bitmap = CreateDCode.CreateQRCodePolygon(this.content, 1000, 5, i2, i3);
                    this.selectedStyle = i;
                    break;
                case 2:
                    bitmap = CreateDCode.CreateQRCodeDot(this.content, 1000, i2, i3);
                    this.selectedStyle = i;
                    break;
                case 3:
                    bitmap = CreateDCode.CreateQRCodeSDot(this.content, 1000, i2, i3);
                    this.selectedStyle = i;
                    break;
                case 4:
                    bitmap = CreateDCode.CreateQRCodeSmooth(this.content, 1000, 1.0f, i2, i3);
                    this.selectedStyle = i;
                    break;
                case 5:
                    bitmap = CreateDCode.CreateQRCodePolygon(this.content, 1000, 3, i2, i3);
                    this.selectedStyle = i;
                    break;
                case 6:
                    bitmap = CreateDCode.CreateQRCodePolygon(this.content, 1000, 4, i2, i3);
                    this.selectedStyle = i;
                    break;
                case 7:
                    bitmap = CreateDCode.CreateQRCodeStar(this.content, 1000, 4, i2, i3);
                    this.selectedStyle = i;
                    break;
                case 8:
                    bitmap = CreateDCode.CreateQRCodeStar(this.content, 1000, 5, i2, i3);
                    this.selectedStyle = i;
                    break;
                case 9:
                    bitmap = CreateDCode.CreateQRCodeStar(this.content, 1000, 10, i2, i3);
                    this.selectedStyle = i;
                    break;
                case 10:
                    bitmap = CreateDCode.CreateQRCodeBitmap(this.content, 500, new Bitmap[]{getBitmapFromVectorDrawable(this, R.drawable.icn_tumblr), getBitmapFromVectorDrawable(this, R.drawable.icn_tumblr), getBitmapFromVectorDrawable(this, R.drawable.icn_tumblr), getBitmapFromVectorDrawable(this, R.drawable.icn_tumblr), getBitmapFromVectorDrawable(this, R.drawable.icn_tumblr), getBitmapFromVectorDrawable(this, R.drawable.icn_tumblr), getBitmapFromVectorDrawable(this, R.drawable.icn_tumblr)}, getBitmapFromVectorDrawable(this, R.drawable.icl_gplus_icon));
                    this.selectedStyle = i;
                    break;
                case 11:
                    bitmap = CreateDCode.CreateQRCodeSmooth(this.content, 1000, 0.0f, i2, i3);
                    this.selectedStyle = i;
                    break;
                default:
                    bitmap = null;
                    break;
            }
        } else {
            bitmap = CreateDCode.CreateQRCodeSmooth(this.content, 1000, 0.0f, i2, i3);
        }
        Bitmap bitmap2 = this.logo;
        if (bitmap2 != null) {
            bitmap = CreateDCode.withIcon(bitmap, bitmap2, 0.3f);
        }
        this.mQrImg.setImageBitmap(bitmap);
    }

    /* access modifiers changed from: private */
    public void colorPicker(int i) {
        new ColorDialog.Builder(this).setColorShape(ColorShape.CIRCLE).setColorChoices(R.array.color_choices).setSelectedColor(-16711936).setTag(String.valueOf(i)).show();
    }

    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    public void onColorSelected(int i, String str) {
        int parseInt = Integer.parseInt(str);
        if (parseInt == 0) {
            Drawable background = this.mFirstColor.getBackground();
            if (background instanceof ShapeDrawable) {
                ((ShapeDrawable) background).getPaint().setColor(i);
            } else if (background instanceof GradientDrawable) {
                ((GradientDrawable) background).setColor(i);
            } else if (background instanceof ColorDrawable) {
                ((ColorDrawable) background).setColor(i);
            }
            this.colorOne = i;
            setQrStyle(this.selectedStyle, this.colorOne, this.colorTwo);
        } else if (parseInt == 1) {
            Drawable background2 = this.mSecondColor.getBackground();
            if (background2 instanceof ShapeDrawable) {
                ((ShapeDrawable) background2).getPaint().setColor(i);
            } else if (background2 instanceof GradientDrawable) {
                ((GradientDrawable) background2).setColor(i);
            } else if (background2 instanceof ColorDrawable) {
                ((ColorDrawable) background2).setColor(i);
            }
            this.colorTwo = i;
            setQrStyle(this.selectedStyle, this.colorOne, this.colorTwo);
        }
    }

    private void showResultData(String str, Bundle bundle) {
        String str2;
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            this.content = bundle.getString(Constants.GENERATE_URL_NAME);
        } else if (!Constants.TYPE_CALENDAR.equals(str)) {
            if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
                String string = bundle.getString(Constants.GENERATE_URL_NAME);
                String string2 = bundle.getString(Constants.GENERATE_URL_LINK);
                String string3 = bundle.getString(Constants.GENERATE_EMAIL_LINK);
                this.content = "MATMSG:TO:" + string + ";SUB:" + string3 + ";BODY:" + string2 + ";;";
            } else if (Constants.TYPE_GEO.equals(str)) {
                String string4 = bundle.getString(Constants.GENERATE_URL_NAME);
                String string5 = bundle.getString(Constants.GENERATE_URL_LINK);
                this.content = "geo:" + string4 + "," + string5;
            } else if ("ISBN".equals(str)) {
                bundle.getString(Constants.GENERATE_URL_NAME);
                this.content = bundle.getString(Constants.GENERATE_URL_LINK);
            } else if (Constants.TYPE_PRODUCT.equals(str)) {
                bundle.getString(Constants.GENERATE_URL_NAME);
                this.content = bundle.getString(Constants.GENERATE_URL_LINK);
            } else if (Constants.TYPE_SMS.equals(str)) {
                String string6 = bundle.getString(Constants.GENERATE_URL_NAME);
                String string7 = bundle.getString(Constants.GENERATE_URL_LINK);
                this.content = "smsto:" + string6 + ":" + string7;
            } else if (Constants.TYPE_TEL.equals(str)) {
                String string8 = bundle.getString(Constants.GENERATE_URL_NAME);
                bundle.getString(Constants.GENERATE_URL_LINK);
                this.content = "tel:" + string8;
            } else if (Constants.TYPE_TEXT.equals(str)) {
                bundle.getString(Constants.GENERATE_URL_NAME);
                this.content = bundle.getString(Constants.GENERATE_URL_LINK);
            } else if (Constants.TYPE_URI.equals(str)) {
                bundle.getString(Constants.GENERATE_URL_NAME);
                String string9 = bundle.getString(Constants.GENERATE_URL_LINK);
                if (string9 == null) {
                    string9 = "http://www.example.com";
                } else if (!string9.toLowerCase().contains("http")) {
                    string9 = "http://" + string9;
                }
                this.content = string9;
            } else if (Constants.TYPE_WIFI.equals(str)) {
                String string10 = bundle.getString(Constants.GENERATE_URL_NAME);
                String string11 = bundle.getString(Constants.GENERATE_URL_LINK);
                String string12 = bundle.getString(Constants.GENERATE_WIFI_NET);
                if (string12.equals("WPA/WPA2")) {
                    string12 = "WPA";
                }
                String string13 = bundle.getString(Constants.GENERATE_WIFI_HIDE);
                if (string12.equals("non")) {
                    if (string13.equals("true")) {
                        str2 = "WIFI:S:" + string10 + ";P:" + string11 + ";H:" + string13 + ";;";
                    } else {
                        str2 = "WIFI:S:" + string10 + ";P:" + string11 + ";;";
                    }
                } else if (string13.equals("true")) {
                    str2 = "WIFI:S:" + string10 + ";T:" + string12 + ";P:" + string11 + ";H:" + string13 + ";;";
                } else {
                    str2 = "WIFI:S:" + string10 + ";T:" + string12 + ";P:" + string11 + ";;";
                }
                this.content = str2;
            }
        }
    }

    private void showResultCard(String str, Bundle bundle) {
        String string = bundle.getString(Constants.GENERATE_URL_NAME);
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            setCardData(bundle, string);
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            setContentView((int) R.layout.activity_generate_card_result);
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            setEmailCardData(bundle);
        } else if (Constants.TYPE_GEO.equals(str)) {
            setGeoCardData(bundle);
        } else if (Constants.TYPE_ISBN.equals(str)) {
            setISBNCardData(bundle);
        } else if (Constants.TYPE_PRODUCT.equals(str)) {
            setProCardData(bundle);
        } else if (Constants.TYPE_SMS.equals(str)) {
            setSMSCardData(bundle);
        } else if (Constants.TYPE_TEL.equals(str)) {
            setTelCardData(bundle);
        } else if (Constants.TYPE_TEXT.equals(str)) {
            setTxtCardData(bundle);
        } else if (Constants.TYPE_URI.equals(str)) {
            setUrlCardData(bundle);
        } else if (Constants.TYPE_WIFI.equals(str)) {
            setWifiCardData(bundle);
        }
    }

    private void setCardData(Bundle bundle, String str) {
        this.content = str;
    }

    private void setEmailCardData(Bundle bundle) {
        String upperCase = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME).toUpperCase();
        String string = bundle.getString("company");
        String string2 = bundle.getString("web");
        this.content = "MATMSG:TO:" + upperCase + ";SUB:" + string + ";BODY:" + string2 + ";;";
    }

    private void setGeoCardData(Bundle bundle) {
        String string = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
        String string2 = bundle.getString("company");
        bundle.getString("web").toUpperCase();
        this.content = "geo:" + string + "," + string2;
    }

    private void setISBNCardData(Bundle bundle) {
        bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
        String string = bundle.getString("company");
        bundle.getString("web").toUpperCase();
        CodeUtils.createBarCode(string, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
        this.content = string;
    }

    private void setProCardData(Bundle bundle) {
        bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
        String string = bundle.getString("company");
        bundle.getString("web").toUpperCase();
        this.content = string;
    }

    private void setSMSCardData(Bundle bundle) {
        String string = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
        String string2 = bundle.getString("company");
        bundle.getString("web").toUpperCase();
        this.content = "smsto:" + string + ":" + string2;
    }

    private void setTelCardData(Bundle bundle) {
        String upperCase = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME).toUpperCase();
        bundle.getString("company");
        this.content = "tel:" + upperCase;
    }

    private void setTxtCardData(Bundle bundle) {
        this.content = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
    }

    private void setUrlCardData(Bundle bundle) {
        bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME).toUpperCase();
        String string = bundle.getString("company");
        if (string == null) {
            string = "http://www.example.com";
        } else if (!string.toLowerCase().contains("http")) {
            string = "http://" + string;
        }
        this.content = string;
    }

    private void setWifiCardData(Bundle bundle) {
        String str;
        String upperCase = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME).toUpperCase();
        String string = bundle.getString("company");
        String string2 = bundle.getString("mobile");
        String string3 = bundle.getString("phone");
        if (string2.equals("WPA/WPA2")) {
            string2 = "WPA";
        }
        if (string2.equals("non")) {
            if (string3.equals("true")) {
                str = "WIFI:S:" + upperCase + ";P:" + string + ";H:" + string3 + ";;";
            } else {
                str = "WIFI:S:" + upperCase + ";P:" + string + ";;";
            }
        } else if (string3.equals("true")) {
            str = "WIFI:S:" + upperCase + ";T:" + string2 + ";P:" + string + ";H:" + string3 + ";;";
        } else {
            str = "WIFI:S:" + upperCase + ";T:" + string2 + ";P:" + string + ";;";
        }
        this.content = str;
    }

    public static void setWindowFlag(Activity activity, int i, boolean z) {
        Window window = activity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags = i | attributes.flags;
        } else {
            attributes.flags = (i ^ -1) & attributes.flags;
        }
        window.setAttributes(attributes);
    }

    private void statusBarSet() {
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, 67108864, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(1280);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, 67108864, false);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_bar_color));
        }
    }

}