package topcreator.qrcode.barcode.scanner.reader.holder;

import android.view.View;
import android.widget.ImageView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.model.AdvanceQrStyleModel;
import org.greenrobot.eventbus.EventBus;

public class AdvanceQrStyleHolder extends BaseItemHolder<AdvanceQrStyleModel> {
    private ImageView logoImg;

    public AdvanceQrStyleHolder(View view) {
        super(view);
        this.logoImg = (ImageView) view.findViewById(R.id.logo_img);
    }

    public void bindData(final AdvanceQrStyleModel advanceQrStyleModel, int i, int i2) {
        super.bindData(advanceQrStyleModel, i, i2);
        this.logoImg.setBackgroundColor(advanceQrStyleModel.getStyle());
        this.itemView.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                EventBus.getDefault().post(new AdvanceQrStyleModel(advanceQrStyleModel.getStyle()));
            }
        });
    }
}
