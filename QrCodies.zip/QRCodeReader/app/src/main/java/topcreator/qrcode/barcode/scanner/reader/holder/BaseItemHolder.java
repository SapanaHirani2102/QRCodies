package topcreator.qrcode.barcode.scanner.reader.holder;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

public class BaseItemHolder<T> extends RecyclerView.ViewHolder {
    protected T mObject;
    protected int mPosition;
    protected int mSize;

    public BaseItemHolder(View view) {
        super(view);
    }

    public void bindData(T t, int i, int i2) {
        this.mObject = t;
        this.mPosition = i;
        this.mSize = i2;
    }
}
