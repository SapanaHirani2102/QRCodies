package topcreator.qrcode.barcode.scanner.reader.model;

import androidx.annotation.DrawableRes;

public class DesignCardItemModel {
    @DrawableRes
    private int cardImage;
    private int position;
    private String type;

    public DesignCardItemModel(int i, String str) {
        this.cardImage = i;
        this.type = str;
    }

    public DesignCardItemModel(int i, String str, int i2) {
        this.cardImage = i;
        this.type = str;
        this.position = i2;
    }

    public int getCardImage() {
        return this.cardImage;
    }

    public int getPosition() {
        return this.position;
    }

    public void setPosition(int i) {
        this.position = i;
    }

    public String getType() {
        return this.type;
    }
}
