package topcreator.qrcode.barcode.scanner.reader.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.database.CardBookmarkDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.ImageSaver;
import com.nabinbhandari.android.permissions.PermissionHandler;
import com.nabinbhandari.android.permissions.Permissions;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;

public class SelectCardResultActivity extends AppCompatActivity {
    Bitmap bBitmap;
    String bCard;
    Bundle bundle;
    Bitmap fBitmap;
    String fCard;
    SimpleDateFormat fd = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
    private String id = null;
    ImageSaver imageSaver;
    private boolean isBookmark = false;
    private boolean isBookmarkPre = false;
    private ImageView mBackCardImg;
    private ImageView mBookmarkImg;
    private RelativeLayout mBookmarkLayout;
    private LinearLayout mButtonBottom;
    private ImageView mCopyImg;
    private RelativeLayout mCopyLayout;
    private ImageView mFrontCardImg;
    private TextView mGenerateBtn;
    private LinearLayout mLinearLayout;
    private ImageView mShareImg;
    private RelativeLayout mShareLayout;
    private ScanDatabase scanDatabase;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle2) {
        super.onCreate(bundle2);
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        setContentView((int) R.layout.generate_card_select_layout);
        statusBarSet();
        initView();
        this.scanDatabase = ScanDatabase.getInstance(this);
        this.imageSaver = new ImageSaver(this);
        this.bundle = getIntent().getExtras();
        Bundle bundle3 = this.bundle;
        if (bundle3 != null) {
            this.id = bundle3.getString("cardId");
            this.fCard = this.bundle.getString("cardF");
            this.bCard = this.bundle.getString("cardB");
            this.bundle.getString("cardName");
            this.bundle.getString("cardNumber");
            this.bundle.getString("cardType");
            this.bundle.getString("cardSql");
            this.bundle.getString("cardTime");
            this.fBitmap = getImage(this.fCard);
            Bitmap bitmap = this.fBitmap;
            if (bitmap != null) {
                this.mFrontCardImg.setImageBitmap(bitmap);
            }
            this.bBitmap = getImage(this.bCard);
            Bitmap bitmap2 = this.bBitmap;
            if (bitmap2 != null) {
                this.mBackCardImg.setImageBitmap(bitmap2);
            }
            if (getBookmarkSize(this.id) > 0) {
                this.mBookmarkImg.setImageResource(R.drawable.i_bookmark_select);
                this.isBookmarkPre = true;
                this.isBookmark = true;
            } else {
                this.mBookmarkImg.setImageResource(R.drawable.i_bookmark1);
                this.isBookmarkPre = false;
                this.isBookmark = false;
            }
        }
        this.mBookmarkLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SelectCardResultActivity.lambda$onCreate$0(SelectCardResultActivity.this, view);
            }
        });
        this.mShareLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SelectCardResultActivity.lambda$onCreate$1(SelectCardResultActivity.this, view);
            }
        });
        this.mCopyLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                Permissions.check((Context) SelectCardResultActivity.this, "android.permission.WRITE_EXTERNAL_STORAGE", (String) null, (PermissionHandler) new PermissionHandler() {
                    public void onGranted() {
                        long currentTimeMillis = System.currentTimeMillis();
                        String str = "f_image-" + currentTimeMillis + ".jpg";
                        SelectCardResultActivity.this.imageSaver.setFileName(str).setDirectoryName(Constants.SAVE_DIR_NAME_GALLERY).setExternal(true).save(SelectCardResultActivity.this.fBitmap);
                        String absolutePath = SelectCardResultActivity.this.imageSaver.getFilePath().getAbsolutePath();
                        SelectCardResultActivity.this.imageSaver.setFileName("b_image-" + currentTimeMillis + ".jpg").setDirectoryName(Constants.SAVE_DIR_NAME_GALLERY).setExternal(true).save(SelectCardResultActivity.this.bBitmap);
                        String absolutePath2 = SelectCardResultActivity.this.imageSaver.getFilePath().getAbsolutePath();
                        Toast.makeText(SelectCardResultActivity.this, "Save to gallery Successful!", Toast.LENGTH_LONG).show();
                        MediaScannerConnection.scanFile(SelectCardResultActivity.this, new String[]{absolutePath, absolutePath2}, null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String str, Uri uri) {
                                Log.i("ExternalStorage", "Scanned " + str + ":");
                                StringBuilder sb = new StringBuilder();
                                sb.append("-> uri=");
                                sb.append(uri);
                                Log.i("ExternalStorage", sb.toString());
                            }
                        });
                    }
                });
            }
        });
        this.mGenerateBtn.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SelectCardResultActivity.lambda$onCreate$3(SelectCardResultActivity.this, view);
            }
        });
    }

    private void statusBarSet() {
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, 67108864, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(1280);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, 67108864, false);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_bar_color));
        }
    }

    public static void setWindowFlag(Activity activity, int i, boolean z) {
        Window window = activity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags = i | attributes.flags;
        } else {
            attributes.flags = (i ^ -1) & attributes.flags;
        }
        window.setAttributes(attributes);
    }

    public static /* synthetic */ void lambda$onCreate$0(SelectCardResultActivity selectCardResultActivity, View view) {
        if (selectCardResultActivity.isBookmark) {
            selectCardResultActivity.mBookmarkImg.setImageResource(R.drawable.i_bookmark1);
            selectCardResultActivity.isBookmark = false;
            return;
        }
        selectCardResultActivity.mBookmarkImg.setImageResource(R.drawable.i_bookmark_select);
        selectCardResultActivity.isBookmark = true;
    }

    public static /* synthetic */ void lambda$onCreate$1(SelectCardResultActivity selectCardResultActivity, View view) {
        File file = new File(selectCardResultActivity.fCard);
        File file2 = new File(selectCardResultActivity.bCard);
        ArrayList arrayList = new ArrayList();
        arrayList.add(file);
        arrayList.add(file2);
        shareMultiple(arrayList, selectCardResultActivity);
    }

    public static /* synthetic */ void lambda$onCreate$3(SelectCardResultActivity selectCardResultActivity, View view) {
        if (selectCardResultActivity.isBookmark && !selectCardResultActivity.isBookmarkPre) {
            long currentTimeMillis = System.currentTimeMillis();
            Bundle bundle2 = selectCardResultActivity.bundle;
            if (bundle2 != null) {
                String string = bundle2.getString("cardName");
                String string2 = selectCardResultActivity.bundle.getString("cardNumber");
                String string3 = selectCardResultActivity.bundle.getString("cardType");
                selectCardResultActivity.bundle.getString("cardSql");
                selectCardResultActivity.bundle.getString("cardTime");
                CardBookmarkDataEntity cardBookmarkDataEntity = new CardBookmarkDataEntity(string, String.valueOf(currentTimeMillis), selectCardResultActivity.fd.format(Long.valueOf(currentTimeMillis)), Integer.parseInt(string2), selectCardResultActivity.fCard, selectCardResultActivity.bCard, string3, Integer.parseInt(selectCardResultActivity.id));
                selectCardResultActivity.insertBookmarkDatabase(cardBookmarkDataEntity);
            }
            selectCardResultActivity.finish();
        } else if (selectCardResultActivity.isBookmark || !selectCardResultActivity.isBookmarkPre) {
            selectCardResultActivity.finish();
        } else if (selectCardResultActivity.id != null) {
            selectCardResultActivity.scanDatabase.scanDataDao().deleteCardItemBookmark(selectCardResultActivity.id);
            selectCardResultActivity.finish();
        } else {
            selectCardResultActivity.finish();
        }
    }

    private static void shareMultiple(List<File> list, Context context) {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND_MULTIPLE");
        intent.putExtra("android.intent.extra.SUBJECT", "Here are some files.");
        intent.setType("image/*");
        ArrayList arrayList = new ArrayList();
        for (File absolutePath : list) {
            arrayList.add(Uri.fromFile(new File(absolutePath.getAbsolutePath())));
        }
        intent.putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList);
        context.startActivity(intent);
    }

    private void initView() {
        this.mGenerateBtn = (TextView) findViewById(R.id.generate_btn);
        this.mCopyImg = (ImageView) findViewById(R.id.copy_img);
        this.mCopyLayout = (RelativeLayout) findViewById(R.id.copy_layout);
        this.mBookmarkImg = (ImageView) findViewById(R.id.bookmark_img);
        this.mLinearLayout = (LinearLayout) findViewById(R.id.linearLayout);
        this.mBackCardImg = (ImageView) findViewById(R.id.back_card_img);
        this.mShareLayout = (RelativeLayout) findViewById(R.id.share_layout);
        this.mButtonBottom = (LinearLayout) findViewById(R.id.button_bottom);
        this.mShareImg = (ImageView) findViewById(R.id.share_img);
        this.mFrontCardImg = (ImageView) findViewById(R.id.front_card_img);
        this.mBookmarkLayout = (RelativeLayout) findViewById(R.id.bookmark_layout);
    }

    private Bitmap getImage(String str) {
        File file = new File(str);
        if (file.exists()) {
            return BitmapFactory.decodeFile(file.getAbsolutePath());
        }
        return null;
    }

    private int getBookmarkSize(String str) {
        return this.scanDatabase.scanDataDao().checkCardBookMark(str).size();
    }

    private void insertBookmarkDatabase(final CardBookmarkDataEntity cardBookmarkDataEntity) {
        Single.fromCallable(new Callable() {
            public final Object call() {
                 SelectCardResultActivity.this.scanDatabase.scanDataDao().insert(cardBookmarkDataEntity);
                 return cardBookmarkDataEntity;
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer() {
                    public final void accept(Object obj) {
                        SelectCardResultActivity.lambda$insertBookmarkDatabase$5(SelectCardResultActivity.this);
                    }
                }, $$Lambda$SelectCardResultActivity$4LHSn_EAZrfEIm69JHaJuv4Kuw.INSTANCE);
    }

    public static /* synthetic */ void lambda$insertBookmarkDatabase$5(SelectCardResultActivity selectCardResultActivity) {
//        Log.e("Bookmark", "Data Bookmark Inserted: " + bool);
        selectCardResultActivity.finish();
    }
}
