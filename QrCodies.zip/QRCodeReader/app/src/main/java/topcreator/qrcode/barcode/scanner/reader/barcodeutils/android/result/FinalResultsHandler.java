package topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.result;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;
import android.telephony.PhoneNumberUtils;
import android.util.Log;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.Contents;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.Intents;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.LocaleManager;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.book.SearchBookContentsActivity;
import com.google.android.gms.actions.SearchIntents;
import com.google.android.gms.measurement.api.AppMeasurementSdk;
import com.google.zxing.Result;
import com.google.zxing.client.result.ParsedResult;
import com.google.zxing.client.result.ParsedResultType;
import com.google.zxing.client.result.ResultParser;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

public class FinalResultsHandler {
    private static final String[] ADDRESS_TYPE_STRINGS = {"home", "work"};
    private static final int[] ADDRESS_TYPE_VALUES = {1, 2};
    private static final String[] EMAIL_TYPE_STRINGS = {"home", "work", "mobile"};
    private static final int[] EMAIL_TYPE_VALUES = {1, 2, 4};
    public static final int MAX_BUTTON_COUNT = 4;
    private static final int NO_TYPE = -1;
    private static final String[] PHONE_TYPE_STRINGS = {"home", "work", "mobile", "fax", "pager", "main"};
    private static final int[] PHONE_TYPE_VALUES = {1, 3, 2, 4, 6, 12};
    private static final String TAG = "FinalResultsHandler";
    private final Activity activity;
    private String customProductSearch;
    private Result rawResult;
    private ParsedResult result;

    public boolean areContentsSecure() {
        return false;
    }

    FinalResultsHandler(Activity activity2, ParsedResult parsedResult) {
        this(activity2, parsedResult, null);
    }

    public FinalResultsHandler(Activity activity2) {
        this.activity = activity2;
    }

    FinalResultsHandler(Activity activity2, ParsedResult parsedResult, Result result2) {
        this.result = parsedResult;
        this.activity = activity2;
        this.rawResult = result2;
        this.customProductSearch = parseCustomSearchURL();
    }

    public final ParsedResult getResult() {
        return this.result;
    }

    /* access modifiers changed from: package-private */
    public final boolean hasCustomProductSearch() {
        return this.customProductSearch != null;
    }

    /* access modifiers changed from: package-private */
    public final Activity getActivity() {
        return this.activity;
    }

    public CharSequence getDisplayContents() {
        return this.result.getDisplayResult().replace("\r", "");
    }

    public final ParsedResultType getType() {
        return this.result.getType();
    }

    public final void addPhoneOnlyContact(String[] strArr, String[] strArr2) {
        addContact(null, null, null, strArr, strArr2, null, null, null, null, null, null, null, null, null, null, null);
    }

    public final void addEmailOnlyContact(String[] strArr, String[] strArr2) {
        addContact(null, null, null, null, null, strArr, strArr2, null, null, null, null, null, null, null, null, null);
    }

    public final void addContact(String[] strArr, String[] strArr2, String str, String[] strArr3, String[] strArr4, String[] strArr5, String[] strArr6, String str2, String str3, String str4, String str5, String str6, String str7, String[] strArr7, String str8, String[] strArr8) {
        String[] strArr9 = strArr;
        String[] strArr10 = strArr2;
        String[] strArr11 = strArr3;
        String[] strArr12 = strArr4;
        String[] strArr13 = strArr5;
        String[] strArr14 = strArr6;
        String str9 = str2;
        String str10 = str3;
        String[] strArr15 = strArr7;
        String str11 = str8;
        String[] strArr16 = strArr8;
        Intent intent = new Intent("android.intent.action.INSERT_OR_EDIT", ContactsContract.Contacts.CONTENT_URI);
        intent.setType("vnd.android.cursor.item/contact");
        putExtra(intent, AppMeasurementSdk.ConditionalUserProperty.NAME, (strArr9 == null || strArr9.length <= 0) ? null : strArr9[0]);
        putExtra(intent, "phonetic_name", str);
        if (strArr11 != null) {
            int min = Math.min(strArr11.length, Contents.PHONE_KEYS.length);
            for (int i = 0; i < min; i++) {
                putExtra(intent, Contents.PHONE_KEYS[i], strArr11[i]);
                if (strArr12 != null && i < strArr12.length) {
                    int phoneContractType = toPhoneContractType(strArr12[i]);
                    if (phoneContractType >= 0) {
                        intent.putExtra(Contents.PHONE_TYPE_KEYS[i], phoneContractType);
                    }
                }
            }
        }
        if (strArr13 != null) {
            int min2 = Math.min(strArr13.length, Contents.EMAIL_KEYS.length);
            for (int i2 = 0; i2 < min2; i2++) {
                putExtra(intent, Contents.EMAIL_KEYS[i2], strArr13[i2]);
                if (strArr14 != null && i2 < strArr14.length) {
                    int emailContractType = toEmailContractType(strArr14[i2]);
                    if (emailContractType >= 0) {
                        intent.putExtra(Contents.EMAIL_TYPE_KEYS[i2], emailContractType);
                    }
                }
            }
        }
        ArrayList arrayList = new ArrayList();
        if (strArr15 != null) {
            int length = strArr15.length;
            int i3 = 0;
            while (true) {
                if (i3 >= length) {
                    break;
                }
                String str12 = strArr15[i3];
                if (str12 != null && !str12.isEmpty()) {
                    ContentValues contentValues = new ContentValues(2);
                    contentValues.put("mimetype", "vnd.android.cursor.item/website");
                    contentValues.put("data1", str12);
                    arrayList.add(contentValues);
                    break;
                }
                i3++;
            }
        }
        if (str11 != null) {
            ContentValues contentValues2 = new ContentValues(3);
            contentValues2.put("mimetype", "vnd.android.cursor.item/contact_event");
            contentValues2.put("data2", 3);
            contentValues2.put("data1", str11);
            arrayList.add(contentValues2);
        }
        if (strArr10 != null) {
            int length2 = strArr10.length;
            int i4 = 0;
            while (true) {
                if (i4 >= length2) {
                    break;
                }
                String str13 = strArr10[i4];
                if (str13 != null && !str13.isEmpty()) {
                    ContentValues contentValues3 = new ContentValues(3);
                    contentValues3.put("mimetype", "vnd.android.cursor.item/nickname");
                    contentValues3.put("data2", 1);
                    contentValues3.put("data1", str13);
                    arrayList.add(contentValues3);
                    break;
                }
                i4++;
            }
        }
        if (!arrayList.isEmpty()) {
            intent.putParcelableArrayListExtra("data", arrayList);
        }
        StringBuilder sb = new StringBuilder();
        if (str9 != null) {
            sb.append(10);
            sb.append(str9);
        }
        if (strArr16 != null && strArr16.length >= 2) {
            sb.append(10);
            sb.append(strArr16[0]);
            sb.append(',');
            sb.append(strArr16[1]);
        }
        if (sb.length() > 0) {
            putExtra(intent, "notes", sb.substring(1));
        }
        if (str10 == null || !str10.startsWith("xmpp:")) {
            putExtra(intent, "im_handle", str10);
        } else {
            intent.putExtra("im_protocol", 7);
            intent.putExtra("im_handle", str10.substring(5));
        }
        putExtra(intent, "postal", str4);
        if (str5 != null) {
            int addressContractType = toAddressContractType(str5);
            if (addressContractType >= 0) {
                intent.putExtra("postal_type", addressContractType);
            }
        }
        putExtra(intent, "company", str6);
        putExtra(intent, "job_title", str7);
        launchIntent(intent);
    }

    private static int toEmailContractType(String str) {
        return doToContractType(str, EMAIL_TYPE_STRINGS, EMAIL_TYPE_VALUES);
    }

    private static int toPhoneContractType(String str) {
        return doToContractType(str, PHONE_TYPE_STRINGS, PHONE_TYPE_VALUES);
    }

    private static int toAddressContractType(String str) {
        return doToContractType(str, ADDRESS_TYPE_STRINGS, ADDRESS_TYPE_VALUES);
    }

    private static int doToContractType(String str, String[] strArr, int[] iArr) {
        if (str == null) {
            return -1;
        }
        for (int i = 0; i < strArr.length; i++) {
            String str2 = strArr[i];
            if (str.startsWith(str2) || str.startsWith(str2.toUpperCase(Locale.ENGLISH))) {
                return iArr[i];
            }
        }
        return -1;
    }

    public final void shareByEmail(String str) {
        sendEmail(null, null, null, null, str);
    }

    public final void sendEmail(String[] strArr, String[] strArr2, String[] strArr3, String str, String str2) {
        Intent intent = new Intent("android.intent.action.SENDTO", Uri.parse("mailto:"));
        if (!(strArr == null || strArr.length == 0)) {
            intent.putExtra("android.intent.extra.EMAIL", strArr);
        }
        if (!(strArr2 == null || strArr2.length == 0)) {
            intent.putExtra("android.intent.extra.CC", strArr2);
        }
        if (!(strArr3 == null || strArr3.length == 0)) {
            intent.putExtra("android.intent.extra.BCC", strArr3);
        }
        putExtra(intent, "android.intent.extra.SUBJECT", str);
        putExtra(intent, "android.intent.extra.TEXT", str2);
        launchIntent(Intent.createChooser(intent, "Send email..."));
    }

    public final void shareBySMS(String str) {
        sendSMSFromUri("smsto:", str);
    }

    public final void sendSMS(String str, String str2) {
        sendSMSFromUri("smsto:" + str, str2);
    }

    private void sendSMSFromUri(String str, String str2) {
        Intent intent = new Intent("android.intent.action.SENDTO", Uri.parse(str));
        putExtra(intent, "sms_body", str2);
        intent.putExtra("compose_mode", true);
        launchIntent(intent);
    }

    public final void sendMMS(String str, String str2, String str3) {
        sendMMSFromUri("mmsto:" + str, str2, str3);
    }

    private void sendMMSFromUri(String str, String str2, String str3) {
        Intent intent = new Intent("android.intent.action.SENDTO", Uri.parse(str));
        if (str2 == null || str2.isEmpty()) {
            putExtra(intent, "subject", this.activity.getString(R.string.msg_default_mms_subject));
        } else {
            putExtra(intent, "subject", str2);
        }
        putExtra(intent, "sms_body", str3);
        intent.putExtra("compose_mode", true);
        launchIntent(intent);
    }

    public final void dialPhone(String str) {
        launchIntent(new Intent("android.intent.action.DIAL", Uri.parse("tel:" + str)));
    }

    public final void dialPhoneFromUri(String str) {
        launchIntent(new Intent("android.intent.action.DIAL", Uri.parse(str)));
    }

    public final void openMap(String str) {
        launchIntent(new Intent("android.intent.action.VIEW", Uri.parse(str)));
    }

    public final void searchMap(String str) {
        launchIntent(new Intent("android.intent.action.VIEW", Uri.parse("geo:0,0?q=" + Uri.encode(str))));
    }

    public final void getDirections(double d, double d2) {
        launchIntent(new Intent("android.intent.action.VIEW", Uri.parse("http://maps.google." + LocaleManager.getCountryTLD(this.activity) + "/maps?f=d&daddr=" + d + ',' + d2)));
    }

    public final void openProductSearch(String str) {
        launchIntent(new Intent("android.intent.action.VIEW", Uri.parse("http://www.google." + LocaleManager.getProductSearchCountryTLD(this.activity) + "/m/products?q=" + str + "&source=zxing")));
    }

    public final void openBookSearch(String str) {
        launchIntent(new Intent("android.intent.action.VIEW", Uri.parse("http://books.google." + LocaleManager.getBookSearchCountryTLD(this.activity) + "/books?vid=isbn" + str)));
    }

    public final void searchBookContents(String str) {
        Intent intent = new Intent(Intents.SearchBookContents.ACTION);
        intent.setClassName(this.activity, SearchBookContentsActivity.class.getName());
        putExtra(intent, "ISBN", str);
        launchIntent(intent);
    }

    public final void openURL(String str) {
        if (str.startsWith("HTTP://")) {
            str = "http" + str.substring(4);
        } else if (str.startsWith("HTTPS://")) {
            str = "https" + str.substring(5);
        }
        try {
            launchIntent(new Intent("android.intent.action.VIEW", Uri.parse(str)));
        } catch (Exception unused) {
            Log.e(TAG, "Nothing available to handle " + unused.toString());
        }
    }

    public final void webSearch(String str) {
        Intent intent = new Intent("android.intent.action.WEB_SEARCH");
        intent.putExtra(SearchIntents.EXTRA_QUERY, str);
        launchIntent(intent);
    }

    public final void rawLaunchIntent(Intent intent) {
        if (intent != null) {
            intent.addFlags(524288);
            this.activity.startActivity(intent);
        }
    }

    public final void launchIntent(Intent intent) {
        try {
            rawLaunchIntent(intent);
        } catch (ActivityNotFoundException unused) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this.activity);
            builder.setTitle(R.string.app_name);
            builder.setMessage(R.string.msg_intent_failed);
            builder.setPositiveButton(R.string.button_ok, null);
            builder.show();
        }
    }

    private static void putExtra(Intent intent, String str, String str2) {
        if (str2 != null && !str2.isEmpty()) {
            intent.putExtra(str, str2);
        }
    }

    private String parseCustomSearchURL() {
        return this.customProductSearch;
    }

    public final String fillInCustomSearchURL(String str) {
        if (this.customProductSearch == null) {
            return str;
        }
        try {
            str = URLEncoder.encode(str,"UTF-8");
        } catch (UnsupportedEncodingException unused) {
        }
        String str2 = this.customProductSearch;
        Result result2 = this.rawResult;
        if (result2 != null) {
            str2 = str2.replaceFirst("%f(?![0-9a-f])", result2.getBarcodeFormat().toString());
            if (str2.contains("%t")) {
                str2 = str2.replace("%t", ResultParser.parseResult(this.rawResult).getType().toString());
            }
        }
        return str2.replace("%s", str);
    }

    public static String formatPhone(String str) {
        return PhoneNumberUtils.formatNumber(str);
    }
}
