package topcreator.qrcode.barcode.scanner.reader.activities;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.adapter.BaseRecyclerAdapter;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.holder.ScanItemsHeaderHolder;
import topcreator.qrcode.barcode.scanner.reader.holder.ScanItemsHolder;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.ImageSaver;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class ScannedBarcodeItems extends AppCompatActivity {
    BaseRecyclerAdapter<ScanDataEntity, ScanItemsHolder> mAdapter;
    BaseRecyclerAdapter<String, ScanItemsHeaderHolder> mAdapterHeader;
    private TextView mEmptyTxt;
    private RecyclerView mScannedHeaderRv;
    private RecyclerView mScannedRv;
    private List<ScanDataEntity> myOptions = new ArrayList();
    private String requestType;
    ScanDatabase scanDatabase;

    public static void start(Activity activity, String str) {
        Intent intent = new Intent(activity, ScannedBarcodeItems.class);
        intent.putExtra("requestType", str);
        activity.startActivity(intent);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_scanned_barcode_items);
        this.mScannedRv = (RecyclerView) findViewById(R.id.scanned_rv);
        this.mScannedHeaderRv = (RecyclerView) findViewById(R.id.scanned_rv_header);
        this.mEmptyTxt = (TextView) findViewById(R.id.empty_txt);
        this.scanDatabase = ScanDatabase.getInstance(this);
        filterData();
        this.requestType = getIntent().getStringExtra("requestType");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyyy", Locale.ENGLISH);
        simpleDateFormat.format(new Date());
        simpleDateFormat2.format(new Date());
        simpleDateFormat3.format(new Date());
        if (this.requestType.equals(Constants.TYPE_BOOKMARK)) {
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, ScanItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getScannedBookmarkDataList());
        } else if (this.requestType.equals(Constants.TYPE_INFO)) {
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, ScanItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mScannedHeaderRv.setVisibility(0);
            this.mAdapterHeader = new BaseRecyclerAdapter<>(R.layout.scanned_items_header, ScanItemsHeaderHolder.class);
            this.mScannedHeaderRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedHeaderRv.setAdapter(this.mAdapterHeader);
            this.mAdapterHeader.setData(filterData());
        }
    }

    private List<ScanDataEntity> getScannedDataList() {
        List<ScanDataEntity> allWords = this.scanDatabase.scanDataDao().getAllWords();
        Collections.reverse(allWords);
        return allWords;
    }

    private List<ScanDataEntity> getScannedBookmarkDataList() {
        List<ScanDataEntity> bookmarkData = this.scanDatabase.scanDataDao().getBookmarkData();
        Collections.reverse(bookmarkData);
        return bookmarkData;
    }

    private List<ScanDataEntity> getScannedDataListByDay() {
        List<ScanDataEntity> dayData = this.scanDatabase.scanDataDao().getDayData();
        Collections.reverse(dayData);
        return dayData;
    }

    private List<ScanDataEntity> getScannedDataListByWeek() {
        return this.scanDatabase.scanDataDao().getWeekData();
    }

    private List<ScanDataEntity> getScannedDataListByMonth() {
        List<ScanDataEntity> monthData = this.scanDatabase.scanDataDao().getMonthData();
        Collections.reverse(monthData);
        return monthData;
    }

    private List<ScanDataEntity> getScannedDataListByYear() {
        List<ScanDataEntity> yearData = this.scanDatabase.scanDataDao().getYearData();
        Collections.reverse(yearData);
        return yearData;
    }

    private List<ScanDataEntity> getScannedDataListByDayBookmark() {
        List<ScanDataEntity> dayDataBookmark = this.scanDatabase.scanDataDao().getDayDataBookmark();
        Collections.reverse(dayDataBookmark);
        return dayDataBookmark;
    }

    private List<ScanDataEntity> getScannedDataListByWeekBookmark() {
        return this.scanDatabase.scanDataDao().getWeekDataBookmark();
    }

    private List<ScanDataEntity> getScannedDataListByMonthBookmark() {
        List<ScanDataEntity> monthDataBookmark = this.scanDatabase.scanDataDao().getMonthDataBookmark();
        Collections.reverse(monthDataBookmark);
        return monthDataBookmark;
    }

    private List<ScanDataEntity> getScannedDataListByYearBookmark() {
        List<ScanDataEntity> yearDataBookmark = this.scanDatabase.scanDataDao().getYearDataBookmark();
        Collections.reverse(yearDataBookmark);
        return yearDataBookmark;
    }

    private List<ScanDataEntity> getListFilerByType(String str) {
        List<ScanDataEntity> scannedDataList = getScannedDataList();
        ArrayList arrayList = new ArrayList();
        for (ScanDataEntity next : scannedDataList) {
            if (next.getScannedType().equals(str)) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    private List<ScanDataEntity> getNonDuplicate() {
        List<ScanDataEntity> allNonDuplicate = this.scanDatabase.scanDataDao().getAllNonDuplicate();
        Collections.reverse(allNonDuplicate);
        Iterator<ScanDataEntity> it = allNonDuplicate.iterator();
        while (it.hasNext()) {
            Log.e("DATA", "getNonDuplicate: " + it.next().getDate());
        }
        return allNonDuplicate;
    }

    private String[] splitDate(String str) {
        return str.split("-");
    }

    private String getMonth(int i) {
        return new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}[i];
    }

    private List<String> filterData() {
        List<ScanDataEntity> nonDuplicate = getNonDuplicate();
        getScannedDataList();
        ArrayList arrayList = new ArrayList();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM-yyyy", Locale.ENGLISH);
        new SimpleDateFormat("yyyy", Locale.ENGLISH);
        new SimpleDateFormat("MMM", Locale.ENGLISH);
        Calendar instance = Calendar.getInstance();
        String format = simpleDateFormat.format(instance.getTime());
        String format2 = simpleDateFormat2.format(instance.getTime());
        instance.add(5, -1);
        String format3 = simpleDateFormat.format(instance.getTime());
        for (ScanDataEntity date : nonDuplicate) {
            String date2 = date.getDate();
            if (!date2.contains(format2)) {
                if (!arrayList.contains(getMonth(Integer.parseInt(splitDate(date2)[1]) - 1) + "-" + splitDate(date2)[2])) {
                    arrayList.add(getMonth(Integer.parseInt(splitDate(date2)[1]) - 1) + "-" + splitDate(date2)[2]);
                }
            } else if (date2.equals(format)) {
                arrayList.add(Constants.DATE_TYPE_DAY);
            } else if (date2.equals(format3)) {
                arrayList.add(Constants.DATE_TYPE_YESTERDAY);
            } else {
                arrayList.add(Constants.DATE_TYPE_MONTH);
            }
        }
        return arrayList;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.remove_list, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 16908332) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return true;
        } else if (itemId != R.id.items_remove) {
            return super.onOptionsItemSelected(menuItem);
        } else {
            showDeleteDialog();
            return true;
        }
    }

    private void showDeleteDialog() {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= 21) {
            builder = new AlertDialog.Builder(this);
        } else {
            builder = new AlertDialog.Builder(this);
        }
        builder.setTitle((CharSequence) "Delete").setMessage((CharSequence) "Are you sure you want to delete?").setPositiveButton(17039379, (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public final void onClick(DialogInterface dialogInterface, int i) {
                ScannedBarcodeItems.this.clearSaveData();
            }
        }).setNegativeButton(17039369, (DialogInterface.OnClickListener) $$Lambda$ScannedBarcodeItems$09q1ZDxm0iLXoIyKm_SGBdsqixs.INSTANCE).show();
    }

    /* access modifiers changed from: private */
    public void clearSaveData() {
        this.scanDatabase.scanDataDao().deleteAll();
        new ImageSaver(this).setDirectoryName(Constants.SAVE_DIR_NAME).deleteAllFile();
        this.mAdapter.setData(getScannedDataList());
        this.mEmptyTxt.setVisibility(View.VISIBLE);
        this.mScannedRv.setVisibility(View.GONE);
        invalidateOptionsMenu();
    }

    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
