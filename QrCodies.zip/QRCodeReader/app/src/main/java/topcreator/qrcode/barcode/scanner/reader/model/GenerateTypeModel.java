package topcreator.qrcode.barcode.scanner.reader.model;

import androidx.annotation.DrawableRes;

public class GenerateTypeModel {
    private String detailTxt;
    @DrawableRes
    private int itemImage;
    private String itemTxt;

    public GenerateTypeModel(int i, String str, String str2) {
        this.itemImage = i;
        this.itemTxt = str;
        this.detailTxt = str2;
    }

    public int getItemImage() {
        return this.itemImage;
    }

    public String getItemTxt() {
        return this.itemTxt;
    }

    public String getDetailType() {
        return this.detailTxt;
    }
}
