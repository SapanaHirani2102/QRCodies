package topcreator.qrcode.barcode.scanner.reader.model;

import com.google.zxing.Result;

public class ScanDataModel {
    private Result result;
    private String scannedCode;
    private String scannedImg;
    private String scannedType;
    private String time;

    public ScanDataModel(String str, String str2, String str3, String str4, Result result2) {
        this.scannedCode = str;
        this.scannedType = str2;
        this.scannedImg = str3;
        this.result = result2;
        this.time = str4;
    }

    public Result getResult() {
        return this.result;
    }

    public ScanDataModel() {
    }

    public String getScannedCode() {
        return this.scannedCode;
    }

    public String getScannedType() {
        return this.scannedType;
    }

    public String getScannedImg() {
        return this.scannedImg;
    }

    public String getTime() {
        return this.time;
    }
}
