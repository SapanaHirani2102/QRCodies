package topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.result;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.util.Log;
import topcreator.qrcode.barcode.scanner.reader.R;
import com.google.zxing.client.result.CalendarParsedResult;
import com.google.zxing.client.result.ParsedResult;
import java.text.DateFormat;

public final class CalendarResultHandler extends ResultHandler {
    private static final String TAG = "CalendarResultHandler";

    public int getButtonCount() {
        return 0;
    }

    public int getButtonText(int i) {
        return 0;
    }

    public int getDisplayTitle() {
        return R.string.result_calendar;
    }

    public CalendarResultHandler(Activity activity, ParsedResult parsedResult) {
        super(activity, parsedResult);
    }

    public void handleButtonPress(int i) {
        String str;
        if (i == 0) {
            CalendarParsedResult calendarParsedResult = (CalendarParsedResult) getResult();
            String description = calendarParsedResult.getDescription();
            String organizer = calendarParsedResult.getOrganizer();
            if (organizer == null) {
                str = description;
            } else if (description == null) {
                str = organizer;
            } else {
                str = description + 10 + organizer;
            }
//            addCalendarEvent(calendarParsedResult.getSummary(), calendarParsedResult.getStartTimestamp(), calendarParsedResult.isStartAllDay(), calendarParsedResult.getEndTimestamp(), calendarParsedResult.getLocation(), str, calendarParsedResult.getAttendees());
        }
    }

    private void addCalendarEvent(String str, long j, boolean z, long j2, String str2, String str3, String[] strArr) {
        Intent intent = new Intent("android.intent.action.INSERT");
        intent.setType("vnd.android.cursor.item/event");
        intent.putExtra("beginTime", j);
        if (z) {
            intent.putExtra("allDay", true);
        }
        if (j2 >= 0) {
            j = j2;
        } else if (z) {
            j += 86400000;
        }
        intent.putExtra("endTime", j);
        intent.putExtra("title", str);
        intent.putExtra("eventLocation", str2);
        intent.putExtra("description", str3);
        if (strArr != null) {
            intent.putExtra("android.intent.extra.EMAIL", strArr);
        }
        try {
            rawLaunchIntent(intent);
        } catch (ActivityNotFoundException unused) {
            Log.w(TAG, "No calendar app available that responds to android.intent.action.INSERT");
            intent.setAction("android.intent.action.EDIT");
            launchIntent(intent);
        }
    }

    public CharSequence getDisplayContents() {
        CalendarParsedResult calendarParsedResult = (CalendarParsedResult) getResult();
        StringBuilder sb = new StringBuilder(100);
        ParsedResult.maybeAppend(calendarParsedResult.getSummary(), sb);
//        long startTimestamp = calendarParsedResult.getStartTimestamp();
//        ParsedResult.maybeAppend(format(calendarParsedResult.isStartAllDay(), startTimestamp), sb);
//        long endTimestamp = calendarParsedResult.getEndTimestamp();
//        if (endTimestamp >= 0) {
//            if (calendarParsedResult.isEndAllDay() && startTimestamp != endTimestamp) {
//                endTimestamp -= 86400000;
//            }
//            ParsedResult.maybeAppend(format(calendarParsedResult.isEndAllDay(), endTimestamp), sb);
//        }
        ParsedResult.maybeAppend(calendarParsedResult.getLocation(), sb);
        ParsedResult.maybeAppend(calendarParsedResult.getOrganizer(), sb);
        ParsedResult.maybeAppend(calendarParsedResult.getAttendees(), sb);
        ParsedResult.maybeAppend(calendarParsedResult.getDescription(), sb);
        return sb.toString();
    }

    private static String format(boolean z, long j) {
        DateFormat dateFormat;
        if (j < 0) {
            return null;
        }
        if (z) {
            dateFormat = DateFormat.getDateInstance(2);
        } else {
            dateFormat = DateFormat.getDateTimeInstance(2, 2);
        }
        return dateFormat.format(Long.valueOf(j));
    }
}
