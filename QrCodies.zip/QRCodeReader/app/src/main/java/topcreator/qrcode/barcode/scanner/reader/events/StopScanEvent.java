package topcreator.qrcode.barcode.scanner.reader.events;

public class StopScanEvent {
    private boolean checkStatus;

    public StopScanEvent(boolean z) {
        this.checkStatus = z;
    }

    public boolean isCheckStatus() {
        return this.checkStatus;
    }
}
