package topcreator.qrcode.barcode.scanner.reader.events;

import topcreator.qrcode.barcode.scanner.reader.model.ScanDataModel;

public class ScannedDataEvent {
    private ScanDataModel scanDataModel;

    public ScanDataModel getScanDataModel() {
        return this.scanDataModel;
    }

    public ScannedDataEvent(ScanDataModel scanDataModel2) {
        this.scanDataModel = scanDataModel2;
    }
}
