package topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.result;

import android.app.Activity;
import topcreator.qrcode.barcode.scanner.reader.R;
import com.google.zxing.client.result.ParsedResult;
import com.google.zxing.client.result.SMSParsedResult;

public final class SMSResultHandler extends ResultHandler {
    public int getButtonCount() {
        return 0;
    }

    public int getButtonText(int i) {
        return 0;
    }

    public int getDisplayTitle() {
        return R.string.result_sms;
    }

    public SMSResultHandler(Activity activity, ParsedResult parsedResult) {
        super(activity, parsedResult);
    }

    public void handleButtonPress(int i) {
        SMSParsedResult sMSParsedResult = (SMSParsedResult) getResult();
        String str = sMSParsedResult.getNumbers()[0];
        switch (i) {
            case 0:
                sendSMS(str, sMSParsedResult.getBody());
                return;
            case 1:
                sendMMS(str, sMSParsedResult.getSubject(), sMSParsedResult.getBody());
                return;
            default:
                return;
        }
    }

    public CharSequence getDisplayContents() {
        SMSParsedResult sMSParsedResult = (SMSParsedResult) getResult();
        String[] numbers = sMSParsedResult.getNumbers();
        String[] strArr = new String[numbers.length];
        for (int i = 0; i < numbers.length; i++) {
            strArr[i] = formatPhone(numbers[i]);
        }
        StringBuilder sb = new StringBuilder(50);
        ParsedResult.maybeAppend(strArr, sb);
        ParsedResult.maybeAppend(sMSParsedResult.getSubject(), sb);
        ParsedResult.maybeAppend(sMSParsedResult.getBody(), sb);
        return sb.toString();
    }
}
