package topcreator.qrcode.barcode.scanner.reader.holder;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.FragmentTransaction;

import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.database.GenerateDataEntity;
import topcreator.qrcode.barcode.scanner.reader.fragments.ScannedBarcodeInfoFragment;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.ImageSaver;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;

public class GenerateScanItemsHolder extends BaseItemHolder<GenerateDataEntity> {
    TextView scanTxt;
    TextView timeTxt;
    TinyDB tinyDB;
    String[] typeArray;
    ImageView typeImg;
    TextView typeTxt;


    public GenerateScanItemsHolder(View view) {
        super(view);
        this.typeImg = (ImageView) view.findViewById(R.id.type_img);
        this.scanTxt = (TextView) view.findViewById(R.id.scan_txt);
        this.timeTxt = (TextView) view.findViewById(R.id.time_txt);
        this.typeTxt = (TextView) view.findViewById(R.id.scan_type_txt);
        this.tinyDB = TinyDB.getInstance(view.getContext());
        this.typeArray = view.getResources().getStringArray(R.array.filter_by_type);
    }

    public void bindData(final GenerateDataEntity generateDataEntity, int i, int i2) {
        super.bindData(generateDataEntity, i, i2);
        setProductTypeImage(generateDataEntity.getScannedType());
        if (generateDataEntity.getScannedType().equals(Constants.TYPE_URI)) {
            SpannableString spannableString = new SpannableString(generateDataEntity.getScannedCode());
            spannableString.setSpan(new UnderlineSpan(), 0, spannableString.length(), 0);
            this.scanTxt.setText(spannableString);
        } else {
            this.scanTxt.setText(generateDataEntity.getScannedCode());
        }
        this.scanTxt.setSelected(true);
        this.timeTxt.setText(generateDataEntity.getTime());
        this.itemView.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                GenerateScanItemsHolder.lambda$bindData$0(GenerateScanItemsHolder.this, generateDataEntity, view);
            }
        });
    }

    public static /* synthetic */ void lambda$bindData$0(GenerateScanItemsHolder generateScanItemsHolder, GenerateDataEntity generateDataEntity, View view) {
        TinyDB tinyDB2 = generateScanItemsHolder.tinyDB;
        tinyDB2.putInt(Constants.ADS_COUNT, tinyDB2.getInt(Constants.ADS_COUNT) + 1);
        Bundle bundle = new Bundle();
        bundle.putString(Constants.SCANNED_TYPE, generateDataEntity.getScannedType());
        bundle.putString(Constants.SCANNED_TXT, generateDataEntity.getScannedCode());
        bundle.putString(Constants.SCANNED_TIME, generateDataEntity.getTime());
        bundle.putString(Constants.GENERATE_SQL_DATE, generateDataEntity.getSqlDate());
        bundle.putString(Constants.GENERATE_TYPE, "GenerateItem");
        bundle.putString(Constants.CUSTOM_QR_PATH, generateDataEntity.getGenerateImgPath());
        ScannedBarcodeInfoFragment scannedBarcodeInfoFragment = new ScannedBarcodeInfoFragment();
        scannedBarcodeInfoFragment.setArguments(bundle);
        FragmentTransaction beginTransaction = ((MainActivity) generateScanItemsHolder.itemView.getContext()).getSupportFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.fragment_layout, scannedBarcodeInfoFragment);
        beginTransaction.commitAllowingStateLoss();
    }

    private Bitmap getImage(Context context, String str) {
        return new ImageSaver(context).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(str).load();
    }

    private void setProductTypeImage(String str) {
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_add);
            this.typeTxt.setText(this.typeArray[8]);
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_cal1);
            this.typeTxt.setText(this.typeArray[9]);
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_email);
            this.typeTxt.setText(this.typeArray[7]);
        } else if (Constants.TYPE_GEO.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_loc);
            this.typeTxt.setText(this.typeArray[11]);
        } else if ("ISBN".equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_isbn);
            this.typeTxt.setText(this.typeArray[10]);
        } else if (Constants.TYPE_PRODUCT.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_product);
            this.typeTxt.setText(this.typeArray[1]);
        } else if (Constants.TYPE_SMS.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_msgs);
            this.typeTxt.setText(this.typeArray[6]);
        } else if (Constants.TYPE_TEL.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_call);
            this.typeTxt.setText(this.typeArray[4]);
        } else if (Constants.TYPE_TEXT.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_text);
            this.typeTxt.setText(this.typeArray[5]);
        } else if (Constants.TYPE_URI.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_url);
            this.typeTxt.setText(this.typeArray[2]);
        } else if (Constants.TYPE_WIFI.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_wifi);
            this.typeTxt.setText(this.typeArray[3]);
        }
    }
}
