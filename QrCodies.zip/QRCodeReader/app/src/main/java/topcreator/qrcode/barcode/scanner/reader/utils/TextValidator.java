package topcreator.qrcode.barcode.scanner.reader.utils;

import android.view.View;
import android.widget.EditText;

public abstract class TextValidator implements View.OnFocusChangeListener {
    private final EditText textView;

    public abstract void validate(EditText editText, String str, boolean z);

    public TextValidator(EditText editText) {
        this.textView = editText;
    }

    public void onFocusChange(View view, boolean z) {
        validate(this.textView, this.textView.getText().toString(), z);
    }
}
