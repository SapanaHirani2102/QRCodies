package topcreator.qrcode.barcode.scanner.reader.events;

import topcreator.qrcode.barcode.scanner.reader.model.AdvanceQrModel;

public class AdvanceQrEvent {
    private AdvanceQrModel advanceQrModel;


    public AdvanceQrEvent(AdvanceQrModel advanceQrModel2) {
        this.advanceQrModel = advanceQrModel2;
    }
    public AdvanceQrModel getAdvanceQrModel() {
        return this.advanceQrModel;
    }

}
