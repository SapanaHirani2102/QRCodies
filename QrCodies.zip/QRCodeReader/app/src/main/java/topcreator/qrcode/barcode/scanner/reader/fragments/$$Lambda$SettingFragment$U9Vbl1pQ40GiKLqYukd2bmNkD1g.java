package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.content.DialogInterface;

/* renamed from: topcreator.qrcode.barcode.scanner.reader.fragments.-$$Lambda$SettingFragment$U9Vbl1pQ40GiKLqYukd2bmNkD1g  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$SettingFragment$U9Vbl1pQ40GiKLqYukd2bmNkD1g implements DialogInterface.OnClickListener {
    public static final /* synthetic */ $$Lambda$SettingFragment$U9Vbl1pQ40GiKLqYukd2bmNkD1g INSTANCE = new $$Lambda$SettingFragment$U9Vbl1pQ40GiKLqYukd2bmNkD1g();

    private /* synthetic */ $$Lambda$SettingFragment$U9Vbl1pQ40GiKLqYukd2bmNkD1g() {
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();
    }
}
