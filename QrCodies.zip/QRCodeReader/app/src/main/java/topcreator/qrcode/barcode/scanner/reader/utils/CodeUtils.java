package topcreator.qrcode.barcode.scanner.reader.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.TextPaint;
import android.text.TextUtils;
import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.core.view.ViewCompat;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.util.HashMap;
import java.util.Map;

public class CodeUtils {
    private CodeUtils() {
        throw new AssertionError();
    }

    public static Bitmap createQRCode(String str, int i) {
        return createQRCode(str, i, null);
    }

    public static Bitmap createQRCode(String str, int i, Bitmap bitmap) {
        HashMap hashMap = new HashMap();
        hashMap.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hashMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        hashMap.put(EncodeHintType.MARGIN, 1);
        return createQRCode(str, i, bitmap, hashMap);
    }

    public static Bitmap createQRCode(String str, int i, Bitmap bitmap, Map<EncodeHintType, ?> map) {
        try {
            BitMatrix encode = new QRCodeWriter().encode(str, BarcodeFormat.DATA_MATRIX, i, i, map);
            int[] iArr = new int[(i * i)];
            for (int i2 = 0; i2 < i; i2++) {
                for (int i3 = 0; i3 < i; i3++) {
                    if (encode.get(i3, i2)) {
                        iArr[(i2 * i) + i3] = -16777216;
                    } else {
                        iArr[(i2 * i) + i3] = -1;
                    }
                }
            }
            Bitmap createBitmap = Bitmap.createBitmap(i, i, Bitmap.Config.ARGB_8888);
            createBitmap.setPixels(iArr, 0, i, 0, 0, i, i);
            if (bitmap != null) {
                createBitmap = addLogo(createBitmap, bitmap);
            }
            return createBitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Bitmap addLogo(Bitmap bitmap, Bitmap bitmap2) {
        Bitmap bitmap3 = null;
        if (bitmap == null) {
            return null;
        }
        if (bitmap2 == null) {
            return bitmap;
        }
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int width2 = bitmap2.getWidth();
        int height2 = bitmap2.getHeight();
        if (width == 0 || height == 0) {
            return null;
        }
        if (width2 == 0 || height2 == 0) {
            return bitmap;
        }
        float f = ((((float) width) * 2.0f) / 6.0f) / ((float) width2);
        Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        try {
            Canvas canvas = new Canvas(createBitmap);
            canvas.drawBitmap(bitmap, 0.0f, 0.0f, null);
            canvas.scale(f, f, (float) (width / 2), (float) (height / 2));
            canvas.drawBitmap(bitmap2, (float) ((width - width2) / 2), (float) ((height - height2) / 2), null);
            canvas.save();
            canvas.restore();
            bitmap3 = createBitmap;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap3;
    }

    public static String parseQRCode(String str) {
        HashMap hashMap = new HashMap();
        hashMap.put(DecodeHintType.CHARACTER_SET, "utf-8");
        return parseQRCode(str, hashMap);
    }

    public static String parseQRCode(String str, Map<DecodeHintType, ?> map) {
        try {
            return new QRCodeReader().decode(getBinaryBitmap(compressBitmap(str)), map).getText();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String parseCode(String str, Map<DecodeHintType, Object> map) {
        try {
            MultiFormatReader multiFormatReader = new MultiFormatReader();
            multiFormatReader.setHints(map);
            return multiFormatReader.decodeWithState(getBinaryBitmap(compressBitmap(str))).getText();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static Bitmap compressBitmap(String str) {
        int i;
        BitmapFactory.Options options = new BitmapFactory.Options();
        int i2 = 1;
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(str, options);
        int i3 = options.outWidth;
        int i4 = options.outHeight;
        if (i3 <= i4 || ((float) i3) <= 800.0f) {
            i = (i3 >= i4 || ((float) i4) <= 480.0f) ? 1 : (int) (((float) options.outHeight) / 480.0f);
        } else {
            i = (int) (((float) options.outWidth) / 800.0f);
        }
        if (i > 0) {
            i2 = i;
        }
        options.inSampleSize = i2;
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(str, options);
    }

    private static BinaryBitmap getBinaryBitmap(@NonNull Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] iArr = new int[(width * height)];
        bitmap.getPixels(iArr, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
        return new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(width, height, iArr)));
    }

    public static Bitmap createBarCode(String str, BarcodeFormat barcodeFormat, int i, int i2) {
        try {
            return createBarCode(str, barcodeFormat, i, i2, null);
        } catch (WriterException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Bitmap createAdvanceQrCode(String str, BarcodeFormat barcodeFormat, int i, int i2, int i3, int i4, int i5, Bitmap bitmap) {
        return createAdvanceBarCode(str, barcodeFormat, i, i2, null, false, 40, ViewCompat.MEASURED_STATE_MASK, i3, i4, i5, bitmap);
    }

    public static Bitmap createBarCode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map<EncodeHintType, ?> map) throws WriterException {
        return createBarCode(str, barcodeFormat, i, i2, map, false, 40, ViewCompat.MEASURED_STATE_MASK);
    }

    public static Bitmap createBarCode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map<EncodeHintType, ?> map, boolean z) throws WriterException {
        return createBarCode(str, barcodeFormat, i, i2, map, z, 40, ViewCompat.MEASURED_STATE_MASK);
    }

    public static Bitmap createBarCode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map<EncodeHintType, ?> map, boolean z, int i3, @ColorInt int i4) throws WriterException {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        BitMatrix encode = new MultiFormatWriter().encode(str, barcodeFormat, i, i2, map);
        int width = encode.getWidth();
        int height = encode.getHeight();
        int[] iArr = new int[(width * height)];
        for (int i5 = 0; i5 < height; i5++) {
            int i6 = i5 * width;
            for (int i7 = 0; i7 < width; i7++) {
                iArr[i6 + i7] = encode.get(i7, i5) ? ViewCompat.MEASURED_STATE_MASK : -1;
            }
        }
        Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        createBitmap.setPixels(iArr, 0, width, 0, 0, width, height);
        return z ? addCode(createBitmap, str, i3, i4, i3 / 2) : createBitmap;
    }

    public static Bitmap createAdvanceBarCode(String str, BarcodeFormat barcodeFormat, int i, int i2, Map<EncodeHintType, ?> map, boolean z, int i3, @ColorInt int i4, int i5, int i6, int i7, Bitmap bitmap) {
        int i8 = i3;
        int i9 = i5;
        int i10 = i6;
        Bitmap bitmap2 = bitmap;
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        try {
            BitMatrix encode = new MultiFormatWriter().encode(str, barcodeFormat, i, i2, map);
            int width = encode.getWidth();
            int height = encode.getHeight();
            int[] iArr = new int[(width * height)];
            for (int i11 = 0; i11 < height; i11++) {
                int i12 = i11 * width;
                if (i9 != -1 || i10 == -1) {
                    int i13 = i7;
                } else {
                    int i14 = i7;
                    if (i14 != -1) {
                        if (i11 > height / 2) {
                            for (int i15 = 0; i15 < width; i15++) {
                                iArr[i12 + i15] = encode.get(i15, i11) ? i14 : -1;
                            }
                        } else {
                            for (int i16 = 0; i16 < width; i16++) {
                                iArr[i12 + i16] = encode.get(i16, i11) ? i10 : -1;
                            }
                        }
                    }
                }
                if (i9 != -1) {
                    for (int i17 = 0; i17 < width; i17++) {
                        iArr[i12 + i17] = encode.get(i17, i11) ? ViewCompat.MEASURED_STATE_MASK : -1;
                    }
                } else if (i10 != -1) {
                    for (int i18 = 0; i18 < width; i18++) {
                        iArr[i12 + i18] = encode.get(i18, i11) ? i10 : -1;
                    }
                }
            }
            Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            createBitmap.setPixels(iArr, 0, width, 0, 0, width, height);
            if (z) {
                return addCode(createBitmap, str, i8, i4, i8 / 2);
            }
            if (bitmap2 != null) {
                createBitmap = addLogo(createBitmap, bitmap2);
            }
            return createBitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static Bitmap addCode(Bitmap bitmap, String str, int i, @ColorInt int i2, int i3) {
        Bitmap bitmap2 = null;
        if (bitmap == null) {
            return null;
        }
        if (TextUtils.isEmpty(str)) {
            return bitmap;
        }
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        if (width <= 0 || height <= 0) {
            return null;
        }
        Bitmap createBitmap = Bitmap.createBitmap(width, height + i + (i3 * 2), Bitmap.Config.ARGB_8888);
        try {
            Canvas canvas = new Canvas(createBitmap);
            canvas.drawBitmap(bitmap, 0.0f, 0.0f, null);
            TextPaint textPaint = new TextPaint();
            textPaint.setTextSize((float) i);
            textPaint.setColor(i2);
            textPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText(str, (float) (width / 2), (float) (height + (i / 2) + i3), textPaint);
            canvas.save();
            canvas.restore();
            bitmap2 = createBitmap;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap2;
    }
}
