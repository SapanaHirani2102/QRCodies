package topcreator.qrcode.barcode.scanner.reader.activities;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.ItemTouchHelper;

import com.ironsource.mediationsdk.IronSource;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.ScannedResultManager;
import topcreator.qrcode.barcode.scanner.reader.database.GenerateDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.splashexit.BaseSplashActivity;
import topcreator.qrcode.barcode.scanner.reader.utils.CodeUtils;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.ImageSaver;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.google.zxing.client.result.ParsedResult;
import com.google.zxing.client.result.ResultParser;
import com.nabinbhandari.android.permissions.PermissionHandler;
import com.nabinbhandari.android.permissions.Permissions;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;

public class GenerateResultActivity extends BaseSplashActivity {
    private String TAG = "GenerateResult";
    SimpleDateFormat fd = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
    private GenerateDataEntity generateDataEntity;
    private TextView mBottomBtn;
    private RelativeLayout mCopyLayout;
    private ImageView mGenerateBarcodeImg;
    private TextView mGenerateBtn;
    private ImageView mGenerateQRImg;
    private TextView mScannedText;
    private RelativeLayout mShareLayout;
    private ParsedResult parsedResult;
    Bitmap saveBitmap;
    private ScanDatabase scanDatabase;
    ScannedResultManager scannedResultManager;
    private Bundle bundleExtra;

    public static void start(Activity activity, Bundle bundle) {
        Intent intent = new Intent(activity, GenerateResultActivity.class);
        intent.putExtra(Constants.GENERATE_INFO, bundle);
        activity.startActivity(intent);

//        ((AdvanceQrActivity) activity).showInter(intent, 0,
//                AppCommon.AD_FB, AppCommon.AD_ADMOB, AppCommon.AD_APP_NEXT);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_generate_result);
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());

        statusBarSet();
        initView();
        this.scanDatabase = ScanDatabase.getInstance(this);
        this.scannedResultManager = new ScannedResultManager(this);
        bundleExtra = getIntent().getBundleExtra(Constants.GENERATE_INFO);
        if (bundleExtra != null) {
            String string = bundleExtra.getString(Constants.FILTER_TYPE);
            if (string != null) {
                showResultData(string, bundleExtra);
            } else {
                showHistoryResultData(bundleExtra.getString(Constants.SCANNED_TYPE), bundleExtra);
            }
        }
        this.mGenerateBtn.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                GenerateResultActivity.lambda$onCreate$0(GenerateResultActivity.this, bundleExtra, view);
            }
        });
        this.mCopyLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                GenerateResultActivity.lambda$onCreate$1(GenerateResultActivity.this, view);
            }
        });
        this.mShareLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                Permissions.check((Context) GenerateResultActivity.this, "android.permission.WRITE_EXTERNAL_STORAGE", (String) null, (PermissionHandler) new PermissionHandler() {
                    public void onGranted() {
                        new ImageSaver(GenerateResultActivity.this).setFileName("image1.jpg").setDirectoryName(Constants.SAVE_DIR_NAME).setExternal(true).save(GenerateResultActivity.this.saveBitmap);
                        File filePath = new ImageSaver(GenerateResultActivity.this).setFileName("image1.jpg").setDirectoryName(Constants.SAVE_DIR_NAME).setExternal(true).getFilePath();
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(filePath);
                        GenerateResultActivity generateResultActivity = GenerateResultActivity.this;
                        generateResultActivity.shareMultiple(arrayList, generateResultActivity);
                    }
                });
            }
        });
        this.mBottomBtn.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                GenerateResultActivity.lambda$onCreate$3(GenerateResultActivity.this, view);
            }
        });
    }

    public static void setWindowFlag(Activity activity, int i, boolean z) {
        Window window = activity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags = i | attributes.flags;
        } else {
            attributes.flags = (i ^ -1) & attributes.flags;
        }
        window.setAttributes(attributes);
    }

    private void statusBarSet() {
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, 67108864, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(1280);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, 67108864, false);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_bar_color));
        }
    }


    public static /* synthetic */ void lambda$onCreate$0(GenerateResultActivity generateResultActivity, Bundle bundle, View view) {
        Bitmap bitmap;

        if (bundle == null) {
            return;
        }
        if (bundle.getString(Constants.SCANNED_TYPE) != null) {
            Intent intent = new Intent(generateResultActivity, MainActivity.class);
            intent.addFlags(603979776);
            generateResultActivity.startActivity(intent);
        } else if (generateResultActivity.generateDataEntity != null) {
            String string = bundle.getString(Constants.FILTER_TYPE);
            if ("ISBN".equals(string) || Constants.TYPE_PRODUCT.equals(string)) {
                bitmap = loadBitmapFromView(generateResultActivity.mGenerateBarcodeImg);
            } else {
                bitmap = loadBitmapFromView(generateResultActivity.mGenerateQRImg);
            }
            long currentTimeMillis = System.currentTimeMillis();
            String str = "custom-image-" + currentTimeMillis + ".jpg";
            ImageSaver imageSaver = new ImageSaver(generateResultActivity);
            imageSaver.setFileName(str).setDirectoryName(Constants.SAVE_DIR_NAME).save(bitmap);
            generateResultActivity.generateDataEntity.setGenerateImgPath(imageSaver.getFilePath().getAbsolutePath());
            generateResultActivity.insertDatabase(generateResultActivity.generateDataEntity);
        }
    }

    public static /* synthetic */ void lambda$onCreate$1(GenerateResultActivity generateResultActivity, View view) {
        ClipboardManager clipboardManager = (ClipboardManager) generateResultActivity.getSystemService("clipboard");
        ClipData newPlainText = ClipData.newPlainText("label", generateResultActivity.mScannedText.getText());
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(newPlainText);
            Toast makeText = Toast.makeText(generateResultActivity.getApplicationContext(), "Copied to clipboard", 0);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        }
    }

    public static /* synthetic */ void lambda$onCreate$3(GenerateResultActivity generateResultActivity, View view) {
        Intent intent = new Intent(generateResultActivity, MainActivity.class);
        intent.addFlags(603979776);
        generateResultActivity.startActivity(intent);
    }

    /* access modifiers changed from: private */
    public void shareMultiple(List<File> list, Context context) {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND_MULTIPLE");
        intent.putExtra("android.intent.extra.SUBJECT", "Here are some files.");
        intent.setType("image/*");
        ArrayList arrayList = new ArrayList();
        for (File absolutePath : list) {
            arrayList.add(Uri.fromFile(new File(absolutePath.getAbsolutePath())));
        }
        intent.putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList);
        context.startActivity(intent);
    }

    public static Bitmap loadBitmapFromView(View view) {
        Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        view.draw(new Canvas(createBitmap));
        return createBitmap;
    }

    private void initView() {
        this.mGenerateBtn = (TextView) findViewById(R.id.generate_btn);
        this.mBottomBtn = (TextView) findViewById(R.id.bottom_btn);
        this.mGenerateBarcodeImg = (ImageView) findViewById(R.id.generate_barcode_img);
        this.mGenerateQRImg = (ImageView) findViewById(R.id.generate_qr_img);
        this.mScannedText = (TextView) findViewById(R.id.scanned_text);
        this.mCopyLayout = (RelativeLayout) findViewById(R.id.copy_layout);
        this.mShareLayout = (RelativeLayout) findViewById(R.id.share_layout);
    }

    private void showResultData(String str, Bundle bundle) {
        String str2;
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            String string = bundle.getString(Constants.GENERATE_URL_NAME);
            this.parsedResult = ResultParser.parseResult(new Result(string, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.scannedResultManager.addressResultContent(this.parsedResult));
            byte[] byteArray = bundle.getByteArray("customQr");
            Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
            this.saveBitmap = decodeByteArray;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(decodeByteArray);
            long currentTimeMillis = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string, str, String.valueOf(currentTimeMillis), this.fd.format(Long.valueOf(currentTimeMillis)));
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            bundle.getString(Constants.GENERATE_URL_NAME);
            String string2 = bundle.getString(Constants.GENERATE_URL_LINK);
            this.parsedResult = ResultParser.parseResult(new Result(string2, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.scannedResultManager.addressResultContent(this.parsedResult));
            Bitmap createBarCode = CodeUtils.createBarCode(string2, BarcodeFormat.QR_CODE, 500, 500);
            this.saveBitmap = createBarCode;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(createBarCode);
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            String string3 = bundle.getString(Constants.GENERATE_URL_NAME);
            String string4 = bundle.getString(Constants.GENERATE_URL_LINK);
            String string5 = bundle.getString(Constants.GENERATE_EMAIL_LINK);
            String str3 = "MATMSG:TO:" + string3 + ";SUB:" + string5 + ";BODY:" + string4 + ";;";
            this.parsedResult = ResultParser.parseResult(new Result(str3, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            byte[] byteArray2 = bundle.getByteArray("customQr");
            Bitmap decodeByteArray2 = BitmapFactory.decodeByteArray(byteArray2, 0, byteArray2.length);
            this.saveBitmap = decodeByteArray2;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(decodeByteArray2);
            long currentTimeMillis2 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(str3, str, String.valueOf(currentTimeMillis2), this.fd.format(Long.valueOf(currentTimeMillis2)));
        } else if (Constants.TYPE_GEO.equals(str)) {
            String string6 = bundle.getString(Constants.GENERATE_URL_NAME);
            String string7 = bundle.getString(Constants.GENERATE_URL_LINK);
            String str4 = "geo:" + string6 + "," + string7;
            this.parsedResult = ResultParser.parseResult(new Result(str4, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            byte[] byteArray3 = bundle.getByteArray("customQr");
            Bitmap decodeByteArray3 = BitmapFactory.decodeByteArray(byteArray3, 0, byteArray3.length);
            this.saveBitmap = decodeByteArray3;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(decodeByteArray3);
            long currentTimeMillis3 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(str4, str, String.valueOf(currentTimeMillis3), this.fd.format(Long.valueOf(currentTimeMillis3)));
        } else if ("ISBN".equals(str)) {
            bundle.getString(Constants.GENERATE_URL_NAME);
            String string8 = bundle.getString(Constants.GENERATE_URL_LINK);
            this.parsedResult = ResultParser.parseResult(new Result(string8, null, null, BarcodeFormat.EAN_13));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode2 = CodeUtils.createBarCode(string8, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            this.saveBitmap = createBarCode2;
            this.mGenerateBarcodeImg.setVisibility(View.VISIBLE);
            this.mGenerateBarcodeImg.setImageBitmap(createBarCode2);
            long currentTimeMillis4 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string8, str, String.valueOf(currentTimeMillis4), this.fd.format(Long.valueOf(currentTimeMillis4)));
        } else if (Constants.TYPE_PRODUCT.equals(str)) {
            bundle.getString(Constants.GENERATE_URL_NAME);
            String string9 = bundle.getString(Constants.GENERATE_URL_LINK);
            this.parsedResult = ResultParser.parseResult(new Result(string9, null, null, BarcodeFormat.EAN_13));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode3 = CodeUtils.createBarCode(string9, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            this.saveBitmap = createBarCode3;
            this.mGenerateBarcodeImg.setVisibility(View.VISIBLE);
            this.mGenerateBarcodeImg.setImageBitmap(createBarCode3);
            long currentTimeMillis5 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string9, str, String.valueOf(currentTimeMillis5), this.fd.format(Long.valueOf(currentTimeMillis5)));
        } else if (Constants.TYPE_SMS.equals(str)) {
            String string10 = bundle.getString(Constants.GENERATE_URL_NAME);
            String string11 = bundle.getString(Constants.GENERATE_URL_LINK);
            String str5 = "smsto:" + string10 + ":" + string11;
            this.parsedResult = ResultParser.parseResult(new Result(str5, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.scannedResultManager.smsResultContent(this.parsedResult));
            byte[] byteArray4 = bundle.getByteArray("customQr");
            Bitmap decodeByteArray4 = BitmapFactory.decodeByteArray(byteArray4, 0, byteArray4.length);
            this.saveBitmap = decodeByteArray4;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(decodeByteArray4);
            long currentTimeMillis6 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(str5, str, String.valueOf(currentTimeMillis6), this.fd.format(Long.valueOf(currentTimeMillis6)));
        } else if (Constants.TYPE_TEL.equals(str)) {
            String string12 = bundle.getString(Constants.GENERATE_URL_NAME);
            bundle.getString(Constants.GENERATE_URL_LINK);
            String str6 = "tel:" + string12;
            this.parsedResult = ResultParser.parseResult(new Result(str6, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.scannedResultManager.telResultContent(this.parsedResult));
            byte[] byteArray5 = bundle.getByteArray("customQr");
            Bitmap decodeByteArray5 = BitmapFactory.decodeByteArray(byteArray5, 0, byteArray5.length);
            this.saveBitmap = decodeByteArray5;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(decodeByteArray5);
            long currentTimeMillis7 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(str6, str, String.valueOf(currentTimeMillis7), this.fd.format(Long.valueOf(currentTimeMillis7)));
        } else if (Constants.TYPE_TEXT.equals(str)) {
            bundle.getString(Constants.GENERATE_URL_NAME);
            String string13 = bundle.getString(Constants.GENERATE_URL_LINK);
            this.parsedResult = ResultParser.parseResult(new Result(string13, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            byte[] byteArray6 = bundle.getByteArray("customQr");
            Bitmap decodeByteArray6 = BitmapFactory.decodeByteArray(byteArray6, 0, byteArray6.length);
            this.saveBitmap = decodeByteArray6;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(decodeByteArray6);
            long currentTimeMillis8 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string13, str, String.valueOf(currentTimeMillis8), this.fd.format(Long.valueOf(currentTimeMillis8)));
        } else if (Constants.TYPE_URI.equals(str)) {
            bundle.getString(Constants.GENERATE_URL_NAME);
            String string14 = bundle.getString(Constants.GENERATE_URL_LINK);
            if (string14 == null) {
                string14 = "http://www.example.com";
            } else if (!string14.toLowerCase().contains("http")) {
                string14 = "http://" + string14;
            }
            this.parsedResult = ResultParser.parseResult(new Result(string14, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            byte[] byteArray7 = bundle.getByteArray("customQr");
            Bitmap decodeByteArray7 = BitmapFactory.decodeByteArray(byteArray7, 0, byteArray7.length);
            this.saveBitmap = decodeByteArray7;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(decodeByteArray7);
            long currentTimeMillis9 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string14, str, String.valueOf(currentTimeMillis9), this.fd.format(Long.valueOf(currentTimeMillis9)));
        } else if (Constants.TYPE_WIFI.equals(str)) {
            String string15 = bundle.getString(Constants.GENERATE_URL_NAME);
            String string16 = bundle.getString(Constants.GENERATE_URL_LINK);
            String string17 = bundle.getString(Constants.GENERATE_WIFI_NET);
            if (string17.equals("WPA/WPA2")) {
                string17 = "WPA";
            }
            String string18 = bundle.getString(Constants.GENERATE_WIFI_HIDE);
            if (string17.equals("non")) {
                if (string18.equals("true")) {
                    str2 = "WIFI:S:" + string15 + ";P:" + string16 + ";H:" + string18 + ";;";
                } else {
                    str2 = "WIFI:S:" + string15 + ";P:" + string16 + ";;";
                }
            } else if (string18.equals("true")) {
                str2 = "WIFI:S:" + string15 + ";T:" + string17 + ";P:" + string16 + ";H:" + string18 + ";;";
            } else {
                str2 = "WIFI:S:" + string15 + ";T:" + string17 + ";P:" + string16 + ";;";
            }
            this.parsedResult = ResultParser.parseResult(new Result(str2, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.scannedResultManager.wifiResultContent(this.parsedResult));
            byte[] byteArray8 = bundle.getByteArray("customQr");
            Bitmap decodeByteArray8 = BitmapFactory.decodeByteArray(byteArray8, 0, byteArray8.length);
            this.saveBitmap = decodeByteArray8;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(decodeByteArray8);
            long currentTimeMillis10 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(str2, str, String.valueOf(currentTimeMillis10), this.fd.format(Long.valueOf(currentTimeMillis10)));
        }
    }

    private void showHistoryResultData(String str, Bundle bundle) {
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            String string = bundle.getString(Constants.SCANNED_TXT);
            this.parsedResult = ResultParser.parseResult(new Result(string, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.scannedResultManager.addressResultContent(this.parsedResult));
            Bitmap createBarCode = CodeUtils.createBarCode(string, BarcodeFormat.QR_CODE, 500, 500);
            this.saveBitmap = createBarCode;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(createBarCode);
            long currentTimeMillis = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string, str, String.valueOf(currentTimeMillis), this.fd.format(Long.valueOf(currentTimeMillis)));
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            bundle.getString(Constants.GENERATE_URL_NAME);
            String string2 = bundle.getString(Constants.GENERATE_URL_LINK);
            this.parsedResult = ResultParser.parseResult(new Result(string2, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.scannedResultManager.addressResultContent(this.parsedResult));
            Bitmap createBarCode2 = CodeUtils.createBarCode(string2, BarcodeFormat.QR_CODE, 500, 500);
            this.saveBitmap = createBarCode2;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(createBarCode2);
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            String string3 = bundle.getString(Constants.SCANNED_TXT);
            this.parsedResult = ResultParser.parseResult(new Result(string3, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode3 = CodeUtils.createBarCode(string3, BarcodeFormat.QR_CODE, 500, 500);
            this.saveBitmap = createBarCode3;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(createBarCode3);
            long currentTimeMillis2 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string3, str, String.valueOf(currentTimeMillis2), this.fd.format(Long.valueOf(currentTimeMillis2)));
        } else if (Constants.TYPE_GEO.equals(str)) {
            String string4 = bundle.getString(Constants.SCANNED_TXT);
            this.parsedResult = ResultParser.parseResult(new Result(string4, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode4 = CodeUtils.createBarCode(string4, BarcodeFormat.QR_CODE, 500, 500);
            this.saveBitmap = createBarCode4;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(createBarCode4);
            long currentTimeMillis3 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string4, str, String.valueOf(currentTimeMillis3), this.fd.format(Long.valueOf(currentTimeMillis3)));
        } else if ("ISBN".equals(str)) {
            String string5 = bundle.getString(Constants.SCANNED_TXT);
            this.parsedResult = ResultParser.parseResult(new Result(string5, null, null, BarcodeFormat.EAN_13));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode5 = CodeUtils.createBarCode(string5, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            this.saveBitmap = createBarCode5;
            this.mGenerateBarcodeImg.setVisibility(View.VISIBLE);
            this.mGenerateBarcodeImg.setImageBitmap(createBarCode5);
            long currentTimeMillis4 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string5, str, String.valueOf(currentTimeMillis4), this.fd.format(Long.valueOf(currentTimeMillis4)));
        } else if (Constants.TYPE_PRODUCT.equals(str)) {
            String string6 = bundle.getString(Constants.SCANNED_TXT);
            this.parsedResult = ResultParser.parseResult(new Result(string6, null, null, BarcodeFormat.EAN_13));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode6 = CodeUtils.createBarCode(string6, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            this.saveBitmap = createBarCode6;
            this.mGenerateBarcodeImg.setVisibility(View.VISIBLE);
            this.mGenerateBarcodeImg.setImageBitmap(createBarCode6);
            long currentTimeMillis5 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string6, str, String.valueOf(currentTimeMillis5), this.fd.format(Long.valueOf(currentTimeMillis5)));
        } else if (Constants.TYPE_SMS.equals(str)) {
            String string7 = bundle.getString(Constants.SCANNED_TXT);
            this.parsedResult = ResultParser.parseResult(new Result(string7, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.scannedResultManager.smsResultContent(this.parsedResult));
            Bitmap createBarCode7 = CodeUtils.createBarCode(string7, BarcodeFormat.QR_CODE, 500, 500);
            this.saveBitmap = createBarCode7;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(createBarCode7);
            long currentTimeMillis6 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string7, str, String.valueOf(currentTimeMillis6), this.fd.format(Long.valueOf(currentTimeMillis6)));
        } else if (Constants.TYPE_TEL.equals(str)) {
            String string8 = bundle.getString(Constants.SCANNED_TXT);
            this.parsedResult = ResultParser.parseResult(new Result(string8, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.scannedResultManager.telResultContent(this.parsedResult));
            Bitmap createBarCode8 = CodeUtils.createBarCode(string8, BarcodeFormat.QR_CODE, 500, 500);
            this.saveBitmap = createBarCode8;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(createBarCode8);
            long currentTimeMillis7 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string8, str, String.valueOf(currentTimeMillis7), this.fd.format(Long.valueOf(currentTimeMillis7)));
        } else if (Constants.TYPE_TEXT.equals(str)) {
            String string9 = bundle.getString(Constants.SCANNED_TXT);
            this.parsedResult = ResultParser.parseResult(new Result(string9, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode9 = CodeUtils.createBarCode(string9, BarcodeFormat.QR_CODE, 500, 500);
            this.saveBitmap = createBarCode9;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(createBarCode9);
            long currentTimeMillis8 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string9, str, String.valueOf(currentTimeMillis8), this.fd.format(Long.valueOf(currentTimeMillis8)));
        } else if (Constants.TYPE_URI.equals(str)) {
            String string10 = bundle.getString(Constants.SCANNED_TXT);
            this.parsedResult = ResultParser.parseResult(new Result(string10, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode10 = CodeUtils.createBarCode(string10, BarcodeFormat.QR_CODE, 500, 500);
            this.saveBitmap = createBarCode10;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(createBarCode10);
            long currentTimeMillis9 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string10, str, String.valueOf(currentTimeMillis9), this.fd.format(Long.valueOf(currentTimeMillis9)));
        } else if (Constants.TYPE_WIFI.equals(str)) {
            String string11 = bundle.getString(Constants.SCANNED_TXT);
            this.parsedResult = ResultParser.parseResult(new Result(string11, null, null, BarcodeFormat.QR_CODE));
            this.mScannedText.setText(this.scannedResultManager.wifiResultContent(this.parsedResult));
            Bitmap createBarCode11 = CodeUtils.createBarCode(string11, BarcodeFormat.QR_CODE, 500, 500);
            this.saveBitmap = createBarCode11;
            this.mGenerateQRImg.setVisibility(View.VISIBLE);
            this.mGenerateQRImg.setImageBitmap(createBarCode11);
            long currentTimeMillis10 = System.currentTimeMillis();
            this.generateDataEntity = new GenerateDataEntity(string11, str, String.valueOf(currentTimeMillis10), this.fd.format(Long.valueOf(currentTimeMillis10)));
        }
    }

//    private void insertDatabase(final GenerateDataEntity generateDataEntity2) {
//        Single.fromCallable(new Callable<Object>() {
//            public final Object call() {
//                return scanDatabase.scanDataDao().insert(generateDataEntity2);
//            }
//        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer() {
//            public final void accept(Object obj) {
//                GenerateResultActivity.lambda$insertDatabase$5(GenerateResultActivity.this, (Boolean) obj);
//            }
//        }, new Consumer() {
//            public final void accept(Object obj) {
//                GenerateResultActivity.lambda$insertDatabase$6(GenerateResultActivity.this, (Throwable) obj);
//            }
//        });
//
//    }

    private void insertDatabase(final GenerateDataEntity generateDataEntity2) {
        Single.fromCallable(new Callable() {
            public final Object call() {
                GenerateResultActivity.this.scanDatabase.scanDataDao().insert(generateDataEntity2);
                return generateDataEntity2;
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer() {
            public final void accept(Object obj) {
                GenerateResultActivity.lambda$insertDatabase$5(GenerateResultActivity.this);
            }
        }, new Consumer() {
            public final void accept(Object obj) {
                GenerateResultActivity.lambda$insertDatabase$6(GenerateResultActivity.this, (Throwable) obj);
            }
        });
    }

    public static /* synthetic */ void lambda$insertDatabase$5(GenerateResultActivity generateResultActivity) {
        String str = generateResultActivity.TAG;
//        Log.e(str, "Data Inserted: " + bool);
        Toast makeText = Toast.makeText(generateResultActivity.getApplicationContext(), "Generated code saved", 0);
        makeText.setGravity(17, 0, 0);
        makeText.show();
        Intent intent = new Intent(generateResultActivity, MainActivity.class);
        intent.addFlags(603979776);
        generateResultActivity.startActivity(intent);
        if (IronSource.isInterstitialReady()) {
            //show the interstitial
            IronSource.showInterstitial();
        }
    }

    public static /* synthetic */ void lambda$insertDatabase$6(GenerateResultActivity generateResultActivity, Throwable th) {
        String str = generateResultActivity.TAG;
        Log.e(str, "Generate Result: " + th.getMessage());
    }


    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(603979776);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        IronSource.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        IronSource.onPause(this);
    }
}
