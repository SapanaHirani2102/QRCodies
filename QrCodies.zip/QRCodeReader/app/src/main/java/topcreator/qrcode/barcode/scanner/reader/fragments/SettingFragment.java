package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Switch;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.splashexit.Splash_Activity;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.ImageSaver;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;

public class SettingFragment extends Fragment {
    private Activity activity;
    private Switch mCopySwitch;
    private RelativeLayout mGeneralDelete;
    private RelativeLayout mGeneralTell;
    private Switch mSaveHistorySwitch;
    private Switch mSoundSwitch;
    private Switch mVibrationSwitch;
    private Switch mWebSwitch;
    private ScanDatabase scanDatabase;
    TinyDB tinyDB;
    private FrameLayout adMobView;

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (Activity) context;
        }
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_settings, viewGroup, false);
        this.activity.getWindow().clearFlags(1024);

        adMobView = (FrameLayout) inflate.findViewById(R.id.adMobView);
        showBanner();

        this.tinyDB = TinyDB.getInstance(this.activity);
        this.mVibrationSwitch = (Switch) inflate.findViewById(R.id.vibration_switch);
        this.mSaveHistorySwitch = (Switch) inflate.findViewById(R.id.save_history_switch);
        this.mGeneralTell = (RelativeLayout) inflate.findViewById(R.id.general_tell);
        this.mCopySwitch = (Switch) inflate.findViewById(R.id.copy_switch);
        this.mSoundSwitch = (Switch) inflate.findViewById(R.id.sound_switch);
        this.mGeneralDelete = (RelativeLayout) inflate.findViewById(R.id.general_delete);
        this.mWebSwitch = (Switch) inflate.findViewById(R.id.web_switch);
        this.tinyDB = TinyDB.getInstance(this.activity);
        this.scanDatabase = ScanDatabase.getInstance(this.activity);
        if (this.tinyDB.getBoolean(Constants.SETTING_VIBRATION)) {
            this.mVibrationSwitch.setChecked(true);
        } else {
            this.mVibrationSwitch.setChecked(false);
        }
        if (this.tinyDB.getBoolean(Constants.SETTING_SOUND)) {
            this.mSoundSwitch.setChecked(true);
        } else {
            this.mSoundSwitch.setChecked(false);
        }
        if (this.tinyDB.getBoolean(Constants.SETTING_AUTO_COPY)) {
            this.mCopySwitch.setChecked(true);
        } else {
            this.mCopySwitch.setChecked(false);
        }
        if (this.tinyDB.getBoolean(Constants.SETTING_WEB_SEARCH)) {
            this.mWebSwitch.setChecked(true);
        } else {
            this.mWebSwitch.setChecked(false);
        }
        if (this.tinyDB.getBoolean(Constants.SETTING_HISTORY)) {
            this.mSaveHistorySwitch.setChecked(true);
        } else {
            this.mSaveHistorySwitch.setChecked(false);
        }
        this.mGeneralDelete.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SettingFragment.this.showDeleteDialog();
            }
        });
        this.mGeneralTell.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SettingFragment.this.ShareText("https://play.google.com/store/apps/details?id=" + SettingFragment.this.activity.getPackageName());
            }
        });
        this.mVibrationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                SettingFragment.lambda$onCreateView$4(SettingFragment.this, compoundButton, z);
            }
        });
        this.mSoundSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                SettingFragment.lambda$onCreateView$5(SettingFragment.this, compoundButton, z);
            }
        });
        this.mCopySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                SettingFragment.lambda$onCreateView$6(SettingFragment.this, compoundButton, z);
            }
        });
        this.mWebSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                SettingFragment.lambda$onCreateView$7(SettingFragment.this, compoundButton, z);
            }
        });
        this.mSaveHistorySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                SettingFragment.lambda$onCreateView$8(SettingFragment.this, compoundButton, z);
            }
        });
        return inflate;
    }


    public static /* synthetic */ void lambda$onCreateView$4(SettingFragment settingFragment, CompoundButton compoundButton, boolean z) {
        if (z) {
            settingFragment.vibration();
            settingFragment.tinyDB.putBoolean(Constants.SETTING_VIBRATION, true);
            return;
        }
        settingFragment.tinyDB.putBoolean(Constants.SETTING_VIBRATION, false);
    }

    public static /* synthetic */ void lambda$onCreateView$5(SettingFragment settingFragment, CompoundButton compoundButton, boolean z) {
        if (z) {
            settingFragment.tinyDB.putBoolean(Constants.SETTING_SOUND, true);
        } else {
            settingFragment.tinyDB.putBoolean(Constants.SETTING_SOUND, false);
        }
    }

    public static /* synthetic */ void lambda$onCreateView$6(SettingFragment settingFragment, CompoundButton compoundButton, boolean z) {
        if (z) {
            settingFragment.tinyDB.putBoolean(Constants.SETTING_AUTO_COPY, true);
        } else {
            settingFragment.tinyDB.putBoolean(Constants.SETTING_AUTO_COPY, false);
        }
    }

    public static /* synthetic */ void lambda$onCreateView$7(SettingFragment settingFragment, CompoundButton compoundButton, boolean z) {
        if (z) {
            settingFragment.tinyDB.putBoolean(Constants.SETTING_WEB_SEARCH, true);
        } else {
            settingFragment.tinyDB.putBoolean(Constants.SETTING_WEB_SEARCH, false);
        }
    }

    public static /* synthetic */ void lambda$onCreateView$8(SettingFragment settingFragment, CompoundButton compoundButton, boolean z) {
        if (z) {
            settingFragment.tinyDB.putBoolean(Constants.SETTING_HISTORY, true);
        } else {
            settingFragment.tinyDB.putBoolean(Constants.SETTING_HISTORY, false);
        }
    }

    /* access modifiers changed from: private */
    public void showDeleteDialog() {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= 21) {
            builder = new AlertDialog.Builder(this.activity);
        } else {
            builder = new AlertDialog.Builder(this.activity);
        }
        builder.setTitle((CharSequence) "Delete").setMessage((CharSequence) "Are you sure you want to Delete all History?").setPositiveButton(17039379, (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public final void onClick(DialogInterface dialogInterface, int i) {
                SettingFragment.this.clearSaveData();
            }
        }).setNegativeButton(17039369, (DialogInterface.OnClickListener) $$Lambda$SettingFragment$U9Vbl1pQ40GiKLqYukd2bmNkD1g.INSTANCE).show();
    }

    /* access modifiers changed from: private */
    public void ShareText(String str) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT", str);
        this.activity.startActivity(Intent.createChooser(intent, "Share via"));
    }

    /* access modifiers changed from: private */
    public void clearSaveData() {
        this.scanDatabase.scanDataDao().deleteAll();
        this.scanDatabase.scanDataDao().deleteAllBookmark();
        this.scanDatabase.scanDataDao().deleteAllGenerate();
        this.scanDatabase.scanDataDao().deleteAllBookmarkGenerate();
        this.scanDatabase.scanDataDao().deleteAllCard();
        new ImageSaver(this.activity).setDirectoryName(Constants.SAVE_DIR_NAME).deleteAllFile();
    }

    private void vibration() {
        Vibrator vibrator = (Vibrator) this.activity.getSystemService("vibrator");
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(500, -1));
        } else {
            vibrator.vibrate(500);
        }
    }

    public void onDestroy() {
        super.onDestroy();

    }

    private void showBanner() {
        final AdView mAdView = new AdView(getActivity());
        mAdView.setAdSize(getAdSize());
        mAdView.setAdUnitId(Splash_Activity.adModel.getAdMobBanner());
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                if (adMobView != null) {
                    adMobView.removeAllViews();
                }
                adMobView.addView(mAdView);
            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        if (adMobView != null) {
            adMobView.removeAllViews();
        }
    }

    private com.google.android.gms.ads.AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = getActivity().getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(getActivity(), adWidth);
    }
}
