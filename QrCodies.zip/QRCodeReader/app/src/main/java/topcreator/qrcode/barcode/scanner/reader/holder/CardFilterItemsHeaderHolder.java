package topcreator.qrcode.barcode.scanner.reader.holder;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.adapter.BaseRecyclerAdapter;
import topcreator.qrcode.barcode.scanner.reader.database.CardDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CardFilterItemsHeaderHolder extends BaseItemHolder<String> {
    BaseRecyclerAdapter<CardDataEntity, GenerateScanItemsHolder> mAdapter;
    private RecyclerView mScannedRv;
    String month;
    ScanDatabase scanDatabase;
    TextView timeTxt;
    TinyDB tinyDB;
    String year;

    public CardFilterItemsHeaderHolder(View view) {
        super(view);
        this.timeTxt = (TextView) view.findViewById(R.id.time_line_txt_header);
        this.mScannedRv = (RecyclerView) view.findViewById(R.id.items_recycler_view);
        this.scanDatabase = ScanDatabase.getInstance(view.getContext());
        this.tinyDB = TinyDB.getInstance(view.getContext());
    }

    public void bindData(String str, int i, int i2) {
        super.bindData(str, i, i2);
        String string = this.tinyDB.getString(Constants.FILTER_TYPE_SP);
        if (str.equals(Constants.DATE_TYPE_DAY)) {
            this.timeTxt.setVisibility(View.VISIBLE);
            this.timeTxt.setText(str);
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, CardItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getTodayScannedDataList(string));
        } else if (str.equals(Constants.DATE_TYPE_MONTH)) {
            this.timeTxt.setVisibility(View.VISIBLE);
            this.timeTxt.setText(str);
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, CardItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getMonthScannedDataList(string));
        } else if (str.equals(Constants.DATE_TYPE_YESTERDAY)) {
            this.timeTxt.setVisibility(View.VISIBLE);
            this.timeTxt.setText(str);
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, CardItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getYesterdayScannedDataList(string));
        } else if (str.equals(Constants.DATE_TYPE_WEEK)) {
            this.timeTxt.setVisibility(View.VISIBLE);
            this.timeTxt.setText(str);
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, CardItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getWeekScannedDataList(string));
        } else {
            this.timeTxt.setVisibility(View.VISIBLE);
            this.timeTxt.setText(str);
            String[] splitDate = splitDate(str);
            if (splitDate.length > 1) {
                int monthIndex = getMonthIndex(splitDate[0]);
                if (monthIndex <= 9) {
                    this.month = "0" + monthIndex;
                } else {
                    this.month = String.valueOf(monthIndex);
                }
                this.year = splitDate[1];
            }
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, GenerateScanItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getScannedDataList(this.month, this.year, string));
        }
        if (i + 1 == i2) {
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMargins(0, 0, 0, 100);
            this.itemView.setLayoutParams(layoutParams);
        }
    }

    private int getMonthIndex(String str) {
        try {
            Date parse = new SimpleDateFormat("MMM", Locale.ENGLISH).parse(str);
            Calendar instance = Calendar.getInstance();
            instance.setTime(parse);
            return instance.get(2) + 1;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    private String[] splitDate(String str) {
        return str.split("-");
    }

    private List<CardDataEntity> getScannedDataList(String str, String str2, String str3) {
        List<CardDataEntity> cardGenericFilerDataList = this.scanDatabase.scanDataDao().getCardGenericFilerDataList(str, str2, str3);
        Collections.reverse(cardGenericFilerDataList);
        return cardGenericFilerDataList;
    }

    private List<CardDataEntity> getTodayScannedDataList(String str) {
        List<CardDataEntity> cardDayFilterData = this.scanDatabase.scanDataDao().getCardDayFilterData(str);
        Collections.reverse(cardDayFilterData);
        return cardDayFilterData;
    }

    private List<CardDataEntity> getMonthScannedDataList(String str) {
        return this.scanDatabase.scanDataDao().getCardMonthFilterData(str);
    }

    private List<CardDataEntity> getYesterdayScannedDataList(String str) {
        List<CardDataEntity> cardYesterdayFilterDataList = this.scanDatabase.scanDataDao().getCardYesterdayFilterDataList(str);
        Collections.reverse(cardYesterdayFilterDataList);
        return cardYesterdayFilterDataList;
    }

    private List<CardDataEntity> getWeekScannedDataList(String str) {
        return this.scanDatabase.scanDataDao().getCardWeekData(str);
    }
}
