package topcreator.qrcode.barcode.scanner.reader.model;

public class BarcodeSelectFilterItemModel {
    String type;

    public BarcodeSelectFilterItemModel(String str) {
        this.type = str;
    }

    public String getType() {
        return this.type;
    }
}
