package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.util.Log;
import io.reactivex.functions.Consumer;

/* renamed from: topcreator.qrcode.barcode.scanner.reader.fragments.-$$Lambda$ScannedBarcodeInfoFragment$Dy4Cm_81MNquMfaR76g5iCV26_A  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$ScannedBarcodeInfoFragment$Dy4Cm_81MNquMfaR76g5iCV26_A implements Consumer {
    public static final /* synthetic */ $$Lambda$ScannedBarcodeInfoFragment$Dy4Cm_81MNquMfaR76g5iCV26_A INSTANCE = new $$Lambda$ScannedBarcodeInfoFragment$Dy4Cm_81MNquMfaR76g5iCV26_A();

    private /* synthetic */ $$Lambda$ScannedBarcodeInfoFragment$Dy4Cm_81MNquMfaR76g5iCV26_A() {
    }

    public final void accept(Object obj) {
        Log.e("Data Inserted", "barcodeResult: " + ((Throwable) obj).getMessage());
    }
}
