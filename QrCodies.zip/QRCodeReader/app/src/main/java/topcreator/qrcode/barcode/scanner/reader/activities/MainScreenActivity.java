package topcreator.qrcode.barcode.scanner.reader.activities;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.splashexit.Splash_Activity;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;


public class MainScreenActivity extends AppCompatActivity {
    private ClickType clickType = ClickType.NONE;
    private LinearLayout mBusinessLayout;
    private LinearLayout mGenerateLayout;
    private LinearLayout mHistoryLayout;
    private LinearLayout mScanLayout;
    boolean ad = true;
    private FrameLayout adMobView;
    private InterstitialAd mInterstitialAdMob;

    public enum ClickType {
        SCAN,
        GENERATE,
        CARD,
        HISTORY,
        NONE
    }

    public static void setWindowFlag(Activity activity, int i, boolean z) {
        Window window = activity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags = i | attributes.flags;
        } else {
            attributes.flags = (i ^ -1) & attributes.flags;
        }
        window.setAttributes(attributes);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main_update);
        statusBarSet();
        initView();

        initAdmobFullAd(this);
        loadAdmobAd();

        adMobView = (FrameLayout) findViewById(R.id.adMobView);
        showBanner();

        this.mGenerateLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainScreenActivity.lambda$onCreate$0(MainScreenActivity.this, view);
            }
        });
        this.mBusinessLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainScreenActivity.lambda$onCreate$1(MainScreenActivity.this, view);
            }
        });
        this.mHistoryLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainScreenActivity.lambda$onCreate$2(MainScreenActivity.this, view);
            }
        });
        this.mScanLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainScreenActivity.lambda$onCreate$3(MainScreenActivity.this, view);
            }
        });
    }

    public static /* synthetic */ void lambda$onCreate$0(MainScreenActivity mainScreenActivity, View view) {
        Intent intent2 = new Intent(mainScreenActivity, MainActivity.class);
        intent2.putExtra(Constants.MAIN_FRAG_TYPE, 2);
        mainScreenActivity.showad(intent2);
    }

    public static /* synthetic */ void lambda$onCreate$1(MainScreenActivity mainScreenActivity, View view) {
        Intent intent2 = new Intent(mainScreenActivity, MainActivity.class);
        intent2.putExtra(Constants.MAIN_FRAG_TYPE, 3);
        mainScreenActivity.showad(intent2);

    }

    public static /* synthetic */ void lambda$onCreate$2(MainScreenActivity mainScreenActivity, View view) {
        Intent intent2 = new Intent(mainScreenActivity, MainActivity.class);
        intent2.putExtra(Constants.MAIN_FRAG_TYPE, 4);
        mainScreenActivity.showad(intent2);
    }

    public static /* synthetic */ void lambda$onCreate$3(MainScreenActivity mainScreenActivity, View view) {
        Intent intent2 = new Intent(mainScreenActivity, MainActivity.class);
        intent2.putExtra(Constants.MAIN_FRAG_TYPE, 1);
        mainScreenActivity.startActivity(intent2);
    }

    private void initView() {
        this.mHistoryLayout = (LinearLayout) findViewById(R.id.history_layout);
        this.mBusinessLayout = (LinearLayout) findViewById(R.id.business_layout);
        this.mGenerateLayout = (LinearLayout) findViewById(R.id.generate_layout);
        this.mScanLayout = (LinearLayout) findViewById(R.id.scan_layout);
    }

    private void statusBarSet() {
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, 67108864, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(1280);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, 67108864, false);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_bar_color));
        }
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        finish();
    }

    public void onActivityResult(int i, int i2, @Nullable Intent intent) {
        super.onActivityResult(i, i2, intent);
    }

    public void showad(Intent intent) {
        if (ad) {
            ad = false;
            if (Splash_Activity.adModel.getIsAdmobEnable() == 1 && isAdmobLoaded()) {
                startActivity(intent);
                showAdmobInterstitial();
            }
        } else {
            ad = true;
            startActivity(intent);
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }

    public void initAdmobFullAd(Context context) {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            return;
        }
        mInterstitialAdMob = new com.google.android.gms.ads.InterstitialAd(context);
        mInterstitialAdMob.setAdUnitId(Splash_Activity.adModel.getAdMobInter());
        mInterstitialAdMob.setAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdClosed() {
                loadAdmobAd();
            }

            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdOpened() {
                //   super.onAdOpened();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }

            @Override
            public void onAdLeftApplication() {
                super.onAdLeftApplication();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
            }
        });
    }

    public void loadAdmobAd() {
        if (mInterstitialAdMob != null && !mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
        }
    }

    public void showAdmobInterstitial() {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.show();
        }
    }

    private boolean isAdmobLoaded() {
        if (mInterstitialAdMob != null) {
            return mInterstitialAdMob.isLoaded();
        } else {
            return false;
        }
    }

    private void showBanner() {
        final AdView mAdView = new AdView(this);
        mAdView.setAdSize(getAdSize());
        mAdView.setAdUnitId(Splash_Activity.adModel.getAdMobBanner());
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                if (adMobView != null) {
                    adMobView.removeAllViews();
                }
                adMobView.addView(mAdView);
            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        if (adMobView != null) {
            adMobView.removeAllViews();
        }
    }

    private com.google.android.gms.ads.AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }
}
