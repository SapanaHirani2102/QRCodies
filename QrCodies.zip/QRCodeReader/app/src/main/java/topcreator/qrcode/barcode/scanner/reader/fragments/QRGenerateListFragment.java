package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.GenerateInfoActivity;
import topcreator.qrcode.barcode.scanner.reader.adapter.BaseRecyclerAdapterFilter;
import topcreator.qrcode.barcode.scanner.reader.holder.BaseItemHolder;
import topcreator.qrcode.barcode.scanner.reader.holder.GenerateTypeFilterHolder;
import topcreator.qrcode.barcode.scanner.reader.model.GenerateTypeModel;
import topcreator.qrcode.barcode.scanner.reader.model.SelectFilterItemModel;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import java.util.ArrayList;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class QRGenerateListFragment extends Fragment {
    private Activity activity;
    private BaseRecyclerAdapterFilter<GenerateTypeModel, BaseItemHolder> mAdapterHeader;
    private RecyclerView mGenerateListRv;
    private String[] typeTxt;

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (Activity) context;
        }
    }

    public View onCreateView(@NonNull LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.fragment_generate_list, viewGroup, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle bundle) {
        this.mGenerateListRv = (RecyclerView) view.findViewById(R.id.generate_list_rv);
        this.typeTxt = this.activity.getResources().getStringArray(R.array.filter_by_type);
        this.mAdapterHeader = new BaseRecyclerAdapterFilter<>(R.layout.scanned_items, GenerateTypeFilterHolder.class);
        this.mGenerateListRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
        this.mGenerateListRv.setAdapter(this.mAdapterHeader);
        this.mAdapterHeader.setData(getTypeData());
    }

    private List<GenerateTypeModel> getTypeData() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new GenerateTypeModel(R.drawable.i_url, this.typeTxt[2], Constants.TYPE_URI));
        arrayList.add(new GenerateTypeModel(R.drawable.i_text, this.typeTxt[5], Constants.TYPE_TEXT));
        arrayList.add(new GenerateTypeModel(R.drawable.i_msgs, this.typeTxt[6], Constants.TYPE_SMS));
        arrayList.add(new GenerateTypeModel(R.drawable.i_wifi, this.typeTxt[3], Constants.TYPE_WIFI));
        arrayList.add(new GenerateTypeModel(R.drawable.i_call, this.typeTxt[4], Constants.TYPE_TEL));
        arrayList.add(new GenerateTypeModel(R.drawable.i_email, this.typeTxt[7], Constants.TYPE_EMAIL_ADDRESS));
        arrayList.add(new GenerateTypeModel(R.drawable.i_add, this.typeTxt[8], Constants.TYPE_ADDRESSBOOK));
        arrayList.add(new GenerateTypeModel(R.drawable.i_loc, this.typeTxt[11], Constants.TYPE_GEO));
        return arrayList;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(SelectFilterItemModel selectFilterItemModel) {
        Bundle bundle = new Bundle();
        bundle.putString(Constants.FILTER_TYPE, selectFilterItemModel.getType());

        GenerateInfoActivity.start(this.activity, bundle);
    }

    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    public void onDestroy() {
        super.onDestroy();
        this.mGenerateListRv.setAdapter(null);
    }
}
