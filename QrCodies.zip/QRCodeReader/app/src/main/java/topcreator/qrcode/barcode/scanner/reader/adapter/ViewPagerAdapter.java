package topcreator.qrcode.barcode.scanner.reader.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import java.util.ArrayList;
import java.util.List;

public class ViewPagerAdapter extends FragmentPagerAdapter {
    private final List<String> mFragmentTitles = new ArrayList();
    private final List<Fragment> mFragments = new ArrayList();

    public ViewPagerAdapter(FragmentManager fragmentManager) {
        super(fragmentManager);
    }

    public void addFragment(Fragment fragment, String str) {
        this.mFragments.add(fragment);
        this.mFragmentTitles.add(str);
    }

    @NonNull
    public Fragment getItem(int i) {
        return this.mFragments.get(i);
    }

    public int getCount() {
        return this.mFragments.size();
    }

    public CharSequence getPageTitle(int i) {
        return this.mFragmentTitles.get(i);
    }

    public void removeAll() {
        this.mFragments.clear();
        this.mFragmentTitles.clear();
    }
}
