package topcreator.qrcode.barcode.scanner.reader.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import topcreator.qrcode.barcode.scanner.reader.R;
import im.delight.android.webview.AdvancedWebView;
import topcreator.qrcode.barcode.scanner.reader.splashexit.Splash_Activity;

public class WebviewActivity extends AppCompatActivity implements AdvancedWebView.Listener {
    boolean isPrivacy = false;
    private ImageView mHistoryBackImg;
    private ProgressBar mPolicyProBar;
    private TextView mTitleTxt;
    AdvancedWebView mWebView;

    public void onDownloadRequested(String str, String str2, String str3, long j, String str4, String str5) {
    }

    public void onExternalPageRequest(String str) {
    }

    public void onPageError(int i, String str, String str2) {
    }

    public void onPageStarted(String str, Bitmap bitmap) {
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_webview);
        statusBarSet();
        this.mPolicyProBar = (ProgressBar) findViewById(R.id.policy_pro_bar);
        this.mTitleTxt = (TextView) findViewById(R.id.title_txt);
        this.mWebView = (AdvancedWebView) findViewById(R.id.webview);
        this.mWebView.setListener((Activity) this, (AdvancedWebView.Listener) this);
        this.mHistoryBackImg = (ImageView) findViewById(R.id.history_back_img);
        this.mTitleTxt.setSelected(true);
        Intent intent = getIntent();
        if (intent != null) {
            if (intent.getStringExtra("SEARCH_URL") != null) {
                this.mWebView.loadUrl(intent.getStringExtra("SEARCH_URL"));
                this.mTitleTxt.setText(intent.getStringExtra("SEARCH_URL"));
                this.isPrivacy = false;
            } else {
                this.mWebView.loadUrl(Splash_Activity.adModel.getPrivacy());
                this.mTitleTxt.setText("Privacy Policy");
                this.isPrivacy = true;
            }
        }
        this.mHistoryBackImg.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                WebviewActivity.this.finish();
            }
        });
    }

    public static void setWindowFlag(Activity activity, int i, boolean z) {
        Window window = activity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags = i | attributes.flags;
        } else {
            attributes.flags = (i ^ -1) & attributes.flags;
        }
        window.setAttributes(attributes);
    }

    private void statusBarSet() {
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, 67108864, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(1280);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, 67108864, false);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_bar_color));
        }
    }

    public void onPageFinished(String str) {
        this.mPolicyProBar.setVisibility(View.GONE);
    }

    /* access modifiers changed from: protected */
    @SuppressLint({"NewApi"})
    public void onResume() {
        super.onResume();
        this.mWebView.onResume();
    }

    /* access modifiers changed from: protected */
    @SuppressLint({"NewApi"})
    public void onPause() {
        this.mWebView.onPause();
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        this.mWebView.onDestroy();
        super.onDestroy();
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        this.mWebView.onActivityResult(i, i2, intent);
    }

    public void onBackPressed() {
        if (this.mWebView.onBackPressed()) {
            super.onBackPressed();
        }
    }
}
