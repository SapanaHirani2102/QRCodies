package topcreator.qrcode.barcode.scanner.reader.model;

public class AdvanceQrStyleModel {
    private int style;

    public AdvanceQrStyleModel(int i) {
        this.style = i;
    }

    public int getStyle() {
        return this.style;
    }
}
