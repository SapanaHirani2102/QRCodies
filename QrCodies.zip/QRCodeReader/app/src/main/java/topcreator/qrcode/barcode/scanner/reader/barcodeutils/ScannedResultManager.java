package topcreator.qrcode.barcode.scanner.reader.barcodeutils;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.util.Log;
import android.widget.Toast;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.result.FinalResultsHandler;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.wifi.WifiConfigManager;
import com.google.zxing.client.result.AddressBookParsedResult;
import com.google.zxing.client.result.CalendarParsedResult;
import com.google.zxing.client.result.EmailAddressParsedResult;
import com.google.zxing.client.result.ExpandedProductParsedResult;
import com.google.zxing.client.result.GeoParsedResult;
import com.google.zxing.client.result.ISBNParsedResult;
import com.google.zxing.client.result.ParsedResult;
import com.google.zxing.client.result.ProductParsedResult;
import com.google.zxing.client.result.SMSParsedResult;
import com.google.zxing.client.result.TelParsedResult;
import com.google.zxing.client.result.URIParsedResult;
import com.google.zxing.client.result.WifiParsedResult;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class ScannedResultManager {
    private static final DateFormat[] DATE_FORMATS = {new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH), new SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.ENGLISH), new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH), new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ENGLISH)};
    private static final String TAG = "Log:";
    private Activity context;
    private FinalResultsHandler finalResultsHandler;

    public ScannedResultManager(Activity activity) {
        this.context = activity;
        this.finalResultsHandler = new FinalResultsHandler(activity);
    }

    private String getProductIDFromResult(ParsedResult parsedResult) {
        if (parsedResult instanceof ProductParsedResult) {
            return ((ProductParsedResult) parsedResult).getNormalizedProductID();
        }
        if (parsedResult instanceof ExpandedProductParsedResult) {
            return ((ExpandedProductParsedResult) parsedResult).getRawText();
        }
        throw new IllegalArgumentException(parsedResult.getClass().toString());
    }

    private long parseDate(String str) {
        DateFormat[] dateFormatArr = DATE_FORMATS;
        int i = 0;
        while (i < dateFormatArr.length) {
            try {
                return dateFormatArr[i].parse(str).getTime();
            } catch (ParseException unused) {
                i++;
            }
        }
        return -1;
    }

    private String format(boolean z, long j) {
        DateFormat dateFormat;
        if (j < 0) {
            return null;
        }
        if (z) {
            dateFormat = DateFormat.getDateInstance(2);
        } else {
            dateFormat = DateFormat.getDateTimeInstance(2, 2);
        }
        return dateFormat.format(Long.valueOf(j));
    }

    public void wifiResult(ParsedResult parsedResult) {
        WifiParsedResult wifiParsedResult = (WifiParsedResult) parsedResult;
        WifiManager wifiManager = (WifiManager) this.context.getApplicationContext().getSystemService("wifi");
        if (wifiManager == null) {
            Log.w(TAG, "No WifiManager available from device");
            return;
        }
        Activity activity = this.context;
        final Toast makeText = Toast.makeText(activity.getApplicationContext(), "Connecting", 0);
        makeText.setGravity(17, 0, 0);
        activity.runOnUiThread(new Runnable() {
            public final void run() {
                makeText.show();
            }
        });
        new WifiConfigManager(wifiManager).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new WifiParsedResult[]{wifiParsedResult});
    }

    public void addressBookResult(ParsedResult parsedResult, int i) {
        AddressBookParsedResult addressBookParsedResult = (AddressBookParsedResult) parsedResult;
        String[] addresses = addressBookParsedResult.getAddresses();
        String str = null;
        String str2 = (addresses == null || addresses.length < 1) ? null : addresses[0];
        String[] addressTypes = addressBookParsedResult.getAddressTypes();
        if (addressTypes != null && addressTypes.length >= 1) {
            str = addressTypes[0];
        }
        String str3 = str;
        switch (i) {
            case 0:
                this.finalResultsHandler.addContact(addressBookParsedResult.getNames(), addressBookParsedResult.getNicknames(), addressBookParsedResult.getPronunciation(), addressBookParsedResult.getPhoneNumbers(), addressBookParsedResult.getPhoneTypes(), addressBookParsedResult.getEmails(), addressBookParsedResult.getEmailTypes(), addressBookParsedResult.getNote(), addressBookParsedResult.getInstantMessenger(), str2, str3, addressBookParsedResult.getOrg(), addressBookParsedResult.getTitle(), addressBookParsedResult.getURLs(), addressBookParsedResult.getBirthday(), addressBookParsedResult.getGeo());
                return;
            case 1:
                this.finalResultsHandler.searchMap(str2);
                return;
            case 2:
                this.finalResultsHandler.dialPhone(addressBookParsedResult.getPhoneNumbers()[0]);
                return;
            case 3:
                this.finalResultsHandler.sendEmail(addressBookParsedResult.getEmails(), null, null, null, null);
                return;
            default:
                return;
        }
    }

    public void calenderResult(ParsedResult parsedResult) {
        String str;
        CalendarParsedResult calendarParsedResult = (CalendarParsedResult) parsedResult;
        String description = calendarParsedResult.getDescription();
        String organizer = calendarParsedResult.getOrganizer();
        if (organizer == null) {
            str = description;
        } else if (description == null) {
            str = organizer;
        } else {
            str = description + 10 + organizer;
        }
        addCalendarEvent(calendarParsedResult.getSummary(), calendarParsedResult.getStartTimestamp(), calendarParsedResult.isStartAllDay(), calendarParsedResult.getEndTimestamp(), calendarParsedResult.getLocation(), str, calendarParsedResult.getAttendees());
    }

    private void addCalendarEvent(String str, long j, boolean z, long j2, String str2, String str3, String[] strArr) {
        Intent intent = new Intent("android.intent.action.INSERT");
        intent.setType("vnd.android.cursor.item/event");
        intent.putExtra("beginTime", j);
        if (z) {
            intent.putExtra("allDay", true);
        }
        if (j2 >= 0) {
            j = j2;
        } else if (z) {
            j += 86400000;
        }
        intent.putExtra("endTime", j);
        intent.putExtra("title", str);
        intent.putExtra("eventLocation", str2);
        intent.putExtra("description", str3);
        if (strArr != null) {
            intent.putExtra("android.intent.extra.EMAIL", strArr);
        }
        try {
            this.finalResultsHandler.rawLaunchIntent(intent);
        } catch (ActivityNotFoundException unused) {
            Log.w(TAG, "No calendar app available that responds to android.intent.action.INSERT");
            intent.setAction("android.intent.action.EDIT");
            this.finalResultsHandler.launchIntent(intent);
        }
    }

    public void emailResult(ParsedResult parsedResult, int i) {
        EmailAddressParsedResult emailAddressParsedResult = (EmailAddressParsedResult) parsedResult;
        switch (i) {
            case 0:
                this.finalResultsHandler.sendEmail(emailAddressParsedResult.getTos(), emailAddressParsedResult.getCCs(), emailAddressParsedResult.getBCCs(), emailAddressParsedResult.getSubject(), emailAddressParsedResult.getBody());
                return;
            case 1:
                this.finalResultsHandler.addEmailOnlyContact(emailAddressParsedResult.getTos(), null);
                return;
            default:
                return;
        }
    }

    public void geoResult(ParsedResult parsedResult, int i) {
        GeoParsedResult geoParsedResult = (GeoParsedResult) parsedResult;
        switch (i) {
            case 0:
                this.finalResultsHandler.openMap(geoParsedResult.getGeoURI());
                return;
            case 1:
                this.finalResultsHandler.getDirections(geoParsedResult.getLatitude(), geoParsedResult.getLongitude());
                return;
            default:
                return;
        }
    }

    public void isbnResult(ParsedResult parsedResult, int i) {
        ISBNParsedResult iSBNParsedResult = (ISBNParsedResult) parsedResult;
        switch (i) {
            case 0:
                this.finalResultsHandler.openProductSearch(iSBNParsedResult.getISBN());
                return;
            case 1:
                this.finalResultsHandler.openBookSearch(iSBNParsedResult.getISBN());
                return;
            case 2:
                FinalResultsHandler finalResultsHandler2 = this.finalResultsHandler;
                finalResultsHandler2.openURL(finalResultsHandler2.fillInCustomSearchURL(iSBNParsedResult.getISBN()));
                return;
            default:
                return;
        }
    }

    public void productResult(ParsedResult parsedResult, int i) {
        String productIDFromResult = getProductIDFromResult(parsedResult);
        switch (i) {
            case 0:
                this.finalResultsHandler.openProductSearch(productIDFromResult);
                return;
            case 1:
                this.finalResultsHandler.webSearch(productIDFromResult);
                return;
            case 2:
                FinalResultsHandler finalResultsHandler2 = this.finalResultsHandler;
                finalResultsHandler2.openURL(finalResultsHandler2.fillInCustomSearchURL(productIDFromResult));
                return;
            default:
                return;
        }
    }

    public void smsResult(ParsedResult parsedResult, int i) {
        SMSParsedResult sMSParsedResult = (SMSParsedResult) parsedResult;
        String str = sMSParsedResult.getNumbers()[0];
        switch (i) {
            case 0:
                this.finalResultsHandler.sendSMS(str, sMSParsedResult.getBody());
                return;
            case 1:
                this.finalResultsHandler.sendMMS(str, sMSParsedResult.getSubject(), sMSParsedResult.getBody());
                return;
            default:
                return;
        }
    }

    public void contactResult(ParsedResult parsedResult, int i) {
        TelParsedResult telParsedResult = (TelParsedResult) parsedResult;
        switch (i) {
            case 0:
                this.finalResultsHandler.dialPhoneFromUri(telParsedResult.getTelURI());
                return;
            case 1:
                this.finalResultsHandler.addPhoneOnlyContact(new String[]{telParsedResult.getNumber()}, null);
                return;
            default:
                return;
        }
    }

    public void textResult(ParsedResult parsedResult, int i) {
        String displayResult = parsedResult.getDisplayResult();
        switch (i) {
            case 0:
                this.finalResultsHandler.webSearch(displayResult);
                return;
            case 1:
                this.finalResultsHandler.shareByEmail(displayResult);
                return;
            case 2:
                this.finalResultsHandler.shareBySMS(displayResult);
                return;
            case 3:
                FinalResultsHandler finalResultsHandler2 = this.finalResultsHandler;
                finalResultsHandler2.openURL(finalResultsHandler2.fillInCustomSearchURL(displayResult));
                return;
            default:
                return;
        }
    }

    public void urlResult(ParsedResult parsedResult, int i) {
        String uri = ((URIParsedResult) parsedResult).getURI();
        switch (i) {
            case 0:
                this.finalResultsHandler.openURL(uri);
                return;
            case 1:
                this.finalResultsHandler.shareByEmail(uri);
                return;
            case 2:
                this.finalResultsHandler.shareBySMS(uri);
                return;
            case 3:
                this.finalResultsHandler.searchBookContents(uri);
                return;
            default:
                return;
        }
    }

    public CharSequence addressResultContent(ParsedResult parsedResult) {
        AddressBookParsedResult addressBookParsedResult = (AddressBookParsedResult) parsedResult;
        StringBuilder sb = new StringBuilder(100);
        ParsedResult.maybeAppend(addressBookParsedResult.getNames(), sb);
        int length = sb.length();
        String pronunciation = addressBookParsedResult.getPronunciation();
        if (pronunciation != null && !pronunciation.isEmpty()) {
            sb.append("\n(");
            sb.append(pronunciation);
            sb.append(')');
        }
        ParsedResult.maybeAppend(addressBookParsedResult.getTitle(), sb);
        ParsedResult.maybeAppend(addressBookParsedResult.getOrg(), sb);
        ParsedResult.maybeAppend(addressBookParsedResult.getAddresses(), sb);
        String[] phoneNumbers = addressBookParsedResult.getPhoneNumbers();
        if (phoneNumbers != null) {
            for (String str : phoneNumbers) {
                if (str != null) {
                    ParsedResult.maybeAppend(FinalResultsHandler.formatPhone(str), sb);
                }
            }
        }
        ParsedResult.maybeAppend(addressBookParsedResult.getEmails(), sb);
        ParsedResult.maybeAppend(addressBookParsedResult.getURLs(), sb);
        String birthday = addressBookParsedResult.getBirthday();
        if (birthday != null && !birthday.isEmpty()) {
            long parseDate = parseDate(birthday);
            if (parseDate >= 0) {
                ParsedResult.maybeAppend(DateFormat.getDateInstance(2).format(Long.valueOf(parseDate)), sb);
            }
        }
        ParsedResult.maybeAppend(addressBookParsedResult.getNote(), sb);
        if (length <= 0) {
            return sb.toString();
        }
        SpannableString spannableString = new SpannableString(sb.toString());
        spannableString.setSpan(new StyleSpan(1), 0, length, 0);
        return spannableString;
    }

    public CharSequence calenderResultContent(ParsedResult parsedResult) {
        CalendarParsedResult calendarParsedResult = (CalendarParsedResult) parsedResult;
        StringBuilder sb = new StringBuilder(100);
        ParsedResult.maybeAppend(calendarParsedResult.getSummary(), sb);
        long startTimestamp = calendarParsedResult.getStartTimestamp();
        ParsedResult.maybeAppend(format(calendarParsedResult.isStartAllDay(), startTimestamp), sb);
        long endTimestamp = calendarParsedResult.getEndTimestamp();
        if (endTimestamp >= 0) {
            if (calendarParsedResult.isEndAllDay() && startTimestamp != endTimestamp) {
                endTimestamp -= 86400000;
            }
            ParsedResult.maybeAppend(format(calendarParsedResult.isEndAllDay(), endTimestamp), sb);
        }
        ParsedResult.maybeAppend(calendarParsedResult.getLocation(), sb);
        ParsedResult.maybeAppend(calendarParsedResult.getOrganizer(), sb);
        ParsedResult.maybeAppend(calendarParsedResult.getAttendees(), sb);
        ParsedResult.maybeAppend(calendarParsedResult.getDescription(), sb);
        return sb.toString();
    }

    public CharSequence wifiResultContent(ParsedResult parsedResult) {
        WifiParsedResult wifiParsedResult = (WifiParsedResult) parsedResult;
        return wifiParsedResult.getSsid() + " (" + wifiParsedResult.getNetworkEncryption() + ')';
    }

    public CharSequence smsResultContent(ParsedResult parsedResult) {
        SMSParsedResult sMSParsedResult = (SMSParsedResult) parsedResult;
        String[] numbers = sMSParsedResult.getNumbers();
        String[] strArr = new String[numbers.length];
        for (int i = 0; i < numbers.length; i++) {
            strArr[i] = FinalResultsHandler.formatPhone(numbers[i]);
        }
        StringBuilder sb = new StringBuilder(50);
        ParsedResult.maybeAppend(strArr, sb);
        ParsedResult.maybeAppend(sMSParsedResult.getSubject(), sb);
        ParsedResult.maybeAppend(sMSParsedResult.getBody(), sb);
        return sb.toString();
    }

    public CharSequence telResultContent(ParsedResult parsedResult) {
        return FinalResultsHandler.formatPhone(parsedResult.getDisplayResult().replace("\r", ""));
    }
}
