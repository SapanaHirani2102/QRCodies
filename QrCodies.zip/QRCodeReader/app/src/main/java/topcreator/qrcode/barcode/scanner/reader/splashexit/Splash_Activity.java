package topcreator.qrcode.barcode.scanner.reader.splashexit;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.MobileAds;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.ironsource.mediationsdk.IronSource;
import com.ironsource.mediationsdk.integration.IntegrationHelper;
import com.ironsource.mediationsdk.logger.IronSourceError;
import com.ironsource.mediationsdk.sdk.InterstitialListener;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.splashexit.model.AdModel;

public class Splash_Activity extends AppCompatActivity {
    public static final String FALLBACK_USER_ID = "userId";
    private FirebaseDatabase mFirebaseInstance;
    private DatabaseReference mFirebaseDatabase;
    public static AdModel adModel = new AdModel();
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);

        adModel = getAdPref();
        firebaseAd();

        if (!AppCommon.CheckNet(this)) {
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    Intent i = new Intent(Splash_Activity.this, SplashStart_Activity.class);
                    i.putExtra("fromSplash", true);
                    startActivity(i);
                    finish();
                }
            }, 2000);
        }

        IntegrationHelper.validateIntegration(this);
        IronSource.shouldTrackNetworkState(this, true);

    }

    private void firebaseAd() {
        mFirebaseInstance = FirebaseDatabase.getInstance();
        mFirebaseDatabase = mFirebaseInstance.getReference();
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Query query = mFirebaseDatabase.child("user");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    adModel = dataSnapshot.getValue(AdModel.class);
                    setAdPref(adModel);
                    MobileAds.initialize(Splash_Activity.this, adModel.getAdMobAppID());
                    if (Splash_Activity.adModel.getIsIronEnable() == 1) {
                        startIronSourceInitTask();
                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        Intent i = new Intent(Splash_Activity.this, SplashStart_Activity.class);
                        i.putExtra("fromSplash", true);
                        startActivity(i);
                        finish();
                    }
                }, 2000);
                Log.e("print", "onCancelled: " + databaseError.getMessage());
            }
        });
    }

    private void startIronSourceInitTask() {

        // getting advertiser id should be done on a background thread
        AsyncTask<Void, Void, String> task = new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                return IronSource.getAdvertiserId(Splash_Activity.this);
            }

            @Override
            protected void onPostExecute(String advertisingId) {
                if (TextUtils.isEmpty(advertisingId)) {
                    advertisingId = FALLBACK_USER_ID;
                }
                // we're using an advertisingId as the 'userId'
                initIronSource(adModel.getIronAppKey(), advertisingId);
            }
        };
        task.execute();
    }

    private void initIronSource(String appKey, String userId) {
        IronSource.setInterstitialListener(new InterstitialListener() {
            @Override
            public void onInterstitialAdReady() {
                if (IronSource.isInterstitialReady()) {
                    //show the interstitial
                    IronSource.showInterstitial();
                }
            }

            @Override
            public void onInterstitialAdLoadFailed(IronSourceError ironSourceError) {
                Log.e("print", "onInterstitialAdLoadFailed: " + ironSourceError.getErrorCode());
                Intent i = new Intent(Splash_Activity.this, SplashStart_Activity.class);
                i.putExtra("fromSplash", true);
                startActivity(i);
                finish();
            }

            @Override
            public void onInterstitialAdOpened() {

            }

            @Override
            public void onInterstitialAdClosed() {
                Intent i = new Intent(Splash_Activity.this, SplashStart_Activity.class);
                i.putExtra("fromSplash", true);
                startActivity(i);
                finish();
            }

            @Override
            public void onInterstitialAdShowSucceeded() {

            }

            @Override
            public void onInterstitialAdShowFailed(IronSourceError ironSourceError) {
                Log.e("print", "onInterstitialAdShowFailed: " + ironSourceError.getErrorMessage());
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        Intent i = new Intent(Splash_Activity.this, SplashStart_Activity.class);
                        i.putExtra("fromSplash", true);
                        startActivity(i);
                        finish();
                    }
                }, 2000);
            }

            @Override
            public void onInterstitialAdClicked() {

            }

        });

        // set the IronSource user id
        IronSource.setUserId(userId);
        // init the IronSource SDK
        IronSource.init(this, appKey);
        IronSource.loadInterstitial();

    }

    @Override
    public void onBackPressed() {

    }

    public AdModel getAdPref() {
        AdModel adModel = new AdModel();
        SharedPreferences pref = getSharedPreferences("admodel", 0);
        adModel.setAdMobAppID(pref.getString("adMobAppID", ""));
        adModel.setAdMobBanner(pref.getString("adMobBanner", ""));
        adModel.setAdMobInter(pref.getString("adMobInter", ""));
        adModel.setAdMobNative(pref.getString("adMobNative", ""));
        adModel.setIronAppKey(pref.getString("ironAppKey", ""));
        adModel.setIsAdmobEnable(pref.getInt("isAdmobEnable", 0));
        adModel.setIsIronEnable(pref.getInt("isIronEnable", 0));
        adModel.setPrivacy(pref.getString("privacy", ""));
        adModel.setMoreApps(pref.getString("moreApps", ""));

        return adModel;
    }

    @SuppressLint("ApplySharedPref")
    public void setAdPref(AdModel adModel) {
        SharedPreferences pref = getSharedPreferences("admodel", 0);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("adMobAppID", adModel.getAdMobAppID());
        editor.putString("adMobBanner", adModel.getAdMobBanner());
        editor.putString("adMobInter", adModel.getAdMobInter());
        editor.putString("adMobNative", adModel.getAdMobNative());
        editor.putString("ironAppKey", adModel.getIronAppKey());
        editor.putInt("isAdmobEnable", adModel.getIsAdmobEnable());
        editor.putInt("isIronEnable", adModel.getIsIronEnable());
        editor.putString("privacy", adModel.getPrivacy());
        editor.putString("moreApps", adModel.getMoreApps());

        editor.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        IronSource.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        IronSource.onPause(this);
    }
}
