package topcreator.qrcode.barcode.scanner.reader.activities;

import android.content.DialogInterface;

/* renamed from: topcreator.qrcode.barcode.scanner.reader.activities.-$$Lambda$ScannedBarcodeItems$09q1ZDxm0iLXoIyKm_SGBdsqixs  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$ScannedBarcodeItems$09q1ZDxm0iLXoIyKm_SGBdsqixs implements DialogInterface.OnClickListener {
    public static final /* synthetic */ $$Lambda$ScannedBarcodeItems$09q1ZDxm0iLXoIyKm_SGBdsqixs INSTANCE = new $$Lambda$ScannedBarcodeItems$09q1ZDxm0iLXoIyKm_SGBdsqixs();

    private /* synthetic */ $$Lambda$ScannedBarcodeItems$09q1ZDxm0iLXoIyKm_SGBdsqixs() {
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        dialogInterface.dismiss();
    }
}
