package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.adapter.BaseRecyclerAdapter;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.holder.BookmarkFilterItemsHeaderHolder;
import topcreator.qrcode.barcode.scanner.reader.holder.BookmarkItemsHeaderHolder;
import topcreator.qrcode.barcode.scanner.reader.holder.ScanItemsHolder;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ScannedBarcodeBookmarkFragment extends Fragment {
    private Activity activity;
    private String filterType = "all";
    BaseRecyclerAdapter<ScanDataEntity, ScanItemsHolder> mAdapter;
    BaseRecyclerAdapter<String, BookmarkFilterItemsHeaderHolder> mAdapterHeader;
    private TextView mEmptyTxt;
    private RecyclerView mScannedHeaderRv;
    private RecyclerView mScannedRv;
    private List<ScanDataEntity> myOptions = new ArrayList();
    private String requestType;
    ScanDatabase scanDatabase;
    private TinyDB tinyDB;

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (MainActivity) context;
        }
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_bookmark_scanned_barcode_items, viewGroup, false);
        this.activity.getWindow().clearFlags(1024);
        this.tinyDB = TinyDB.getInstance(this.activity);
        this.mScannedRv = (RecyclerView) inflate.findViewById(R.id.scanned_rv);
        this.mScannedHeaderRv = (RecyclerView) inflate.findViewById(R.id.scanned_rv_header);
        this.mEmptyTxt = (TextView) inflate.findViewById(R.id.empty_txt);
        this.scanDatabase = ScanDatabase.getInstance(this.activity);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyyy", Locale.ENGLISH);
        simpleDateFormat.format(new Date());
        simpleDateFormat2.format(new Date());
        simpleDateFormat3.format(new Date());
        Bundle arguments = getArguments();
        if (arguments != null) {
            this.requestType = "filterItemSelected";
            this.tinyDB.putString(Constants.FILTER_TYPE_BACK, this.requestType);
            this.filterType = arguments.getString(Constants.FILTER_TYPE);
            this.tinyDB.putString(Constants.FILTER_TYPE_SP, this.filterType);
            this.mScannedHeaderRv.setVisibility(View.VISIBLE);
            this.mAdapterHeader = new BaseRecyclerAdapter<>(R.layout.scanned_items_header, BookmarkFilterItemsHeaderHolder.class);
            this.mScannedHeaderRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedHeaderRv.setAdapter(this.mAdapterHeader);
            this.mAdapterHeader.setData(filterTypeData(this.filterType));
        } else {
            this.requestType = "filterItemNotSelected";
            this.tinyDB.putString(Constants.FILTER_TYPE_BACK, this.requestType);
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, ScanItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mScannedHeaderRv.setVisibility(View.VISIBLE);
            this.mAdapterHeader = new BaseRecyclerAdapter<>(R.layout.scanned_items_header, BookmarkItemsHeaderHolder.class);
            this.mScannedHeaderRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedHeaderRv.setAdapter(this.mAdapterHeader);
            this.mAdapterHeader.setData(filterData());
        }
        return inflate;
    }

    private List<ScanDataEntity> getNonDuplicate() {
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        List<ScanDataEntity> allBookmarkNonDuplicate = this.scanDatabase.scanDataDao().getAllBookmarkNonDuplicate();
        if (allBookmarkNonDuplicate.size() == 0) {
            this.mEmptyTxt.setVisibility(View.VISIBLE);
        }
        Collections.sort(allBookmarkNonDuplicate, new Comparator() {
            public final int compare(Object obj, Object obj2) {
                return ScannedBarcodeBookmarkFragment.lambda$getNonDuplicate$0(simpleDateFormat, (ScanDataEntity) obj, (ScanDataEntity) obj2);
            }
        });
        Collections.reverse(allBookmarkNonDuplicate);
        return allBookmarkNonDuplicate;
    }

    static /* synthetic */ int lambda$getNonDuplicate$0(SimpleDateFormat simpleDateFormat, ScanDataEntity scanDataEntity, ScanDataEntity scanDataEntity2) {
        try {
            return simpleDateFormat.parse(scanDataEntity.getDate()).compareTo(simpleDateFormat.parse(scanDataEntity2.getDate()));
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private List<ScanDataEntity> getNonFilterDuplicate(String str) {
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        List<ScanDataEntity> allFilterBookmarkNonDuplicate = this.scanDatabase.scanDataDao().getAllFilterBookmarkNonDuplicate(str);
        if (allFilterBookmarkNonDuplicate.size() == 0) {
            this.mEmptyTxt.setVisibility(View.VISIBLE);
        }
        Collections.sort(allFilterBookmarkNonDuplicate, new Comparator() {
             public final int compare(Object obj, Object obj2) {
                return ScannedBarcodeBookmarkFragment.lambda$getNonFilterDuplicate$1(simpleDateFormat, (ScanDataEntity) obj, (ScanDataEntity) obj2);
            }
        });
        Collections.reverse(allFilterBookmarkNonDuplicate);
        return allFilterBookmarkNonDuplicate;
    }

    static /* synthetic */ int lambda$getNonFilterDuplicate$1(SimpleDateFormat simpleDateFormat, ScanDataEntity scanDataEntity, ScanDataEntity scanDataEntity2) {
        try {
            return simpleDateFormat.parse(scanDataEntity.getDate()).compareTo(simpleDateFormat.parse(scanDataEntity2.getDate()));
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private String[] splitDate(String str) {
        return str.split("-");
    }

    private String getMonth(int i) {
        return new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}[i];
    }

    private List<ScanDataEntity> getScannedDataList() {
        List<ScanDataEntity> allWords = this.scanDatabase.scanDataDao().getAllWords();
        Collections.reverse(allWords);
        return allWords;
    }

    private List<ScanDataEntity> getListFilerByType(String str) {
        List<ScanDataEntity> scannedDataList = getScannedDataList();
        ArrayList arrayList = new ArrayList();
        for (ScanDataEntity next : scannedDataList) {
            if (next.getScannedType().equals(str)) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    private List<String> filterData() {
        List<ScanDataEntity> nonDuplicate = getNonDuplicate();
        ArrayList arrayList = new ArrayList();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM-yyyy", Locale.ENGLISH);
        new SimpleDateFormat("yyyy", Locale.ENGLISH);
        new SimpleDateFormat("MMM", Locale.ENGLISH);
        Calendar instance = Calendar.getInstance();
        instance.set(7, 1);
        try {
            Date parse = simpleDateFormat.parse(simpleDateFormat.format(instance.getTime()));
            instance.set(7, 7);
            Date parse2 = simpleDateFormat.parse(simpleDateFormat.format(instance.getTime()));
            Calendar instance2 = Calendar.getInstance();
            String format = simpleDateFormat.format(instance2.getTime());
            String format2 = simpleDateFormat2.format(instance2.getTime());
            instance2.add(5, -1);
            String format3 = simpleDateFormat.format(instance2.getTime());
            for (ScanDataEntity date : nonDuplicate) {
                String date2 = date.getDate();
                Date parse3 = simpleDateFormat.parse(date2);
                if (!date2.contains(format2)) {
                    if (!arrayList.contains(getMonth(Integer.parseInt(splitDate(date2)[1]) - 1) + "-" + splitDate(date2)[2])) {
                        arrayList.add(getMonth(Integer.parseInt(splitDate(date2)[1]) - 1) + "-" + splitDate(date2)[2]);
                    }
                } else if (date2.equals(format)) {
                    arrayList.add(Constants.DATE_TYPE_DAY);
                } else if (date2.equals(format3)) {
                    arrayList.add(Constants.DATE_TYPE_YESTERDAY);
                } else if (parse3.getTime() < parse.getTime() || parse3.getTime() > parse2.getTime()) {
                    if (!arrayList.contains(Constants.DATE_TYPE_MONTH)) {
                        arrayList.add(Constants.DATE_TYPE_MONTH);
                    }
                } else if (!arrayList.contains(Constants.DATE_TYPE_WEEK)) {
                    arrayList.add(Constants.DATE_TYPE_WEEK);
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    private List<String> filterTypeData(String str) {
        List<ScanDataEntity> nonFilterDuplicate = getNonFilterDuplicate(str);
        ArrayList arrayList = new ArrayList();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM-yyyy", Locale.ENGLISH);
        new SimpleDateFormat("yyyy", Locale.ENGLISH);
        new SimpleDateFormat("MMM", Locale.ENGLISH);
        Calendar instance = Calendar.getInstance();
        instance.set(7, 1);
        try {
            Date parse = simpleDateFormat.parse(simpleDateFormat.format(instance.getTime()));
            instance.set(7, 7);
            Date parse2 = simpleDateFormat.parse(simpleDateFormat.format(instance.getTime()));
            Calendar instance2 = Calendar.getInstance();
            String format = simpleDateFormat.format(instance2.getTime());
            String format2 = simpleDateFormat2.format(instance2.getTime());
            instance2.add(5, -1);
            String format3 = simpleDateFormat.format(instance2.getTime());
            for (ScanDataEntity date : nonFilterDuplicate) {
                String date2 = date.getDate();
                Date parse3 = simpleDateFormat.parse(date2);
                if (!date2.contains(format2)) {
                    if (!arrayList.contains(getMonth(Integer.parseInt(splitDate(date2)[1]) - 1) + "-" + splitDate(date2)[2])) {
                        arrayList.add(getMonth(Integer.parseInt(splitDate(date2)[1]) - 1) + "-" + splitDate(date2)[2]);
                    }
                } else if (date2.equals(format)) {
                    arrayList.add(Constants.DATE_TYPE_DAY);
                } else if (date2.equals(format3)) {
                    arrayList.add(Constants.DATE_TYPE_YESTERDAY);
                } else if (parse3.getTime() < parse.getTime() || parse3.getTime() > parse2.getTime()) {
                    if (!arrayList.contains(Constants.DATE_TYPE_MONTH)) {
                        arrayList.add(Constants.DATE_TYPE_MONTH);
                    }
                } else if (!arrayList.contains(Constants.DATE_TYPE_WEEK)) {
                    arrayList.add(Constants.DATE_TYPE_WEEK);
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    private List<ScanDataEntity> getScannedTimeDataList(String str, String str2, String str3, String str4) {
        List<ScanDataEntity> genericBookmarkTimeDataList = this.scanDatabase.scanDataDao().getGenericBookmarkTimeDataList(str, str2, str3, str4);
        Collections.reverse(genericBookmarkTimeDataList);
        return genericBookmarkTimeDataList;
    }
}
