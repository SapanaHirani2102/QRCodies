package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.adapter.BaseRecyclerAdapter;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.Intents;
import topcreator.qrcode.barcode.scanner.reader.holder.DesignCardItemHolder;
import topcreator.qrcode.barcode.scanner.reader.model.DesignCardItemModel;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class BusinessCardGenerator extends Fragment {
    private Activity activity;
    BaseRecyclerAdapter<DesignCardItemModel, DesignCardItemHolder> mAdapterHeader;
    private TextView mAddressTxt;
    private RelativeLayout mBackCard;
    private ImageView mBarcodeImg;
    private TextView mEmailTxt;
    private RelativeLayout mFrontCard;
    private RecyclerView mGenerateCardRv;
    private TextView mJobTxt;
    private TextView mMobileTxt;
    private TextView mNameTxt;
    private TextView mPhoneTxt;
    private Button mShareBtn;
    private TextView mWebsiteTxt;

    private static void shareMultiple(List<File> list, Context context) {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND_MULTIPLE");
        intent.putExtra("android.intent.extra.SUBJECT", "Here are some files.");
        intent.setType("image/*");
        ArrayList arrayList = new ArrayList();
        for (File absolutePath : list) {
            arrayList.add(Uri.fromFile(new File(absolutePath.getAbsolutePath())));
        }
        intent.putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList);
        context.startActivity(intent);
    }

    public static Bitmap loadBitmapFromView(View view) {
        Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        view.draw(new Canvas(createBitmap));
        return createBitmap;
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.activity = (MainActivity) context;
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_business_card_generator, viewGroup, false);
        initView(inflate);
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        Bundle arguments = getArguments();
        if (arguments != null) {
            String string = arguments.getString(Intents.WifiConnect.TYPE);
            if (Constants.TYPE_ADDRESSBOOK.equals(string)) {
                setAdapterData(getAddressCardList(string));
            } else if (Constants.TYPE_CALENDAR.equals(string)) {
                setAdapterData(getCalenderCardList(string));
            } else if (Constants.TYPE_EMAIL_ADDRESS.equals(string)) {
                setAdapterData(getEmailCardList(string));
            } else if (Constants.TYPE_GEO.equals(string)) {
                setAdapterData(getGeoCardList(string));
            } else if (Constants.TYPE_ISBN.equals(string)) {
                setAdapterData(getISBNCardList(string));
            } else if (Constants.TYPE_PRODUCT.equals(string)) {
                setAdapterData(getProCardList(string));
            } else if (Constants.TYPE_SMS.equals(string)) {
                setAdapterData(getSmsCardList(string));
            } else if (Constants.TYPE_TEL.equals(string)) {
                setAdapterData(getTelCardList(string));
            } else if (Constants.TYPE_TEXT.equals(string)) {
                setAdapterData(getTxtCardList(string));
            } else if (Constants.TYPE_URI.equals(string)) {
                setAdapterData(getUrlCardList(string));
            } else if (Constants.TYPE_WIFI.equals(string)) {
                setAdapterData(getWifiCardList(string));
            } else if (Constants.TYPE_SOCIAL.equals(string)) {
                setAdapterData(getSocialCardList(string));
            }
        }
        return inflate;
    }

    private void setAdapterData(List<DesignCardItemModel> list) {
        this.mAdapterHeader = new BaseRecyclerAdapter<>(R.layout.generate_card_item, DesignCardItemHolder.class);
        this.mGenerateCardRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
        this.mGenerateCardRv.setAdapter(this.mAdapterHeader);
        this.mAdapterHeader.setData(list);
    }

    private List<DesignCardItemModel> getProCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_pro_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_pro_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_pro_3, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_pro_4, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getUrlCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_url_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_url_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_url_3, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getWifiCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_wifi_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_wifi_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_wifi_3, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getAddressCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_contact_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_contact_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_contact_3, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_contact_4, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getTxtCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_txt_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_txt_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_txt_3, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getSmsCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_sms_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_sms_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_sms_3, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getEmailCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_email_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_email_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_email_3, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getCalenderCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_calender_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_calender_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_calender_3, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getISBNCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_isbn_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_isbn_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_isbn_3, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getSocialCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_social_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_social_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_social_3, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getTelCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_tel_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_tel_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_tel_3, str));
        return arrayList;
    }

    private List<DesignCardItemModel> getGeoCardList(String str) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_geo_1, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_geo_2, str));
        arrayList.add(new DesignCardItemModel(R.drawable.ic_card_geo_3, str));
        return arrayList;
    }

    private void initView(View view) {
        this.mGenerateCardRv = (RecyclerView) view.findViewById(R.id.generate_card_rv);
    }
}
