package topcreator.qrcode.barcode.scanner.reader.holder;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.SelectCardResultActivity;
import topcreator.qrcode.barcode.scanner.reader.database.CardDataEntity;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.ImageSaver;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CardItemsHolder extends BaseItemHolder<CardDataEntity>  {
    SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ssa", Locale.ENGLISH);
    TextView scanTxt;
    TextView timeTxt;
    TinyDB tinyDB;
    String[] typeArray;
    ImageView typeImg;
    TextView typeTxt;

    public CardItemsHolder(View view) {
        super(view);
        this.typeImg = (ImageView) view.findViewById(R.id.type_img);
        this.scanTxt = (TextView) view.findViewById(R.id.scan_txt);
        this.timeTxt = (TextView) view.findViewById(R.id.time_txt);
        this.typeTxt = (TextView) view.findViewById(R.id.scan_type_txt);
        this.tinyDB = TinyDB.getInstance(view.getContext());
        this.typeArray = view.getResources().getStringArray(R.array.filter_by_type);
    }

    public void bindData(final CardDataEntity cardDataEntity, int i, int i2) {
        super.bindData(cardDataEntity, i, i2);
            setProductTypeImage(cardDataEntity.getCardType());
            this.scanTxt.setText(cardDataEntity.getCardName());
            this.scanTxt.setSelected(true);
            this.timeTxt.setText(this.format.format(new Date(new Timestamp(Long.parseLong(cardDataEntity.getTime())).getTime())));
            this.itemView.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    CardItemsHolder.lambda$bindData$0(CardItemsHolder.this, cardDataEntity, view);
                }
            });
        if (i + 1 == i2) {
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMargins(0, 0, 0, 100);
            this.itemView.setLayoutParams(layoutParams);
        }
    }

    public static /* synthetic */ void lambda$bindData$0(CardItemsHolder cardItemsHolder, CardDataEntity cardDataEntity, View view) {
        TinyDB tinyDB2 = cardItemsHolder.tinyDB;
        tinyDB2.putInt(Constants.ADS_COUNT, tinyDB2.getInt(Constants.ADS_COUNT) + 1);
        Bundle bundle = new Bundle();
        cardDataEntity.getCardId();
        cardDataEntity.getBPathImg();
        cardDataEntity.getFPathImg();
        bundle.putString("cardId", String.valueOf(cardDataEntity.getCardId()));
        bundle.putString("cardF", String.valueOf(cardDataEntity.getFPathImg()));
        bundle.putString("cardB", String.valueOf(cardDataEntity.getBPathImg()));
        bundle.putString("cardName", String.valueOf(cardDataEntity.getCardName()));
        bundle.putString("cardNumber", String.valueOf(cardDataEntity.getCardNumber()));
        bundle.putString("cardType", String.valueOf(cardDataEntity.getCardType()));
        bundle.putString("cardSql", String.valueOf(cardDataEntity.getSqlDate()));
        bundle.putString("cardTime", String.valueOf(cardDataEntity.getTime()));
        Intent intent = new Intent(cardItemsHolder.itemView.getContext(), SelectCardResultActivity.class);
        intent.putExtras(bundle);
        cardItemsHolder.itemView.getContext().startActivity(intent);
    }

    private Bitmap getImage(Context context, String str) {
        return new ImageSaver(context).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(str).load();
    }

    private void setProductTypeImage(String str) {
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_add);
            this.typeTxt.setText(this.typeArray[8]);
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_cal1);
            this.typeTxt.setText(this.typeArray[9]);
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_email);
            this.typeTxt.setText(this.typeArray[7]);
        } else if (Constants.TYPE_GEO.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_loc);
            this.typeTxt.setText(this.typeArray[11]);
        } else if (Constants.TYPE_ISBN.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_isbn);
            this.typeTxt.setText(this.typeArray[10]);
        } else if (Constants.TYPE_PRODUCT.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_product);
            this.typeTxt.setText(this.typeArray[1]);
        } else if (Constants.TYPE_SMS.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_msgs);
            this.typeTxt.setText(this.typeArray[6]);
        } else if (Constants.TYPE_TEL.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_call);
            this.typeTxt.setText(this.typeArray[4]);
        } else if (Constants.TYPE_TEXT.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_text);
            this.typeTxt.setText(this.typeArray[5]);
        } else if (Constants.TYPE_URI.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_url);
            this.typeTxt.setText(this.typeArray[2]);
        } else if (Constants.TYPE_WIFI.equals(str)) {
            this.typeImg.setImageResource(R.drawable.i_wifi);
            this.typeTxt.setText(this.typeArray[3]);
        }
    }
}
