package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.adapter.BaseRecyclerAdapterFilter;
import topcreator.qrcode.barcode.scanner.reader.holder.BaseItemHolder;
import topcreator.qrcode.barcode.scanner.reader.holder.ScanTypeFilterHolder;
import topcreator.qrcode.barcode.scanner.reader.model.FilterTypeModel;
import topcreator.qrcode.barcode.scanner.reader.model.SelectFilterItemModel;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import java.util.ArrayList;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class ResultTypeFilterFragment extends Fragment {
    private Activity activity;
    private BaseRecyclerAdapterFilter<FilterTypeModel, BaseItemHolder> mAdapterHeader;
    private ImageView mBackImg;
    private RelativeLayout mHeaderLayout;
    private RecyclerView mTypeRecyclerView;
    private String requestType = "filter";
    private String[] typeTxt;

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (Activity) context;
        }
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_result_type_filter, viewGroup, false);
        this.activity.getWindow().clearFlags(1024);
        if (getArguments() != null) {
            this.requestType = getArguments().getString(Constants.FILTER_TYPE_LIST);
        }
        this.mHeaderLayout = (RelativeLayout) inflate.findViewById(R.id.header_layout);
        this.mBackImg = (ImageView) inflate.findViewById(R.id.back_img);
        this.mTypeRecyclerView = (RecyclerView) inflate.findViewById(R.id.type_recycler_view);
        this.typeTxt = this.activity.getResources().getStringArray(R.array.filter_by_type);
        this.mAdapterHeader = new BaseRecyclerAdapterFilter<>(R.layout.filter_type_item, ScanTypeFilterHolder.class);
        this.mTypeRecyclerView.setLayoutManager(new StaggeredGridLayoutManager(3, 1));
        this.mTypeRecyclerView.setAdapter(this.mAdapterHeader);
        this.mAdapterHeader.setData(getTypeData());
        this.mBackImg.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ResultTypeFilterFragment.lambda$onCreateView$0(ResultTypeFilterFragment.this, view);
            }
        });
        return inflate;
    }

    public static /* synthetic */ void lambda$onCreateView$0(ResultTypeFilterFragment resultTypeFilterFragment, View view) {
        if (resultTypeFilterFragment.requestType.equals(Constants.TYPE_BOOKMARK)) {
            ((MainActivity) resultTypeFilterFragment.activity).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeBookmarkFragment()).commitAllowingStateLoss();
        } else if (resultTypeFilterFragment.requestType.equals("filter")) {
            ((MainActivity) resultTypeFilterFragment.activity).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeHistotyFragment()).commitAllowingStateLoss();
        }
    }

    private List<FilterTypeModel> getTypeData() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new FilterTypeModel(R.drawable.i_url, R.drawable.bg_url, this.typeTxt[2], Constants.TYPE_URI));
        arrayList.add(new FilterTypeModel(R.drawable.i_text, R.drawable.bg_text, this.typeTxt[5], Constants.TYPE_TEXT));
        arrayList.add(new FilterTypeModel(R.drawable.i_msgs, R.drawable.bg_sms, this.typeTxt[6], Constants.TYPE_SMS));
        arrayList.add(new FilterTypeModel(R.drawable.i_product, R.drawable.bg_product, this.typeTxt[1], Constants.TYPE_PRODUCT));
        arrayList.add(new FilterTypeModel(R.drawable.i_wifi, R.drawable.bg_wifi, this.typeTxt[3], Constants.TYPE_WIFI));
        arrayList.add(new FilterTypeModel(R.drawable.i_call, R.drawable.bg_contacts, this.typeTxt[4], Constants.TYPE_TEL));
        arrayList.add(new FilterTypeModel(R.drawable.i_email, R.drawable.bg_email, this.typeTxt[7], Constants.TYPE_EMAIL_ADDRESS));
        arrayList.add(new FilterTypeModel(R.drawable.i_add, R.drawable.bg_addressbook, this.typeTxt[8], Constants.TYPE_ADDRESSBOOK));
        arrayList.add(new FilterTypeModel(R.drawable.i_cal1, R.drawable.bg_calender, this.typeTxt[9], Constants.TYPE_CALENDAR));
        arrayList.add(new FilterTypeModel(R.drawable.i_loc, R.drawable.bg_geo, this.typeTxt[11], Constants.TYPE_GEO));
        arrayList.add(new FilterTypeModel(R.drawable.i_isbn, R.drawable.bg_isbn, this.typeTxt[10], "ISBN"));
        return arrayList;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(SelectFilterItemModel selectFilterItemModel) {
        Bundle bundle = new Bundle();
        bundle.putString(Constants.FILTER_TYPE, selectFilterItemModel.getType());
        if (this.requestType.equals(Constants.TYPE_BOOKMARK)) {
            MainBarcodeBookmarkFragment mainBarcodeBookmarkFragment = new MainBarcodeBookmarkFragment();
            mainBarcodeBookmarkFragment.setArguments(bundle);
            ((MainActivity) this.activity).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, mainBarcodeBookmarkFragment).commitAllowingStateLoss();
        } else if (this.requestType.equals("filter")) {
            MainBarcodeHistotyFragment mainBarcodeHistotyFragment = new MainBarcodeHistotyFragment();
            mainBarcodeHistotyFragment.setArguments(bundle);
            ((MainActivity) this.activity).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, mainBarcodeHistotyFragment).commitAllowingStateLoss();
        }
    }

    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }
}
