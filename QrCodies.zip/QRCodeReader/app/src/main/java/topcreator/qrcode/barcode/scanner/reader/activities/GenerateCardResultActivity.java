package topcreator.qrcode.barcode.scanner.reader.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.ItemTouchHelper;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.ScannedResultManager;
import topcreator.qrcode.barcode.scanner.reader.database.CardBookmarkDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.CardDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.splashexit.Splash_Activity;
import topcreator.qrcode.barcode.scanner.reader.utils.CodeUtils;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.ImageSaver;
import com.google.android.gms.measurement.api.AppMeasurementSdk;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.result.ParsedResult;
import com.nabinbhandari.android.permissions.PermissionHandler;
import com.nabinbhandari.android.permissions.Permissions;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;

public class GenerateCardResultActivity extends AppCompatActivity {
    private String TAG = "GenerateCardResultActivity";
    SimpleDateFormat fd = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
    /* access modifiers changed from: private */
    public ImageSaver imageSaver;
    private boolean isBookmark = false;
    /* access modifiers changed from: private */
    public ConstraintLayout mBackCard;
    private ImageView mBarcodeImg;
    private ImageView mBookmarkImg;
    private RelativeLayout mBookmarkLayout;
    private TextView mCardAddressTxt;
    private TextView mCardCompanyNameMain;
    private TextView mCardCompanyTxt;
    private TextView mCardEmailTxt;
    private ImageView mCardGeneratedImg;
    private TextView mCardJobTitleTxt;
    private TextView mCardMobileTxt;
    private TextView mCardNameTxt;
    private TextView mCardPhoneTxt;
    private TextView mCardWebTxt;
    private RelativeLayout mCopyLayout;
    /* access modifiers changed from: private */
    public ConstraintLayout mFrontCard;
    private TextView mGenerateBtn;
    private RelativeLayout mShareLayout;
    private ParsedResult parsedResult;
    private ScanDatabase scanDatabase;
    private ScannedResultManager scannedResultManager;
    private String str2;
    private InterstitialAd mInterstitialAdMob;

    public static void start(Activity activity, Bundle bundle) {
        Intent intent = new Intent(activity, GenerateCardResultActivity.class);
        intent.putExtra(Constants.GENERATE_INFO, bundle);
        activity.startActivity(intent);
//        ((AdvanceQrActivity) activity).showInter(intent, 0,
//                AppCommon.AD_FB, AppCommon.AD_ADMOB, AppCommon.AD_APP_NEXT);

    }

    private static void shareMultiple(List<File> list, Context context) {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND_MULTIPLE");
        intent.putExtra("android.intent.extra.SUBJECT", "Here are some files.");
        intent.setType("image/*");
        ArrayList arrayList = new ArrayList();
        for (File absolutePath : list) {
            arrayList.add(Uri.fromFile(new File(absolutePath.getAbsolutePath())));
        }
        intent.putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList);
        context.startActivity(intent);
    }

    public static Bitmap loadBitmapFromView(View view) {
        Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        view.draw(new Canvas(createBitmap));
        return createBitmap;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        statusBarSet();

        initAdmobFullAd(this);
        loadAdmobAd();

        this.scannedResultManager = new ScannedResultManager(this);
        this.scanDatabase = ScanDatabase.getInstance(this);
        this.imageSaver = new ImageSaver(this);
        final Bundle bundleExtra = getIntent().getBundleExtra(Constants.GENERATE_INFO);
        if (bundleExtra != null) {
            showViewCard(bundleExtra.getString(Constants.CARD_TYPE), bundleExtra.getInt("position"), bundleExtra);
            statusBarSet();
        }
        this.mShareLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                GenerateCardResultActivity.lambda$onCreate$0(GenerateCardResultActivity.this, view);
            }
        });
        this.mCopyLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                Permissions.check((Context) GenerateCardResultActivity.this, "android.permission.WRITE_EXTERNAL_STORAGE", (String) null, (PermissionHandler) new PermissionHandler() {
                    public void onGranted() {
                        Bitmap loadBitmapFromView = GenerateCardResultActivity.loadBitmapFromView(mFrontCard);
                        Bitmap loadBitmapFromView2 = GenerateCardResultActivity.loadBitmapFromView(mBackCard);
                        long currentTimeMillis = System.currentTimeMillis();
                        String str = "f_image-" + currentTimeMillis + ".jpg";
                        imageSaver.setFileName(str).setDirectoryName(Constants.SAVE_DIR_NAME_GALLERY).setExternal(true).save(loadBitmapFromView);
                        String absolutePath = imageSaver.getFilePath().getAbsolutePath();
                        imageSaver.setFileName("b_image-" + currentTimeMillis + ".jpg").setDirectoryName(Constants.SAVE_DIR_NAME_GALLERY).setExternal(true).save(loadBitmapFromView2);
                        String absolutePath2 = imageSaver.getFilePath().getAbsolutePath();
                        Toast.makeText(GenerateCardResultActivity.this, "Save to gallery Successful!", Toast.LENGTH_LONG).show();
                        MediaScannerConnection.scanFile(GenerateCardResultActivity.this, new String[]{absolutePath, absolutePath2}, null, new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String str, Uri uri) {
                                Log.i("ExternalStorage", "Scanned " + str + ":");
                                StringBuilder sb = new StringBuilder();
                                sb.append("-> uri=");
                                sb.append(uri);
                                Log.i("ExternalStorage", sb.toString());
                            }
                        });
                    }
                });
            }
        });
        this.mGenerateBtn.setOnClickListener(new View.OnClickListener() {

            public final void onClick(View view) {
                GenerateCardResultActivity.lambda$onCreate$2(GenerateCardResultActivity.this, bundleExtra, view);
            }
        });
        this.mBookmarkLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                GenerateCardResultActivity.lambda$onCreate$3(GenerateCardResultActivity.this, view);
            }
        });
    }

    private void statusBarSet() {
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, 67108864, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(1280);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, 67108864, false);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_bar_color));
        }
    }

    public static void setWindowFlag(Activity activity, int i, boolean z) {
        Window window = activity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags = i | attributes.flags;
        } else {
            attributes.flags = (i ^ -1) & attributes.flags;
        }
        window.setAttributes(attributes);
    }

    public static /* synthetic */ void lambda$onCreate$0(GenerateCardResultActivity generateCardResultActivity, View view) {
        new ImageSaver(generateCardResultActivity).setFileName("image1.jpg").setDirectoryName(Constants.SAVE_DIR_NAME).setExternal(true).save(loadBitmapFromView(generateCardResultActivity.mFrontCard));
        new ImageSaver(generateCardResultActivity).setFileName("image2.jpg").setDirectoryName(Constants.SAVE_DIR_NAME).setExternal(true).save(loadBitmapFromView(generateCardResultActivity.mBackCard));
        File filePath = new ImageSaver(generateCardResultActivity).setFileName("image1.jpg").setDirectoryName(Constants.SAVE_DIR_NAME).setExternal(true).getFilePath();
        File filePath2 = new ImageSaver(generateCardResultActivity).setFileName("image2.jpg").setDirectoryName(Constants.SAVE_DIR_NAME).setExternal(true).getFilePath();
        ArrayList arrayList = new ArrayList();
        arrayList.add(filePath);
        arrayList.add(filePath2);
        shareMultiple(arrayList, generateCardResultActivity);
    }

    public static /* synthetic */ void lambda$onCreate$2(GenerateCardResultActivity generateCardResultActivity, Bundle bundle, View view) {
        Bitmap loadBitmapFromView = loadBitmapFromView(generateCardResultActivity.mFrontCard);
        Bitmap loadBitmapFromView2 = loadBitmapFromView(generateCardResultActivity.mBackCard);
        long currentTimeMillis = System.currentTimeMillis();
        generateCardResultActivity.imageSaver.setFileName("f_image-" + currentTimeMillis + ".jpg").setDirectoryName(Constants.SAVE_DIR_NAME).save(loadBitmapFromView);
        String absolutePath = generateCardResultActivity.imageSaver.getFilePath().getAbsolutePath();
        generateCardResultActivity.imageSaver.setFileName("b_image-" + currentTimeMillis + ".jpg").setDirectoryName(Constants.SAVE_DIR_NAME).save(loadBitmapFromView2);
        String absolutePath2 = generateCardResultActivity.imageSaver.getFilePath().getAbsolutePath();
        if (bundle != null) {
            CardDataEntity cardDataEntity = new CardDataEntity(bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME), String.valueOf(currentTimeMillis), generateCardResultActivity.fd.format(Long.valueOf(currentTimeMillis)), bundle.getInt("position"), absolutePath, absolutePath2, bundle.getString(Constants.CARD_TYPE));
            generateCardResultActivity.insertDatabase(cardDataEntity, bundle, absolutePath, absolutePath2);
        }
    }

    public static /* synthetic */ void lambda$onCreate$3(GenerateCardResultActivity generateCardResultActivity, View view) {
        if (generateCardResultActivity.isBookmark) {
            generateCardResultActivity.mBookmarkImg.setImageResource(R.drawable.i_bookmark1);
            generateCardResultActivity.isBookmark = false;
            return;
        }
        generateCardResultActivity.mBookmarkImg.setImageResource(R.drawable.i_bookmark_select);
        generateCardResultActivity.isBookmark = true;
    }

    private int getBookmarkSize(int i) {
        return this.scanDatabase.scanDataDao().checkCardBookMark(i).size();
    }

    private int getLastCardRow() {
        return ((CardDataEntity) this.scanDatabase.scanDataDao().getLastCardRow().get(0)).getCardId();
    }

    private void insertDatabase(final CardDataEntity cardDataEntity, final Bundle bundle, final String str, final String str2) {
        Single.fromCallable(new Callable() {
            public final Object call() {
                GenerateCardResultActivity.this.scanDatabase.scanDataDao().insert(cardDataEntity);
                return cardDataEntity;
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer() {
            public final void accept(Object obj) {
                GenerateCardResultActivity.lambda$insertDatabase$5(GenerateCardResultActivity.this, bundle, str, str2);
            }
        }, new Consumer() {
            public final void accept(Object obj) {
                GenerateCardResultActivity.lambda$insertDatabase$6(GenerateCardResultActivity.this, (Throwable) obj);
            }
        });
    }


    public static /* synthetic */ void lambda$insertDatabase$5(GenerateCardResultActivity generateCardResultActivity, Bundle bundle, String str, String str2) {
        String str3 = generateCardResultActivity.TAG;
//        Log.e(str3, "Data Inserted: " + bool);
        Toast makeText = Toast.makeText(generateCardResultActivity.getApplicationContext(), "Generated code saved", 0);
        makeText.setGravity(17, 0, 0);
        makeText.show();
        if (!generateCardResultActivity.isBookmark) {
            Intent intent = new Intent(generateCardResultActivity, MainActivity.class);
            intent.addFlags(603979776);
            generateCardResultActivity.startActivity(intent);
            if (Splash_Activity.adModel.getIsAdmobEnable() == 1 && generateCardResultActivity.isAdmobLoaded()) {
                generateCardResultActivity.showAdmobInterstitial();
            }
            return;
        }
        long currentTimeMillis = System.currentTimeMillis();
        String string = bundle.getString(Constants.CARD_TYPE);
        CardBookmarkDataEntity cardBookmarkDataEntity = new CardBookmarkDataEntity(bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME), String.valueOf(currentTimeMillis), generateCardResultActivity.fd.format(Long.valueOf(currentTimeMillis)), bundle.getInt("position"), str, str2, string, generateCardResultActivity.getLastCardRow());
        generateCardResultActivity.insertBookmarkDatabase(cardBookmarkDataEntity);
    }

    public static /* synthetic */ void lambda$insertDatabase$6(GenerateCardResultActivity generateCardResultActivity, Throwable th) {
        String str = generateCardResultActivity.TAG;
        Log.e(str, "Generate Result: " + th.getMessage());
    }

    private void insertBookmarkDatabase(final CardBookmarkDataEntity cardBookmarkDataEntity) {
        Single.fromCallable(new Callable() {
            public final Object call() {
                scanDatabase.scanDataDao().insert(cardBookmarkDataEntity);
                return cardBookmarkDataEntity;
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer() {
            public final void accept(Object obj) {

                GenerateCardResultActivity.lambda$insertBookmarkDatabase$8(GenerateCardResultActivity.this);

            }
        }, new Consumer() {
            public final void accept(Object obj) {

                GenerateCardResultActivity.lambda$insertBookmarkDatabase$9(GenerateCardResultActivity.this);

            }
        });
    }

    public static /* synthetic */ void lambda$insertBookmarkDatabase$8(GenerateCardResultActivity generateCardResultActivity) {
        String str = generateCardResultActivity.TAG;
        Toast makeText = Toast.makeText(generateCardResultActivity.getApplicationContext(), "Generated code saved", 0);
        makeText.setGravity(17, 0, 0);
        makeText.show();
        Intent intent = new Intent(generateCardResultActivity, MainActivity.class);
        intent.addFlags(603979776);
        generateCardResultActivity.startActivity(intent);
    }

    public static /* synthetic */ void lambda$insertBookmarkDatabase$9(GenerateCardResultActivity generateCardResultActivity) {
        String str = generateCardResultActivity.TAG;
        Toast.makeText(generateCardResultActivity, "Generated code not save ", Toast.LENGTH_SHORT).show();
    }

    private void initView() {
        this.mCardNameTxt = (TextView) findViewById(R.id.card_name_txt);
        this.mCardAddressTxt = (TextView) findViewById(R.id.card_address_txt);
        this.mCardCompanyNameMain = (TextView) findViewById(R.id.card_company_name_main);
        this.mCardJobTitleTxt = (TextView) findViewById(R.id.card_job_title_txt);
        this.mCardGeneratedImg = (ImageView) findViewById(R.id.card_generated_img);
        this.mCardEmailTxt = (TextView) findViewById(R.id.card_email_txt);
        this.mCardMobileTxt = (TextView) findViewById(R.id.card_mobile_txt);
        this.mCardPhoneTxt = (TextView) findViewById(R.id.card_phone_txt);
        this.mCardCompanyTxt = (TextView) findViewById(R.id.card_company_txt);
        this.mCardWebTxt = (TextView) findViewById(R.id.card_web_txt);
        this.mShareLayout = (RelativeLayout) findViewById(R.id.share_layout);
        this.mBackCard = (ConstraintLayout) findViewById(R.id.back_card);
        this.mFrontCard = (ConstraintLayout) findViewById(R.id.front_card);
        this.mGenerateBtn = (TextView) findViewById(R.id.generate_btn);
        this.mCopyLayout = (RelativeLayout) findViewById(R.id.copy_layout);
        this.mBookmarkLayout = (RelativeLayout) findViewById(R.id.bookmark_layout);
        this.mBarcodeImg = (ImageView) findViewById(R.id.barcode_img);
        this.mBookmarkImg = (ImageView) findViewById(R.id.bookmark_img);
        statusBarSet();

    }

    private void showViewCard(String str, int i, Bundle bundle) {
        String string = bundle.getString(Constants.GENERATE_URL_NAME);
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            if (i == 0) {
                setContentView((int) R.layout.generate_card_address_layout);
                initView();
                setCardData(bundle, string);
            } else if (i == 1) {
                setContentView((int) R.layout.generate_card_address_2_layout);
                initView();
                setCardData(bundle, string);
            } else if (i == 2) {
                setContentView((int) R.layout.generate_card_address_3_layout);
                initView();
                setCardData(bundle, string);
            } else if (i == 3) {
                setContentView((int) R.layout.generate_card_address_4_layout);
                initView();
                setCardData(bundle, string);
            }
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            if (i == 0) {
                setContentView((int) R.layout.activity_generate_card_result);
            } else if (i == 1) {
                setContentView((int) R.layout.activity_generate_card_result);
            } else if (i == 2) {
                setContentView((int) R.layout.activity_generate_card_result);
            }
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            if (i == 0) {
                setContentView((int) R.layout.generate_card_email_1_layout);
                initView();
                setEmailCardData(bundle);
            } else if (i == 1) {
                setContentView((int) R.layout.generate_card_email_3_layout);
                initView();
                setEmailCardData(bundle);
            } else if (i == 2) {
                setContentView((int) R.layout.generate_card_email_2_layout);
                initView();
                setEmailCardData(bundle);
            }
        } else if (Constants.TYPE_GEO.equals(str)) {
            if (i == 0) {
                setContentView((int) R.layout.generate_card_geo_1_layout);
                initView();
                setGeoCardData(bundle);
            } else if (i == 1) {
                setContentView((int) R.layout.generate_card_geo_2_layout);
                initView();
                setGeoCardData(bundle);
            } else if (i == 2) {
                setContentView((int) R.layout.generate_card_geo_3_layout);
                initView();
                setGeoCardData(bundle);
            }
        } else if (Constants.TYPE_ISBN.equals(str)) {
            if (i == 0) {
                setContentView((int) R.layout.generate_card_isbn_1_layout);
                initView();
                setISBNCardData(bundle);
            } else if (i == 1) {
                setContentView((int) R.layout.generate_card_isbn_2_layout);
                initView();
                setISBNCardData(bundle);
            } else if (i == 2) {
                setContentView((int) R.layout.generate_card_isbn_3_layout);
                initView();
                setISBNCardData(bundle);
            }
        } else if (Constants.TYPE_PRODUCT.equals(str)) {
            if (i == 0) {
                setContentView((int) R.layout.generate_card_pro_1_layout);
                initView();
                setProCardData(bundle);
            } else if (i == 1) {
                setContentView((int) R.layout.generate_card_pro_2_layout);
                initView();
                setProCardData(bundle);
            } else if (i == 2) {
                setContentView((int) R.layout.generate_card_pro_3_layout);
                initView();
                setProCardData(bundle);
            } else if (i == 3) {
                setContentView((int) R.layout.generate_card_pro_4_layout);
                initView();
                setProCardData(bundle);
            }
        } else if (Constants.TYPE_SMS.equals(str)) {
            if (i == 0) {
                setContentView((int) R.layout.generate_card_sms_1_layout);
                initView();
                setSMSCardData(bundle);
            } else if (i == 1) {
                setContentView((int) R.layout.generate_card_sms_2_layout);
                initView();
                setSMSCardData(bundle);
            } else if (i == 2) {
                setContentView((int) R.layout.generate_card_sms_3_layout);
                initView();
                setSMSCardData(bundle);
            }
        } else if (Constants.TYPE_TEL.equals(str)) {
            if (i == 0) {
                setContentView((int) R.layout.generate_card_tel_1_layout);
                initView();
                setTelCardData(bundle);
            } else if (i == 1) {
                setContentView((int) R.layout.generate_card_tel_2_layout);
                initView();
                setTelCardData(bundle);
            } else if (i == 2) {
                setContentView((int) R.layout.generate_card_tel_3_layout);
                initView();
                setTelCardData(bundle);
            }
        } else if (Constants.TYPE_TEXT.equals(str)) {
            if (i == 0) {
                setContentView((int) R.layout.generate_card_txt_1_layout);
                initView();
                setTxtCardData(bundle);
            } else if (i == 1) {
                setContentView((int) R.layout.generate_card_txt_2_layout);
                initView();
                setTxtCardData(bundle);
            } else if (i == 2) {
                setContentView((int) R.layout.generate_card_txt_3_layout);
                initView();
                setTxtCardData(bundle);
            }
        } else if (Constants.TYPE_URI.equals(str)) {
            if (i == 0) {
                setContentView((int) R.layout.generate_card_url_1_layout);
                initView();
                setUrlCardData(bundle);
            } else if (i == 1) {
                setContentView((int) R.layout.generate_card_url_2_layout);
                initView();
                setUrlCardData(bundle);
            } else if (i == 2) {
                setContentView((int) R.layout.generate_card_url_3_layout);
                initView();
                setUrlCardData(bundle);
            }
        } else if (!Constants.TYPE_WIFI.equals(str)) {
        } else {
            if (i == 0) {
                setContentView((int) R.layout.generate_card_wifi_1_layout);
                initView();
                setWifiCardData(bundle);
            } else if (i == 1) {
                setContentView((int) R.layout.generate_card_wifi_2_layout);
                initView();
                setWifiCardData(bundle);
            } else if (i == 2) {
                setContentView((int) R.layout.generate_card_wifi_3_layout);
                initView();
                setWifiCardData(bundle);
            }
        }
    }

    private void showGenerateCard(String str, int i, Bundle bundle) {
        String string = bundle.getString(Constants.GENERATE_URL_NAME);
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            if (i == 0) {
                this.mFrontCard.setVisibility(View.VISIBLE);
                this.mBackCard.setVisibility(View.VISIBLE);
                setCardData(bundle, string);
            } else if (i == 1) {
                setCardData(bundle, string);
            } else if (i == 2) {
                setCardData(bundle, string);
            } else if (i == 3) {
                setCardData(bundle, string);
            }
        } else if (!Constants.TYPE_CALENDAR.equals(str) && !Constants.TYPE_EMAIL_ADDRESS.equals(str) && !Constants.TYPE_GEO.equals(str) && !"ISBN".equals(str) && !Constants.TYPE_PRODUCT.equals(str) && !Constants.TYPE_SMS.equals(str) && !Constants.TYPE_TEL.equals(str) && !Constants.TYPE_TEXT.equals(str) && !Constants.TYPE_URI.equals(str)) {
            Constants.TYPE_WIFI.equals(str);
        }
    }

    private void setCardData(Bundle bundle, String str) {
        byte[] byteArray = bundle.getByteArray("customQr");
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        this.mCardNameTxt.setText(bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME).toUpperCase());
        this.mCardCompanyNameMain.setText(bundle.getString("company").toUpperCase());
        this.mCardCompanyTxt.setText(bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME).toUpperCase());
        this.mCardMobileTxt.setText(bundle.getString("mobile"));
        this.mCardWebTxt.setText(bundle.getString("web"));
        this.mCardPhoneTxt.setText(bundle.getString("phone"));
        this.mCardJobTitleTxt.setText(bundle.getString("job").toUpperCase());
        this.mCardEmailTxt.setText(bundle.getString("email"));
        this.mCardAddressTxt.setText(bundle.getString("address"));
        this.mCardGeneratedImg.setImageBitmap(decodeByteArray);
    }

    private void setEmailCardData(Bundle bundle) {
        String string = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
        String string2 = bundle.getString("company");
        String upperCase = bundle.getString("web").toUpperCase();
        str2 = "MATMSG:TO:" + upperCase + ";SUB:" + string + ";BODY:" + string2 + ";;";
        byte[] byteArray = bundle.getByteArray("customQr");
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        this.mCardNameTxt.setText(upperCase);
        this.mCardCompanyTxt.setText(string);
        this.mCardWebTxt.setText(string2);
        this.mCardGeneratedImg.setImageBitmap(decodeByteArray);
    }

    private void setGeoCardData(Bundle bundle) {
        String string = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
        String string2 = bundle.getString("company");
        String upperCase = bundle.getString("web").toUpperCase();
        str2 = "geo:" + string + "," + string2;
        byte[] byteArray = bundle.getByteArray("customQr");
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        this.mCardNameTxt.setText(upperCase);
        this.mCardCompanyTxt.setText(string);
        this.mCardWebTxt.setText(string2);
        this.mCardGeneratedImg.setImageBitmap(decodeByteArray);
    }

    private void setISBNCardData(Bundle bundle) {
        String string = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
        String string2 = bundle.getString("company");
        String upperCase = bundle.getString("web").toUpperCase();
        Bitmap createBarCode = CodeUtils.createBarCode(string2, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
        this.mCardNameTxt.setText(string);
        this.mCardCompanyTxt.setText(string);
        TextView textView = this.mCardWebTxt;
        textView.setText(upperCase + " $");
        this.mCardGeneratedImg.setImageBitmap(createBarCode);
    }

    private void setProCardData(Bundle bundle) {
        String string = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
        String string2 = bundle.getString("company");
        String upperCase = bundle.getString("web").toUpperCase();
        Bitmap createBarCode = CodeUtils.createBarCode(string2, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
        this.mCardNameTxt.setText(string);
        this.mCardCompanyTxt.setText(string);
        TextView textView = this.mCardWebTxt;
        textView.setText(upperCase + " $");
        this.mCardGeneratedImg.setImageBitmap(createBarCode);
    }

    private void setSMSCardData(Bundle bundle) {
        String string = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
        String string2 = bundle.getString("company");
        String upperCase = bundle.getString("web").toUpperCase();
        str2 = "smsto:" + string + ":" + string2;
        byte[] byteArray = bundle.getByteArray("customQr");
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        this.mCardNameTxt.setText(upperCase);
        this.mCardCompanyTxt.setText(upperCase);
        this.mCardWebTxt.setText(string2);
        this.mCardAddressTxt.setText(string);
        this.mCardGeneratedImg.setImageBitmap(decodeByteArray);
    }

    private void setTelCardData(Bundle bundle) {
        String upperCase = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME).toUpperCase();
        String string = bundle.getString("company");
        str2 = "tel:" + upperCase;
        byte[] byteArray = bundle.getByteArray("customQr");
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        this.mCardNameTxt.setText(string);
        this.mCardWebTxt.setText(upperCase);
        this.mCardGeneratedImg.setImageBitmap(decodeByteArray);
    }

    private void setTxtCardData(Bundle bundle) {
        String string = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME);
        BitmapFactory.decodeResource(getResources(), R.drawable.ic_main_scan_btn);
        byte[] byteArray = bundle.getByteArray("customQr");
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        this.mCardNameTxt.setText(string);
        this.mCardWebTxt.setText(string);
        this.mCardGeneratedImg.setImageBitmap(decodeByteArray);
    }

    private void setUrlCardData(Bundle bundle) {
        String upperCase = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME).toUpperCase();
        String string = bundle.getString("company");
        if (string == null) {
            string = "http://www.example.com";
        } else if (!string.toLowerCase().contains("http")) {
            string = "http://" + string;
        }
        byte[] byteArray = bundle.getByteArray("customQr");
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        this.mCardNameTxt.setText(string);
        this.mCardCompanyTxt.setText(upperCase);
        this.mCardGeneratedImg.setImageBitmap(decodeByteArray);
    }

    private void setWifiCardData(Bundle bundle) {
        String upperCase = bundle.getString(AppMeasurementSdk.ConditionalUserProperty.NAME).toUpperCase();
        String string = bundle.getString("company");
        String string2 = bundle.getString("mobile");
        String string3 = bundle.getString("phone");
        if (string2.equals("WPA/WPA2")) {
            string2 = "WPA";
        }
        if (string2.equals("non")) {
            if (string3.equals("true")) {
                str2 = "WIFI:S:" + upperCase + ";P:" + string + ";H:" + string3 + ";;";
            } else {
                str2 = "WIFI:S:" + upperCase + ";P:" + string + ";;";
            }
        } else if (string3.equals("true")) {
            str2 = "WIFI:S:" + upperCase + ";T:" + string2 + ";P:" + string + ";H:" + string3 + ";;";
        } else {
            str2 = "WIFI:S:" + upperCase + ";T:" + string2 + ";P:" + string + ";;";
        }
        byte[] byteArray = bundle.getByteArray("customQr");
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        this.mCardNameTxt.setText(upperCase);
        this.mCardCompanyTxt.setText(upperCase);
        this.mCardWebTxt.setText(string2);
        this.mCardGeneratedImg.setImageBitmap(decodeByteArray);
    }


    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(603979776);
        startActivity(intent);
    }

    public void initAdmobFullAd(Context context) {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            return;
        }
        mInterstitialAdMob = new com.google.android.gms.ads.InterstitialAd(context);
        mInterstitialAdMob.setAdUnitId(Splash_Activity.adModel.getAdMobInter());
        mInterstitialAdMob.setAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdClosed() {
                loadAdmobAd();
            }

            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdOpened() {
                //   super.onAdOpened();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }

            @Override
            public void onAdLeftApplication() {
                super.onAdLeftApplication();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
            }
        });
    }

    public void loadAdmobAd() {
        if (mInterstitialAdMob != null && !mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
        }
    }

    public void showAdmobInterstitial() {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.show();
        }
    }

    private boolean isAdmobLoaded() {
        if (mInterstitialAdMob != null) {
            return mInterstitialAdMob.isLoaded();
        } else {
            return false;
        }
    }

}
