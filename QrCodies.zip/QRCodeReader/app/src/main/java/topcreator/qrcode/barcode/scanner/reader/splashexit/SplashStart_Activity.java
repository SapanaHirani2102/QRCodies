package topcreator.qrcode.barcode.scanner.reader.splashexit;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.ironsource.mediationsdk.IronSource;
import com.ironsource.mediationsdk.logger.IronSourceError;
import com.ironsource.mediationsdk.sdk.InterstitialListener;
import topcreator.qrcode.barcode.scanner.reader.BuildConfig;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainScreenActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SplashStart_Activity extends BaseSplashActivity implements View.OnClickListener {
    public static final int REQ_CODE_GALLERY_CAMERA = 11;
    public static int CAMERA_HEIGHT = 0;
    public static int CAMERA_WIDTH = 0;
    public static int height = 0;
    public static int width;
    int heightScreen;
    int witdhScreen;
    private InterstitialAd mInterstitialAdMob;

    private Uri urishare;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splashstart);

        if (Build.VERSION.SDK_INT >= 23) {
            checkMultiplePermissions();
        }

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        startIronSourceInitTask(this);

        initAdmobFullAd(this);
        loadAdmobAd();

        FrameLayout fb_native_ad = (FrameLayout) findViewById(R.id.fb_native_ad);
        showGOOGLEAdvance1(fb_native_ad);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btn_rate:
                Uri uri1 = Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName());
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri1);
                try {
                    startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    //the device hasn't installed Google Play
                    Toast.makeText(SplashStart_Activity.this, "You don't have Google Play installed", Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.btn_start:
                startActivityForResult(new Intent(SplashStart_Activity.this, MainScreenActivity.class), 101);
                if (Splash_Activity.adModel.getIsAdmobEnable() == 1 && isAdmobLoaded()) {
                    showAdmobInterstitial();
                }
                break;

            case R.id.btn_creation:
                break;

            case R.id.btn_share:
                Bitmap bm = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
                File f = new File(getExternalCacheDir() + "/image.png");
                try {
                    FileOutputStream outStream = new FileOutputStream(f);
                    bm.compress(Bitmap.CompressFormat.PNG, 100, outStream);
                    outStream.flush();
                    outStream.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/*");
                shareIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + getPackageName());

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    urishare = FileProvider.getUriForFile(SplashStart_Activity.this, BuildConfig.APPLICATION_ID +
                            ".provider", f);
                } else {
                    urishare = Uri.fromFile(f);
                }

                shareIntent.putExtra(Intent.EXTRA_STREAM, urishare);
                startActivity(Intent.createChooser(shareIntent, "Share Image using"));
                break;

            case R.id.btn_moreapp:
                try {
                    Uri uri = Uri.parse(Splash_Activity.adModel.getMoreApps());
                    myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(myAppLinkToMarket);
                } catch (Exception e) {
                    Toast.makeText(SplashStart_Activity.this, "You don't have Google Play installed", Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.btn_policy:
                startActivity(new Intent(SplashStart_Activity.this, PolicyActivity.class));
                break;
        }
    }

    private void checkMultiplePermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            List<String> permissionsNeeded = new ArrayList();
            List<String> permissionsList = new ArrayList();
            if (!addPermission(permissionsList, "android.permission.WRITE_EXTERNAL_STORAGE")) {
                permissionsNeeded.add("Write Storage");
            }
            if (!addPermission(permissionsList, "android.permission.READ_EXTERNAL_STORAGE")) {
                permissionsNeeded.add("Read Storage");
            }
            if (permissionsList.size() > 0) {
                requestPermissions((String[]) permissionsList.toArray(new String[permissionsList.size()]), REQ_CODE_GALLERY_CAMERA);
                return;
            }
        }
    }

    private boolean addPermission(List<String> permissionsList, String permission) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(permission);
            if (!shouldShowRequestPermissionRationale(permission)) {
                return false;
            }
        }
        return true;
    }

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQ_CODE_GALLERY_CAMERA:
                Map<String, Integer> perms = new HashMap();
                perms.put("android.permission.WRITE_EXTERNAL_STORAGE", Integer.valueOf(0));
                perms.put("android.permission.READ_EXTERNAL_STORAGE", Integer.valueOf(0));
                for (int i = 0; i < permissions.length; i++) {
                    perms.put(permissions[i], Integer.valueOf(grantResults[i]));
                }

                if (((Integer) perms.get("android.permission.READ_EXTERNAL_STORAGE")).intValue() == 0
                        && ((Integer) perms.get("android.permission.WRITE_EXTERNAL_STORAGE")).intValue() == 0) {
                    break;
                } else if (Build.VERSION.SDK_INT >= 23) {
                    Toast.makeText(getApplicationContext(), "My App cannot run without Storage Permissions.\nRelaunch My App or allow permissions in Applications Settings", Toast.LENGTH_LONG).show();
                    finish();
                    break;
                } else {
                    break;
                }
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                return;
        }
    }

    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        startActivityForResult(new Intent(SplashStart_Activity.this, ExitActivity.class), 1010);
        if (IronSource.isInterstitialReady()) {
            //show the interstitial
            IronSource.showInterstitial();
        }
    }


    @Override
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i2 == RESULT_OK && i == 1010) {
            finish();
        } else if (i2 == RESULT_OK && i == 101) {
            if (Splash_Activity.adModel.getIsAdmobEnable() == 1 && isAdmobLoaded()) {
                showAdmobInterstitial();
            }
        }
    }

    public static void startIronSourceInitTask(final Activity activity) {

        // getting advertiser id should be done on a background thread
        AsyncTask<Void, Void, String> task = new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                return IronSource.getAdvertiserId(activity);
            }

            @Override
            protected void onPostExecute(String advertisingId) {
                if (TextUtils.isEmpty(advertisingId)) {
                    advertisingId = Splash_Activity.FALLBACK_USER_ID;
                }
                // we're using an advertisingId as the 'userId'
                initIronSource(Splash_Activity.adModel.getIronAppKey(), advertisingId,activity);
            }
        };
        task.execute();
    }

    public static void initIronSource(String appKey, String userId, Activity activity) {
        IronSource.setInterstitialListener(new InterstitialListener() {
            @Override
            public void onInterstitialAdReady() {

            }

            @Override
            public void onInterstitialAdLoadFailed(IronSourceError ironSourceError) {
                Log.e("print", "onInterstitialAdLoadFailed: " + ironSourceError.getErrorCode());

            }

            @Override
            public void onInterstitialAdOpened() {

            }

            @Override
            public void onInterstitialAdClosed() {
                IronSource.loadInterstitial();
            }

            @Override
            public void onInterstitialAdShowSucceeded() {

            }

            @Override
            public void onInterstitialAdShowFailed(IronSourceError ironSourceError) {
                Log.e("print", "onInterstitialAdShowFailed: " + ironSourceError.getErrorCode());
            }

            @Override
            public void onInterstitialAdClicked() {

            }

        });

        // set the IronSource user id
        IronSource.setUserId(userId);
        // init the IronSource SDK
        IronSource.init(activity, appKey);
        IronSource.loadInterstitial();

    }

    @Override
    protected void onResume() {
        super.onResume();
        IronSource.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        IronSource.onPause(this);
    }

}
