package topcreator.qrcode.barcode.scanner.reader.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.model.FilterTypeModel;
import topcreator.qrcode.barcode.scanner.reader.model.SelectFilterItemModel;
import org.greenrobot.eventbus.EventBus;

public class ScanTypeFilterHolder extends BaseItemHolder<FilterTypeModel> {
    ImageView itemImage;
    TextView itemTxt;

    public ScanTypeFilterHolder(View view) {
        super(view);
        this.itemImage = (ImageView) view.findViewById(R.id.filter_type_img);
        this.itemTxt = (TextView) view.findViewById(R.id.filter_type_txt);
    }

    public void bindData(final FilterTypeModel filterTypeModel, int i, int i2) {
        super.bindData(filterTypeModel, i, i2);
        this.itemImage.setImageResource(filterTypeModel.getItemImage());
        this.itemTxt.setText(filterTypeModel.getItemTxt());
        this.itemView.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                EventBus.getDefault().post(new SelectFilterItemModel(filterTypeModel.getScanType()));
            }
        });
    }
}
