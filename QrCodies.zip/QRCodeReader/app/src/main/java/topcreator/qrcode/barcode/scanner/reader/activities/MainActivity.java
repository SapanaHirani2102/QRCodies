package topcreator.qrcode.barcode.scanner.reader.activities;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.result.FinalResultsHandler;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.events.ButtonClickEvent;
import topcreator.qrcode.barcode.scanner.reader.events.StopScanEvent;
import topcreator.qrcode.barcode.scanner.reader.fragments.BusinessCardFragment;
import topcreator.qrcode.barcode.scanner.reader.fragments.MainBarcodeBookmarkFragment;
import topcreator.qrcode.barcode.scanner.reader.fragments.MainBarcodeHistotyFragment;
import topcreator.qrcode.barcode.scanner.reader.fragments.MainGenerateFragment;
import topcreator.qrcode.barcode.scanner.reader.fragments.MainScanFragment;
import topcreator.qrcode.barcode.scanner.reader.fragments.ResultTypeFilterFragment;
import topcreator.qrcode.barcode.scanner.reader.fragments.ScannedBarcodeBookmarkFragment;
import topcreator.qrcode.barcode.scanner.reader.fragments.ScannedBarcodeInfoFragment;
import topcreator.qrcode.barcode.scanner.reader.fragments.SettingFragment;
import topcreator.qrcode.barcode.scanner.reader.model.ScanDataModel;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.zxing.BarcodeFormat;
//import com.nined.fcm.services.FcmFireBaseInstanceIDService;
import io.reactivex.disposables.Disposable;
import java.util.ArrayList;
import org.greenrobot.eventbus.EventBus;

public class MainActivity extends AppCompatActivity {
    public static final int AZTEC = 4096;
    public static final int CODABAR = 8;
    public static final int CODE_128 = 1;
    public static final int CODE_39 = 2;
    public static final int CODE_93 = 4;
    public static final int DATA_MATRIX = 16;
    public static final int EAN_13 = 32;
    public static final int EAN_8 = 64;
    public static final int ITF = 128;
    public static final int PDF417 = 2048;
    public static final int QR_CODE = 256;
    private static final int RC_BARCODE_CAPTURE = 9001;
    private static final String TAG = "MainActivity";
    public static final int UPC_A = 512;
    public static final int UPC_E = 1024;
    Dialog dialog;
    private Disposable disposable = null;
    private DrawerLayout drawer;
    private FinalResultsHandler finalResultsHandler;
    boolean isAutoFocus;
    boolean isBeepSound;
    boolean isCopyClipboard;
    private ImageView mDrawerMenuImg;
    private CheckBox mFlashCheck;
    private FrameLayout mFragmentLayout;
    private RelativeLayout mGenerateLayout;
    private ImageView mMainBusinessImg;
    private RelativeLayout mMainBusinessLayout;
    private TextView mMainBusinessTxt;
    private ImageView mMainGenerateImg;
    private TextView mMainGenerateTxt;
    private ImageView mMainHistoryImg;
    private RelativeLayout mMainHistoryLayout;
    private TextView mMainHistoryTxt;
    private ImageView mMainScanBtn;
    private ImageView mMainSettingImg;
    private RelativeLayout mMainSettingLayout;
    private TextView mMainSettingTxt;
    private SeekBar mZoomSb;
    private ArrayList<ScanDataModel> scanDataModelList;
    private ScanDatabase scanDatabase;
    private TinyDB tinyDB;

    public static void setWindowFlag(Activity activity, int i, boolean z) {
        Window window = activity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags = i | attributes.flags;
        } else {
            attributes.flags = (i ^ -1) & attributes.flags;
        }
        window.setAttributes(attributes);
    }

    private boolean insertScanData(ScanDataEntity scanDataEntity) {
        this.scanDatabase.scanDataDao().insert(scanDataEntity);
        return true;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);

//        FcmFireBaseInstanceIDService.Companion.subscribeToTopic();
        init();
        this.tinyDB = TinyDB.getInstance(this);
        if (!this.tinyDB.getBoolean(Constants.IS_FIRST_TIME)) {
            this.tinyDB.putBoolean(Constants.SETTING_SOUND, true);
            this.tinyDB.putBoolean(Constants.SETTING_VIBRATION, true);
            this.tinyDB.putBoolean(Constants.SETTING_HISTORY, true);
//            if (FirebaseRemoteConfig.getInstance().getBoolean(Constants.FIRE_AUTO_WEB_SEARCH)) {
                this.tinyDB.putBoolean(Constants.SETTING_WEB_SEARCH, true);
//            } else {
//                this.tinyDB.putBoolean(Constants.SETTING_WEB_SEARCH, false);
//            }
            this.tinyDB.putBoolean(Constants.IS_FIRST_TIME, true);
        }
        Intent intent = getIntent();
        if (intent != null) {
            int intExtra = intent.getIntExtra(Constants.MAIN_FRAG_TYPE, 0);
            if (intExtra == 2) {
                if (!(getSupportFragmentManager().findFragmentById(R.id.fragment_layout) instanceof MainGenerateFragment)) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainGenerateFragment()).commitAllowingStateLoss();
                }
                this.mMainSettingImg.setImageResource(R.drawable.ic_setting);
                this.mMainHistoryImg.setImageResource(R.drawable.ic_history);
                this.mMainBusinessImg.setImageResource(R.drawable.uic_main_business_card);
                this.mMainGenerateImg.setImageResource(R.drawable.uic_main_genrate_btn_enable);
                this.mMainBusinessTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
                this.mMainGenerateTxt.setTextColor(getResources().getColor(R.color.colorAccent));
                this.mMainSettingTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
                this.mMainHistoryTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
            } else if (intExtra == 3) {
                if (!(getSupportFragmentManager().findFragmentById(R.id.fragment_layout) instanceof BusinessCardFragment)) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new BusinessCardFragment()).commitAllowingStateLoss();
                }
                this.mMainSettingImg.setImageResource(R.drawable.ic_setting);
                this.mMainHistoryImg.setImageResource(R.drawable.ic_history);
                this.mMainBusinessImg.setImageResource(R.drawable.uic_main_business_card_enable);
                this.mMainGenerateImg.setImageResource(R.drawable.uic_main_genrate_btn);
                this.mMainBusinessTxt.setTextColor(getResources().getColor(R.color.colorAccent));
                this.mMainGenerateTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
                this.mMainSettingTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
                this.mMainHistoryTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
            } else if (intExtra == 4) {
                if (!(getSupportFragmentManager().findFragmentById(R.id.fragment_layout) instanceof MainBarcodeHistotyFragment)) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeHistotyFragment()).commitAllowingStateLoss();
                }
                this.mMainHistoryTxt.setTextColor(getResources().getColor(R.color.colorAccent));
                this.mMainSettingTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
                this.mMainHistoryImg.setImageResource(R.drawable.ic_history_enable);
                this.mMainSettingImg.setImageResource(R.drawable.ic_setting);
                this.mMainBusinessImg.setImageResource(R.drawable.uic_main_business_card);
                this.mMainGenerateImg.setImageResource(R.drawable.uic_main_genrate_btn);
                this.mMainBusinessTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
                this.mMainGenerateTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
            } else if (intExtra == 1) {
                if (!(getSupportFragmentManager().findFragmentById(R.id.fragment_layout) instanceof MainScanFragment)) {
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainScanFragment()).commitAllowingStateLoss();
                }
                this.mMainSettingImg.setImageResource(R.drawable.ic_setting);
                this.mMainHistoryImg.setImageResource(R.drawable.ic_history);
                this.mMainBusinessImg.setImageResource(R.drawable.uic_main_business_card);
                this.mMainGenerateImg.setImageResource(R.drawable.uic_main_genrate_btn);
                this.mMainBusinessTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
                this.mMainGenerateTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
                this.mMainSettingTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
                this.mMainHistoryTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
            }
        }
        this.mMainScanBtn.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainActivity.lambda$onCreate$0(MainActivity.this, view);
            }
        });
        this.mMainHistoryLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainActivity.lambda$onCreate$1(MainActivity.this, view);
            }
        });
        this.mMainSettingLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainActivity.lambda$onCreate$2(MainActivity.this, view);
            }
        });
        this.mGenerateLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainActivity.lambda$onCreate$3(MainActivity.this, view);
            }
        });
        this.mMainBusinessLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainActivity.lambda$onCreate$4(MainActivity.this, view);
            }
        });
        statusBarSet();
    }

    public static /* synthetic */ void lambda$onCreate$0(MainActivity mainActivity, View view) {
         if (!(mainActivity.getSupportFragmentManager().findFragmentById(R.id.fragment_layout) instanceof MainScanFragment)) {
            mainActivity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainScanFragment()).commitAllowingStateLoss();
        }
        mainActivity.mMainSettingImg.setImageResource(R.drawable.ic_setting);
        mainActivity.mMainHistoryImg.setImageResource(R.drawable.ic_history);
        mainActivity.mMainBusinessImg.setImageResource(R.drawable.uic_main_business_card);
        mainActivity.mMainGenerateImg.setImageResource(R.drawable.uic_main_genrate_btn);
        mainActivity.mMainBusinessTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainGenerateTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainSettingTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainHistoryTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
    }

    public static /* synthetic */ void lambda$onCreate$1(MainActivity mainActivity, View view) {

        if (!(mainActivity.getSupportFragmentManager().findFragmentById(R.id.fragment_layout) instanceof MainBarcodeHistotyFragment)) {
            mainActivity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeHistotyFragment()).commitAllowingStateLoss();
        }
        mainActivity.mMainHistoryTxt.setTextColor(mainActivity.getResources().getColor(R.color.colorAccent));
        mainActivity.mMainSettingTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainHistoryImg.setImageResource(R.drawable.ic_history_enable);
        mainActivity.mMainSettingImg.setImageResource(R.drawable.ic_setting);
        mainActivity.mMainBusinessImg.setImageResource(R.drawable.uic_main_business_card);
        mainActivity.mMainGenerateImg.setImageResource(R.drawable.uic_main_genrate_btn);
        mainActivity.mMainBusinessTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainGenerateTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
    }

    public static /* synthetic */ void lambda$onCreate$2(MainActivity mainActivity, View view) {
        if (!(mainActivity.getSupportFragmentManager().findFragmentById(R.id.fragment_layout) instanceof SettingFragment)) {
            mainActivity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new SettingFragment()).commitAllowingStateLoss();
        }
        mainActivity.mMainSettingTxt.setTextColor(mainActivity.getResources().getColor(R.color.colorAccent));
        mainActivity.mMainHistoryTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainHistoryImg.setImageResource(R.drawable.ic_history);
        mainActivity.mMainSettingImg.setImageResource(R.drawable.ic_setting_enable);
        mainActivity.mMainBusinessImg.setImageResource(R.drawable.uic_main_business_card);
        mainActivity.mMainGenerateImg.setImageResource(R.drawable.uic_main_genrate_btn);
        mainActivity.mMainBusinessTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainGenerateTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
    }

    public static /* synthetic */ void lambda$onCreate$3(MainActivity mainActivity, View view) {
        if (!(mainActivity.getSupportFragmentManager().findFragmentById(R.id.fragment_layout) instanceof MainGenerateFragment)) {
            mainActivity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainGenerateFragment()).commitAllowingStateLoss();
        }
        mainActivity.mMainSettingImg.setImageResource(R.drawable.ic_setting);
        mainActivity.mMainHistoryImg.setImageResource(R.drawable.ic_history);
        mainActivity.mMainBusinessImg.setImageResource(R.drawable.uic_main_business_card);
        mainActivity.mMainGenerateImg.setImageResource(R.drawable.uic_main_genrate_btn_enable);
        mainActivity.mMainBusinessTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainGenerateTxt.setTextColor(mainActivity.getResources().getColor(R.color.colorAccent));
        mainActivity.mMainSettingTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainHistoryTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
    }

    public static /* synthetic */ void lambda$onCreate$4(MainActivity mainActivity, View view) {
        if (!(mainActivity.getSupportFragmentManager().findFragmentById(R.id.fragment_layout) instanceof BusinessCardFragment)) {
            mainActivity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new BusinessCardFragment()).commitAllowingStateLoss();
        }
        mainActivity.mMainSettingImg.setImageResource(R.drawable.ic_setting);
        mainActivity.mMainHistoryImg.setImageResource(R.drawable.ic_history);
        mainActivity.mMainBusinessImg.setImageResource(R.drawable.uic_main_business_card_enable);
        mainActivity.mMainGenerateImg.setImageResource(R.drawable.uic_main_genrate_btn);
        mainActivity.mMainBusinessTxt.setTextColor(mainActivity.getResources().getColor(R.color.colorAccent));
        mainActivity.mMainGenerateTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainSettingTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
        mainActivity.mMainHistoryTxt.setTextColor(mainActivity.getResources().getColor(R.color.main_button_selected_color));
    }

    private void statusBarSet() {
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, 67108864, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(1280);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, 67108864, false);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_bar_color));
        }
    }

    public void buttonClick(View view) {
        EventBus.getDefault().post(new ButtonClickEvent(view));
    }

    private void init() {
        this.mFragmentLayout = (FrameLayout) findViewById(R.id.fragment_layout);
        this.mMainHistoryLayout = (RelativeLayout) findViewById(R.id.main_history_layout);
        this.mMainSettingLayout = (RelativeLayout) findViewById(R.id.main_setting_layout);
        this.mMainScanBtn = (ImageView) findViewById(R.id.main_scan_btn);
        this.mMainSettingTxt = (TextView) findViewById(R.id.main_setting_txt);
        this.mMainSettingImg = (ImageView) findViewById(R.id.main_setting_img);
        this.mMainHistoryImg = (ImageView) findViewById(R.id.main_history_img);
        this.mMainHistoryTxt = (TextView) findViewById(R.id.main_history_txt);
        this.mMainBusinessLayout = (RelativeLayout) findViewById(R.id.main_business_layout);
        this.mGenerateLayout = (RelativeLayout) findViewById(R.id.generate_layout);
        this.mMainBusinessImg = (ImageView) findViewById(R.id.main_business_img);
        this.mMainGenerateImg = (ImageView) findViewById(R.id.main_generate_img);
        this.mMainBusinessTxt = (TextView) findViewById(R.id.main_business_txt);
        this.mMainGenerateTxt = (TextView) findViewById(R.id.main_generate_txt);
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        startActivity(new Intent(this, MainActivity.class));
        finish();
        return true;
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, @Nullable Intent intent) {
        super.onActivityResult(i, i2, intent);
        for (Fragment next : getSupportFragmentManager().getFragments()) {
            if (next instanceof MainScanFragment) {
                next.onActivityResult(i, i2, intent);
            }
        }
    }

    public void onBackPressed() {
        String string = this.tinyDB.getString(Constants.FILTER_TYPE_FRAGMENT);
        String string2 = this.tinyDB.getString(Constants.FILTER_TYPE_BACK);
        Fragment findFragmentById = getSupportFragmentManager().findFragmentById(R.id.fragment_layout);
        boolean z = findFragmentById instanceof ScannedBarcodeInfoFragment;
        if (z && this.tinyDB.getBoolean(Constants.IS_INFO_BACK_PRESS)) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeHistotyFragment()).commitAllowingStateLoss();
            this.tinyDB.putBoolean(Constants.IS_INFO_BACK_PRESS, false);
        } else if (findFragmentById instanceof MainScanFragment) {
            finish();
        } else if (findFragmentById instanceof SettingFragment) {
            finish();
        } else if (findFragmentById instanceof MainBarcodeHistotyFragment) {
            if (string2.equals("filterItemSelected")) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new ResultTypeFilterFragment()).commitAllowingStateLoss();
            } else {
                finish();
            }
        }
        if (findFragmentById instanceof MainBarcodeBookmarkFragment) {
            if (string2.equals("filterItemSelected")) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new ResultTypeFilterFragment()).commitAllowingStateLoss();
                return;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeHistotyFragment()).commitAllowingStateLoss();
            this.mMainSettingImg.setImageResource(R.drawable.ic_setting);
            this.mMainHistoryImg.setImageResource(R.drawable.ic_history);
            this.mMainBusinessImg.setImageResource(R.drawable.uic_main_business_card);
            this.mMainGenerateImg.setImageResource(R.drawable.uic_main_genrate_btn);
            this.mMainBusinessTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
            this.mMainGenerateTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
            this.mMainSettingTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
            this.mMainHistoryTxt.setTextColor(getResources().getColor(R.color.main_button_selected_color));
        } else if (z) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeHistotyFragment()).commitAllowingStateLoss();
        } else if (findFragmentById instanceof ScannedBarcodeBookmarkFragment) {
            if (string2.equals("filterItemSelected")) {
                ResultTypeFilterFragment resultTypeFilterFragment = new ResultTypeFilterFragment();
                Bundle bundle = new Bundle();
                bundle.putString(Constants.FILTER_TYPE_LIST, Constants.TYPE_BOOKMARK);
                resultTypeFilterFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, resultTypeFilterFragment).commitAllowingStateLoss();
                return;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeHistotyFragment()).commitAllowingStateLoss();
        } else if (findFragmentById instanceof ResultTypeFilterFragment) {
            if (string.equals("bookmarkFilter")) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeBookmarkFragment()).commitAllowingStateLoss();
            } else if (string.equals("historyFilter")) {
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeHistotyFragment()).commitAllowingStateLoss();
            }
        } else if (findFragmentById instanceof MainGenerateFragment) {
            finish();
        } else if (findFragmentById instanceof BusinessCardFragment) {
            finish();
        }
    }

    public void showDialog() {
        EventBus.getDefault().post(new StopScanEvent(true));
        this.dialog.show();
    }

    private BarcodeFormat getBarcodeFormat(int i) {
        switch (i) {
            case 1:
                return BarcodeFormat.CODE_128;
            case 2:
                return BarcodeFormat.CODE_39;
            case 4:
                return BarcodeFormat.CODE_93;
            case 8:
                return BarcodeFormat.CODABAR;
            case 16:
                return BarcodeFormat.DATA_MATRIX;
            case 32:
                return BarcodeFormat.EAN_13;
            case 64:
                return BarcodeFormat.EAN_8;
            case 128:
                return BarcodeFormat.ITF;
            case 256:
                return BarcodeFormat.QR_CODE;
            case 512:
                return BarcodeFormat.UPC_A;
            case 1024:
                return BarcodeFormat.UPC_E;
            case 2048:
                return BarcodeFormat.PDF_417;
            case 4096:
                return BarcodeFormat.AZTEC;
            default:
                return BarcodeFormat.QR_CODE;
        }
    }

    private void vibration() {
        Vibrator vibrator = (Vibrator) getSystemService("vibrator");
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(500, -1));
        } else {
            vibrator.vibrate(500);
        }
    }

    private void scanSound() {
        new ToneGenerator(3, 100).startTone(94, 150);
    }

    private void ScannedResultProcess(Barcode barcode) {
        scanSound();
        vibration();
        this.tinyDB.putString(Constants.BARCODE_RAW_VALUE, barcode.rawValue);
        this.tinyDB.putInt(Constants.BARCODE_VALUE, barcode.format);
        ScannedBarcodeInfo.start(this, null);
        finish();
    }


    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }

}
