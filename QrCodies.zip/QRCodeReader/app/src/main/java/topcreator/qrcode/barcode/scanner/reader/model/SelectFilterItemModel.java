package topcreator.qrcode.barcode.scanner.reader.model;

public class SelectFilterItemModel {
    String type;

    public SelectFilterItemModel(String str) {
        this.type = str;
    }

    public String getType() {
        return this.type;
    }
}
