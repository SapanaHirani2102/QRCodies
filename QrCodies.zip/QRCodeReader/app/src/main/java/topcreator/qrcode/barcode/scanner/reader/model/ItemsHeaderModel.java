package topcreator.qrcode.barcode.scanner.reader.model;

public class ItemsHeaderModel {
    private String month;
    private String type;
    private String year;

    public ItemsHeaderModel(String str, String str2, String str3) {
        this.month = str2;
        this.year = str3;
        this.type = str;
    }

    public String getMonth() {
        return this.month;
    }

    public void setMonth(String str) {
        this.month = str;
    }

    public String getYear() {
        return this.year;
    }

    public void setYear(String str) {
        this.year = str;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String str) {
        this.type = str;
    }
}
