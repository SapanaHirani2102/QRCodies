package topcreator.qrcode.barcode.scanner.reader.model;

import androidx.annotation.DrawableRes;

public class FilterTypeModel {
    @DrawableRes
    private int itemBackground;
    @DrawableRes
    private int itemImage;
    private String itemTxt;
    private String scanType;

    public FilterTypeModel(int i, int i2, String str, String str2) {
        this.itemImage = i;
        this.itemBackground = i2;
        this.itemTxt = str;
        this.scanType = str2;
    }

    public int getItemImage() {
        return this.itemImage;
    }

    public int getItemBackground() {
        return this.itemBackground;
    }

    public String getItemTxt() {
        return this.itemTxt;
    }

    public String getScanType() {
        return this.scanType;
    }
}
