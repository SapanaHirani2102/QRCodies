package topcreator.qrcode.barcode.scanner.reader.activities;

import android.util.Log;
import io.reactivex.functions.Consumer;

/* renamed from: topcreator.qrcode.barcode.scanner.reader.activities.-$$Lambda$SelectCardResultActivity$4LHSn_EAZrfEIm6-9JHaJuv4Kuw  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$SelectCardResultActivity$4LHSn_EAZrfEIm69JHaJuv4Kuw implements Consumer {
    public static final /* synthetic */ $$Lambda$SelectCardResultActivity$4LHSn_EAZrfEIm69JHaJuv4Kuw INSTANCE = new $$Lambda$SelectCardResultActivity$4LHSn_EAZrfEIm69JHaJuv4Kuw();

    private /* synthetic */ $$Lambda$SelectCardResultActivity$4LHSn_EAZrfEIm69JHaJuv4Kuw() {
    }

    public final void accept(Object obj) {
        Log.e("Bookmark", "Generate Result: " + ((Throwable) obj).getMessage());
    }
}
