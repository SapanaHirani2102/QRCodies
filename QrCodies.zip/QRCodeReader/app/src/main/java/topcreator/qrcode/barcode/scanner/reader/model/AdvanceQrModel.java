package topcreator.qrcode.barcode.scanner.reader.model;

import androidx.annotation.DrawableRes;

public class AdvanceQrModel {
    @DrawableRes
    private int logo;
    private int non;
    private int style;
    private String type;

    public AdvanceQrModel(int i, String str) {
        this.logo = i;
        this.type = str;
    }

    public AdvanceQrModel(int i, String str, int i2) {
        this.logo = i;
        this.type = str;
        this.style = i2;
    }

    public AdvanceQrModel(int i, String str, int i2, int i3) {
        this.logo = i;
        this.type = str;
        this.style = i2;
        this.non = i3;
    }

    public int getNon() {
        return this.non;
    }

    public void setNon(int i) {
        this.non = i;
    }

    public int getStyle() {
        return this.style;
    }

    public int getLogo() {
        return this.logo;
    }

    public String getType() {
        return this.type;
    }
}
