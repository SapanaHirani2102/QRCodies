package topcreator.qrcode.barcode.scanner.reader.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Environment;
import android.util.Log;
import androidx.annotation.NonNull;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ImageSaver {
    private Context context;
    private String directoryName = "images";
    private boolean external;
    private String fileName = "image.png";

    public ImageSaver(Context context2) {
        this.context = context2;
    }

    public static boolean isExternalStorageWritable() {
        return "mounted".equals(Environment.getExternalStorageState());
    }

    public static boolean isExternalStorageReadable() {
        String externalStorageState = Environment.getExternalStorageState();
        return "mounted".equals(externalStorageState) || "mounted_ro".equals(externalStorageState);
    }

    public ImageSaver setFileName(String str) {
        this.fileName = str;
        return this;
    }

    public ImageSaver setExternal(boolean z) {
        this.external = z;
        return this;
    }

    public ImageSaver setDirectoryName(String str) {
        this.directoryName = str;
        return this;
    }

    public void save(Bitmap bitmap)  {
        FileOutputStream fileOutputStream = null;
        try {
            FileOutputStream fileOutputStream2 = new FileOutputStream(createFile());
            try {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream2);
            } catch (Exception e) {
                fileOutputStream = fileOutputStream2;
                try {
                    e.printStackTrace();
                    if (fileOutputStream == null) {
                    }
                } catch (Exception th) {
                    if (fileOutputStream != null) {
                    }
                    throw th;
                }
            }
            try {
                fileOutputStream2.close();
            } catch (IOException e3) {
                e3.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (fileOutputStream == null) {
                try {
                    fileOutputStream.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    public void saveCompress(Bitmap bitmap) {
        FileOutputStream fileOutputStream = null;
        try {
            FileOutputStream fileOutputStream2 = new FileOutputStream(createFile());
            try {
                getResizedBitmap(bitmap, 400, 120).compress(Bitmap.CompressFormat.JPEG, 60, fileOutputStream2);
            } catch (Exception e) {
                fileOutputStream = fileOutputStream2;
                try {
                    e.printStackTrace();
                    if (fileOutputStream == null) {
                        fileOutputStream.close();
                        return;
                    }
                    return;
                } catch (Exception th) {
                    if (fileOutputStream != null) {
                        try {
                            fileOutputStream.close();
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                    throw th;
                }
            }
            try {
                fileOutputStream2.close();
            } catch (IOException e3) {
                e3.printStackTrace();
            }
        } catch (Exception e4) {
            e4.printStackTrace();
            if (fileOutputStream == null) {
            }
        }
    }

    private Bitmap getResizedBitmap(Bitmap bitmap, int i, int i2) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Matrix matrix = new Matrix();
        matrix.postScale(((float) i) / ((float) width), ((float) i2) / ((float) height));
        return Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, false);
    }

    @NonNull
    private File createFile() {
        File file;
        if (this.external) {
            file = getAlbumStorageDir(this.directoryName);
        } else {
            file = this.context.getDir(this.directoryName, 0);
        }
        if (!file.exists() && !file.mkdirs()) {
            Log.e("ImageSaver", "Error creating directory " + file);
        }
        return new File(file, this.fileName);
    }

    private File getAlbumStorageDir(String str) {
        return new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), str);
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0022 A[SYNTHETIC, Splitter:B:17:0x0022] */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0031 A[SYNTHETIC, Splitter:B:25:0x0031] */
    public Bitmap load() {
        FileInputStream fileInputStream;
        FileInputStream fileInputStream2 = null;
        try {
            fileInputStream = new FileInputStream(createFile());
            try {
                Bitmap decodeStream = BitmapFactory.decodeStream(fileInputStream);
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return decodeStream;
            } catch (Exception e2) {
                try {
                    e2.printStackTrace();
                    if (fileInputStream != null) {
                    }
                    return null;
                } catch (Exception th2) {
                    FileInputStream fileInputStream3 = fileInputStream;
                    fileInputStream2 = fileInputStream3;
                    if (fileInputStream2 != null) {
                    }
                }
            }
        } catch (Exception e3) {
            fileInputStream = null;
            e3.printStackTrace();
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e4) {
                    e4.printStackTrace();
                }
            }
            return null;
        }
        return null;
    }

    public void deleteAllFile() {
        File file = new File(this.context.getDir(this.directoryName, 0), "");
        if (file.isDirectory()) {
            for (String file2 : file.list()) {
                new File(file, file2).delete();
            }
        }
    }

    public void deleteSingleFile() {
        File createFile = createFile();
        if (createFile.exists()) {
            createFile.delete();
        }
    }

    public File getFilePath() {
        return createFile();
    }
}