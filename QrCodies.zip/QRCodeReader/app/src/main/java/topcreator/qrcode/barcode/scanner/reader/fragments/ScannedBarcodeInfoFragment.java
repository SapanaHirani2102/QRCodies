package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Patterns;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.activities.WebviewActivity;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.ScannedResultManager;
import topcreator.qrcode.barcode.scanner.reader.database.GenerateBookmarkDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDataBookmarkEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.events.ButtonClickEvent;
import topcreator.qrcode.barcode.scanner.reader.splashexit.Splash_Activity;
import topcreator.qrcode.barcode.scanner.reader.utils.CodeUtils;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.ImageSaver;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import com.google.gson.Gson;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.google.zxing.client.result.ParsedResult;
import com.google.zxing.client.result.ResultParser;
import com.nabinbhandari.android.permissions.PermissionHandler;
import com.nabinbhandari.android.permissions.Permissions;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class ScannedBarcodeInfoFragment extends Fragment {
    public static final int AZTEC = 4096;
    public static final int CODABAR = 8;
    public static final int CODE_128 = 1;
    public static final int CODE_39 = 2;
    public static final int CODE_93 = 4;
    public static final int DATA_MATRIX = 16;
    public static final int EAN_13 = 32;
    public static final int EAN_8 = 64;
    public static final int ITF = 128;
    public static final int PDF417 = 2048;
    public static final int QR_CODE = 256;
    public static final int UPC_A = 512;
    public static final int UPC_E = 1024;
    public static final String URL = "https://www.google.com/search?q=";
    private String TAG = "scannedInfo";
    /* access modifiers changed from: private */
    public Activity activity;
    private boolean checkBookmarked = false;
    private GenerateBookmarkDataEntity generateBookmarkDataEntity;
    private String generateItem;
    private boolean isAutoCopy = false;
    private boolean isAutoWebSearch = false;
    private boolean isSaveHistory = false;
    private boolean isScanActivity = false;
    private ImageView mBookmarkImg;
    private RelativeLayout mBookmarkLayout;
    private CardView mBottomCardLayout;
    private CardView mCardLayout;
    private ImageView mCopyImg;
    private RelativeLayout mCopyLayout;
    private RelativeLayout mHistoryLayout;
    private ImageView mProductTypeImg;
    private RelativeLayout mScanLayout;
    private ImageView mScannedImg;
    private RelativeLayout mScannedLayout;
    private TextView mScannedTxt;
    private ScrollView mScrollLayout;
    private ImageView mSearchImg;
    private RelativeLayout mSearchLayout;
    private ImageView mShareImg;
    private RelativeLayout mShareLayout;
    private TextView mTimeTxt;
    private TextView mTypeTxt;
    private View mViewOffsetHelper;
    /* access modifiers changed from: private */
    public CardView mWebCardLayout;
    /* access modifiers changed from: private */
    public ProgressBar mWebProBar;
    /* access modifiers changed from: private */
    public WebView mWebView;
    private ParsedResult parsedResult;
    private String resultTypeSelected = "";
    /* access modifiers changed from: private */
    public Bitmap saveBitmap;
    private ScanDataBookmarkEntity scanDataBookmarkEntity;
    private ScanDatabase scanDatabase;
    private ScannedResultManager scannedResultManager;
    private TinyDB tinyDB;
    private View view;
    private FrameLayout adMobView;

    static /* synthetic */ void lambda$showRateUsDialog$8(String str) {
    }

    public static boolean isNetworkStatusAvialable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        if (connectivityManager != null) {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                return true;
            }
        }
        return false;
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (MainActivity) context;
        }
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        this.view = layoutInflater.inflate(R.layout.activity_scanned_barcode_info, viewGroup, false);
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        this.activity.getWindow().clearFlags(1024);
        initView();
        adMobView = (FrameLayout) view.findViewById(R.id.adMobView);
        showBanner();

        getBundle();
        return this.view;
    }

    private void clickListeners() {
        this.mScannedTxt.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScannedBarcodeInfoFragment.lambda$clickListeners$0(ScannedBarcodeInfoFragment.this, view);
            }
        });
        this.mSearchLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScannedBarcodeInfoFragment.lambda$clickListeners$1(ScannedBarcodeInfoFragment.this, view);
            }
        });
        this.mCopyLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScannedBarcodeInfoFragment.lambda$clickListeners$2(ScannedBarcodeInfoFragment.this, view);
            }
        });
        this.mShareLayout.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ScannedBarcodeInfoFragment.lambda$clickListeners$3(ScannedBarcodeInfoFragment.this, view);
            }
        });
    }

    public static /* synthetic */ void lambda$clickListeners$0(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, View view2) {
        if (scannedBarcodeInfoFragment.mTypeTxt.getText().toString().equals("Weblink")) {
            scannedBarcodeInfoFragment.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(scannedBarcodeInfoFragment.mScannedTxt.getText().toString())));
        }
    }

    public static /* synthetic */ void lambda$clickListeners$1(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, View view2) {
        if (scannedBarcodeInfoFragment.mTypeTxt.getText().toString().equals("Weblink")) {
            scannedBarcodeInfoFragment.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(scannedBarcodeInfoFragment.mScannedTxt.getText().toString())));
            return;
        }
        scannedBarcodeInfoFragment.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://www.google.com/search?q=" + scannedBarcodeInfoFragment.mScannedTxt.getText().toString())));
    }

    public static /* synthetic */ void lambda$clickListeners$2(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, View view2) {
        ClipboardManager clipboardManager = (ClipboardManager) scannedBarcodeInfoFragment.activity.getSystemService("clipboard");
        ClipData newPlainText = ClipData.newPlainText("label", scannedBarcodeInfoFragment.mScannedTxt.getText().toString());
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(newPlainText);
            Toast makeText = Toast.makeText(scannedBarcodeInfoFragment.activity.getApplicationContext(), "Copied to clipboard", 0);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        }
    }

    public static /* synthetic */ void lambda$clickListeners$3(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, View view2) {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.TEXT", scannedBarcodeInfoFragment.mScannedTxt.getText().toString());
        intent.setType("text/plain");
        scannedBarcodeInfoFragment.startActivity(intent);
    }

    private boolean insertBookMarkScanData(ScanDataBookmarkEntity scanDataBookmarkEntity2) {
        this.scanDatabase.scanDataDao().insert(scanDataBookmarkEntity2);
        return true;
    }

    private boolean insertBookMarkGenData(GenerateBookmarkDataEntity generateBookmarkDataEntity2) {
        this.scanDatabase.scanDataDao().insert(generateBookmarkDataEntity2);
        return true;
    }

    private boolean insertScanData(ScanDataEntity scanDataEntity) {
        this.scanDatabase.scanDataDao().insert(scanDataEntity);
        return true;
    }

    private void autoCopyClipboard() {
        ClipboardManager clipboardManager = (ClipboardManager) this.activity.getSystemService("clipboard");
        ClipData newPlainText = ClipData.newPlainText("label", this.mTimeTxt.getText());
        if (clipboardManager != null) {
            clipboardManager.setPrimaryClip(newPlainText);
            Toast makeText = Toast.makeText(this.activity.getApplicationContext(), "Copied to clipboard", 0);
            makeText.setGravity(17, 0, 0);
            makeText.show();
        }
    }

    private void getBundle() {
        Bundle arguments = getArguments();
        if (arguments != null) {
            String string = arguments.getString(Constants.GENERATE_TYPE);
            if (string == null) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
                SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("dd MMM yyyy,  hh:mm a", Locale.ENGLISH);
                SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
                this.mTimeTxt.setText(arguments.getString(Constants.SCANNED_TIME, ""));
                if (arguments.getString(Constants.SCANNED_TYPE, "").equals(Constants.TYPE_URI)) {
                    SpannableString spannableString = new SpannableString(arguments.getString(Constants.SCANNED_TXT, ""));
                    spannableString.setSpan(new UnderlineSpan(), 0, spannableString.length(), 0);
                    this.mScannedTxt.setText(spannableString);
                } else {
                    this.mScannedTxt.setText(arguments.getString(Constants.SCANNED_TXT, ""));
                }
                this.mScannedImg.setImageBitmap(getImage(this.activity, arguments.getString(Constants.SCANNED_IMG, "")));
                this.saveBitmap = getImage(this.activity, arguments.getString(Constants.SCANNED_IMG, ""));
                String string2 = arguments.getString(Constants.SCANNED_RESULT, "");
                Result result = (Result) new Gson().fromJson(string2, Result.class);
                this.parsedResult = ResultParser.parseResult(result);
                String parsedResultType = this.parsedResult.getType().toString();
                ScanDataBookmarkEntity scanDataBookmarkEntity2 = new ScanDataBookmarkEntity(result.getText(), this.parsedResult.getType().toString(), arguments.getString(Constants.SCANNED_IMG, ""), simpleDateFormat2.format(Long.valueOf(result.getTimestamp())), simpleDateFormat3.format(Long.valueOf(result.getTimestamp())), string2, simpleDateFormat.format(Long.valueOf(result.getTimestamp())));
                this.scanDataBookmarkEntity = scanDataBookmarkEntity2;
                this.resultTypeSelected = result.getText();
                if (getBookmarkSize(result.getText()) > 0) {
                    this.checkBookmarked = true;
                }
                setViewVisible(parsedResultType, this.view, this.checkBookmarked);
                this.isScanActivity = true;
            } else if (string.equals("GenerateItem")) {
                String string3 = arguments.getString(Constants.SCANNED_TYPE);
                this.generateBookmarkDataEntity = new GenerateBookmarkDataEntity(arguments.getString(Constants.SCANNED_TXT), arguments.getString(Constants.SCANNED_TYPE), arguments.getString(Constants.SCANNED_TIME), arguments.getString(Constants.GENERATE_SQL_DATE));
                this.resultTypeSelected = arguments.getString(Constants.SCANNED_TXT);
                if (getGenBookmarkSize(arguments.getString(Constants.SCANNED_TXT)) > 0) {
                    this.checkBookmarked = true;
                }
                setViewVisible(string3, this.view, arguments);
                this.generateItem = "GenerateItem";
            }
        } else {
            mainCalculations(this.view);
        }
    }

    private BarcodeFormat getBarcodeFormat(int i) {
        switch (i) {
            case 1:
                return BarcodeFormat.CODE_128;
            case 2:
                return BarcodeFormat.CODE_39;
            case 4:
                return BarcodeFormat.CODE_93;
            case 8:
                return BarcodeFormat.CODABAR;
            case 16:
                return BarcodeFormat.DATA_MATRIX;
            case 32:
                return BarcodeFormat.EAN_13;
            case 64:
                return BarcodeFormat.EAN_8;
            case 128:
                return BarcodeFormat.ITF;
            case 256:
                return BarcodeFormat.QR_CODE;
            case 512:
                return BarcodeFormat.UPC_A;
            case 1024:
                return BarcodeFormat.UPC_E;
            case 2048:
                return BarcodeFormat.PDF_417;
            case 4096:
                return BarcodeFormat.AZTEC;
            default:
                return BarcodeFormat.QR_CODE;
        }
    }

    private void mainCalculations(View view2) {
        Bitmap bitmap;
        int i;
        String string = this.tinyDB.getString(Constants.BARCODE_RAW_VALUE);
        int i2 = this.tinyDB.getInt(Constants.BARCODE_VALUE);
        Result result = new Result(string, null, null, getBarcodeFormat(i2));
        String json = new Gson().toJson((Object) result);
        if (i2 == 256 || i2 == 2048 || i2 == 4096 || i2 == 16) {
            try {
                bitmap = CodeUtils.createBarCode(string, getBarcodeFormat(i2), 350, 350);
            } catch (Exception unused) {
                bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.non_qr);
            }
        } else {
            try {
                bitmap = CodeUtils.createBarCode(string, getBarcodeFormat(i2), 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            } catch (Exception unused2) {
                bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.non_qr);
            }
        }
        this.resultTypeSelected = result.getText();
        this.parsedResult = ResultParser.parseResult(result);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd MMM yyyy,  hh:mm a", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        String format = simpleDateFormat.format(Long.valueOf(result.getTimestamp()));
        String format2 = simpleDateFormat2.format(Long.valueOf(result.getTimestamp()));
        SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        String str = "image-" + result.getTimestamp() + ".jpg";
        this.mTimeTxt.setText(format);
        setViewVisible(this.parsedResult.getType().toString(), view2, false);
        this.mScannedImg.setImageBitmap(bitmap);
        this.saveBitmap = bitmap;
        this.isScanActivity = false;
        String str2 = format2;
        String str3 = json;
        final ScanDataEntity scanDataEntity = new ScanDataEntity(result.getText(), this.parsedResult.getType().toString(), str, format, str2, str3, simpleDateFormat3.format(Long.valueOf(result.getTimestamp())));
        String str4 = format;
        ScanDataBookmarkEntity scanDataBookmarkEntity3 = new ScanDataBookmarkEntity(result.getText(), this.parsedResult.getType().toString(), str, str4, str2, str3, simpleDateFormat3.format(Long.valueOf(result.getTimestamp())));
        this.scanDataBookmarkEntity = scanDataBookmarkEntity3;
        if (this.isSaveHistory) {
            new ImageSaver(this.activity).setFileName(str).setDirectoryName(Constants.SAVE_DIR_NAME).save(bitmap);
            List<ScanDataEntity> checkItem = this.scanDatabase.scanDataDao().checkItem(result.getText());
            if (checkItem.size() > 0) {
                i = 0;
                new ImageSaver(this.activity).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(checkItem.get(0).getScannedImg()).deleteSingleFile();
            } else {
                i = 0;
            }
            Single.fromCallable(new Callable() {
                public final Object call() {
                    return Boolean.valueOf(ScannedBarcodeInfoFragment.this.insertScanData(scanDataEntity));
                }
            }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer() {
                public final void accept(Object obj) {
                    ScannedBarcodeInfoFragment.lambda$mainCalculations$5(ScannedBarcodeInfoFragment.this, (Boolean) obj);
                }
            }, new Consumer() {
                public final void accept(Object obj) {
                    ScannedBarcodeInfoFragment.lambda$mainCalculations$6(ScannedBarcodeInfoFragment.this, (Throwable) obj);
                }
            });
        } else {
            i = 0;
        }
        if (this.isAutoCopy) {
            autoCopyClipboard();
        }
        int i3 = this.tinyDB.getInt(Constants.DIALOG_SESSION);
        if (i3 <= 2) {
            this.tinyDB.putInt(Constants.DIALOG_SESSION, i3 + 1);
        } else if (!this.tinyDB.getBoolean(Constants.DIALOG_SUBMIT) && !this.tinyDB.getBoolean(Constants.DIALOG_CANCEL)) {
            this.tinyDB.putInt(Constants.DIALOG_SESSION, i);
        }
    }

    public static /* synthetic */ void lambda$mainCalculations$5(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, Boolean bool) {
        String str = scannedBarcodeInfoFragment.TAG;
        Log.e(str, "Data Inserted: " + bool);
    }

    public static /* synthetic */ void lambda$mainCalculations$6(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, Throwable th) {
        String str = scannedBarcodeInfoFragment.TAG;
        Log.e(str, "barcodeResult: " + th.getMessage());
    }

    public static /* synthetic */ void lambda$showRateUsDialog$7(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, float f, boolean z) {
        scannedBarcodeInfoFragment.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=" + scannedBarcodeInfoFragment.activity.getPackageName())));
        scannedBarcodeInfoFragment.tinyDB.putBoolean(Constants.DIALOG_SUBMIT, true);
    }

    private void webView() {
        if (this.isAutoWebSearch && isNetworkStatusAvialable(this.activity)) {
            new Handler();
            this.mWebView.getSettings();
            this.activity.runOnUiThread(new Runnable() {
                public final void run() {
                    ScannedBarcodeInfoFragment.lambda$webView$10(ScannedBarcodeInfoFragment.this);
                }
            });
        }
    }


    public static /* synthetic */ void lambda$webView$10(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment) {
        char c;
        String charSequence = scannedBarcodeInfoFragment.mTypeTxt.getText().toString();
        int hashCode = charSequence.hashCode();
        if (hashCode == 84303) {
            if (charSequence.equals("URL")) {
                c = 3;
                switch (c) {
                    case 0:
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                }
            }
        } else if (hashCode == 2256630) {
            if (charSequence.equals("ISBN")) {
                c = 0;
                switch (c) {
                    case 0:
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                }
            }
        } else if (hashCode == 2603341) {
            if (charSequence.equals("Text")) {
                c = 2;
                switch (c) {
                    case 0:
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                }
            }
        } else if (hashCode == 1355179215 && charSequence.equals("Product")) {
            c = 1;
            switch (c) {
                case 0:
                    scannedBarcodeInfoFragment.loadWebPage("https://www.google.com/search?q=" + scannedBarcodeInfoFragment.mScannedTxt.getText().toString());
                    return;
                case 1:
                    scannedBarcodeInfoFragment.loadWebPage("https://www.google.com/search?q=" + scannedBarcodeInfoFragment.mScannedTxt.getText().toString());
                    return;
                case 2:
                    scannedBarcodeInfoFragment.loadWebPage("https://www.google.com/search?q=" + scannedBarcodeInfoFragment.mScannedTxt.getText().toString());
                    return;
                case 3:
                    scannedBarcodeInfoFragment.loadWebPage(scannedBarcodeInfoFragment.mScannedTxt.getText().toString());
                    return;
                default:
                    return;
            }
        }
        c = 65535;
        switch (c) {
            case 0:
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
        }
    }


    private void initView() {
        this.mSearchImg = (ImageView) this.view.findViewById(R.id.search_img);
        this.mCopyImg = (ImageView) this.view.findViewById(R.id.copy_img);
        this.mScannedTxt = (TextView) this.view.findViewById(R.id.scanned_txt);
        this.mViewOffsetHelper = this.view.findViewById(R.id.view_offset_helper);
        this.mProductTypeImg = (ImageView) this.view.findViewById(R.id.product_type_img);
        this.mTimeTxt = (TextView) this.view.findViewById(R.id.time_txt);
        this.mScannedImg = (ImageView) this.view.findViewById(R.id.scanned_img);
        this.mShareImg = (ImageView) this.view.findViewById(R.id.share_img);
        this.mTypeTxt = (TextView) this.view.findViewById(R.id.type_txt);
        this.mWebProBar = (ProgressBar) this.view.findViewById(R.id.web_pro_bar);
        this.mBookmarkImg = (ImageView) this.view.findViewById(R.id.bookmark_img);
        this.mCopyLayout = (RelativeLayout) this.view.findViewById(R.id.copy_layout);
        this.mScannedLayout = (RelativeLayout) this.view.findViewById(R.id.scanned_layout);
        this.mSearchLayout = (RelativeLayout) this.view.findViewById(R.id.search_layout);
        this.mShareLayout = (RelativeLayout) this.view.findViewById(R.id.share_layout);
        this.mWebView = (WebView) this.view.findViewById(R.id.web_view);
        this.mScrollLayout = (ScrollView) this.view.findViewById(R.id.scroll_layout);
        this.mWebCardLayout = (CardView) this.view.findViewById(R.id.web_card_layout);
        this.scannedResultManager = new ScannedResultManager(this.activity);
        this.scanDatabase = ScanDatabase.getInstance(this.activity);
        this.tinyDB = TinyDB.getInstance(this.activity);
        this.isAutoCopy = this.tinyDB.getBoolean(Constants.SETTING_AUTO_COPY);
        this.isAutoWebSearch = this.tinyDB.getBoolean(Constants.SETTING_WEB_SEARCH);
        this.isSaveHistory = this.tinyDB.getBoolean(Constants.SETTING_HISTORY);
    }

    private int getBookmarkSize(String str) {
        return this.scanDatabase.scanDataDao().checkBookMark(str).size();
    }

    private int getGenBookmarkSize(String str) {
        return this.scanDatabase.scanDataDao().checkGenBookMark(str).size();
    }

    private void setViewVisible(String str, View view2, boolean z) {
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            View findViewById = view2.findViewById(R.id.address_layout);
            findViewById.setVisibility(View.VISIBLE);
            ImageView imageView = (ImageView) findViewById.findViewById(R.id.bookmark_img);
            if (z) {
                imageView.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText("Address Book");
            this.mProductTypeImg.setImageResource(R.drawable.i_add);
            this.mScannedTxt.setText(this.scannedResultManager.addressResultContent(this.parsedResult));
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            View findViewById2 = view2.findViewById(R.id.calender_layout);
            findViewById2.setVisibility(View.VISIBLE);
            ImageView imageView2 = (ImageView) findViewById2.findViewById(R.id.bookmark_img);
            if (z) {
                imageView2.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText("Calender");
            this.mProductTypeImg.setImageResource(R.drawable.i_cal1);
            this.mScannedTxt.setText(this.scannedResultManager.calenderResultContent(this.parsedResult));
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            View findViewById3 = view2.findViewById(R.id.email_layout);
            findViewById3.setVisibility(View.VISIBLE);
            ImageView imageView3 = (ImageView) findViewById3.findViewById(R.id.bookmark_img);
            if (z) {
                imageView3.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText("Mail");
            this.mProductTypeImg.setImageResource(R.drawable.i_email);
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
        } else if (Constants.TYPE_GEO.equals(str)) {
            View findViewById4 = view2.findViewById(R.id.geo_layout);
            findViewById4.setVisibility(View.VISIBLE);
            ImageView imageView4 = (ImageView) findViewById4.findViewById(R.id.bookmark_img);
            if (z) {
                imageView4.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText("Geo Location");
            this.mProductTypeImg.setImageResource(R.drawable.i_loc);
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
        } else if ("ISBN".equals(str)) {
            View findViewById5 = view2.findViewById(R.id.isbn_layout);
            findViewById5.setVisibility(View.VISIBLE);
            ImageView imageView5 = (ImageView) findViewById5.findViewById(R.id.bookmark_img);
            if (z) {
                imageView5.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText("ISBN");
            this.mProductTypeImg.setImageResource(R.drawable.i_isbn);
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            webView();
        } else if (Constants.TYPE_PRODUCT.equals(str)) {
            View findViewById6 = view2.findViewById(R.id.product_layout);
            findViewById6.setVisibility(View.VISIBLE);
            ImageView imageView6 = (ImageView) findViewById6.findViewById(R.id.bookmark_img);
            if (z) {
                imageView6.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText("Product");
            this.mProductTypeImg.setImageResource(R.drawable.i_product);
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            webView();
        } else if (Constants.TYPE_SMS.equals(str)) {
            View findViewById7 = view2.findViewById(R.id.sms_layout);
            findViewById7.setVisibility(View.VISIBLE);
            ImageView imageView7 = (ImageView) findViewById7.findViewById(R.id.bookmark_img);
            if (z) {
                imageView7.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText(Constants.TYPE_SMS);
            this.mProductTypeImg.setImageResource(R.drawable.i_msgs);
            this.mScannedTxt.setText(this.scannedResultManager.smsResultContent(this.parsedResult));
        } else if (Constants.TYPE_TEL.equals(str)) {
            View findViewById8 = view2.findViewById(R.id.contact_layout);
            findViewById8.setVisibility(View.VISIBLE);
            ImageView imageView8 = (ImageView) findViewById8.findViewById(R.id.bookmark_img);
            if (z) {
                imageView8.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText("Contact");
            this.mProductTypeImg.setImageResource(R.drawable.i_call);
            this.mScannedTxt.setText(this.scannedResultManager.telResultContent(this.parsedResult));
        } else if (Constants.TYPE_TEXT.equals(str)) {
            View findViewById9 = view2.findViewById(R.id.product_layout);
            findViewById9.setVisibility(View.VISIBLE);
            ImageView imageView9 = (ImageView) findViewById9.findViewById(R.id.bookmark_img);
            if (z) {
                imageView9.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText("Text");
            this.mProductTypeImg.setImageResource(R.drawable.i_text);
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            webView();
        } else if (Constants.TYPE_URI.equals(str)) {
            View findViewById10 = view2.findViewById(R.id.product_layout);
            findViewById10.setVisibility(View.VISIBLE);
            ImageView imageView10 = (ImageView) findViewById10.findViewById(R.id.bookmark_img);
            if (z) {
                imageView10.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText("URL");
            this.mProductTypeImg.setImageResource(R.drawable.i_url);
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            TextView textView = this.mScannedTxt;
            textView.setPaintFlags(textView.getPaintFlags() | 8);
            this.mScannedTxt.setTextColor(getResources().getColor(R.color.blue));
            this.mScannedTxt.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    ScannedBarcodeInfoFragment.lambda$setViewVisible$11(ScannedBarcodeInfoFragment.this, view);
                }
            });
            webView();
        } else if (Constants.TYPE_WIFI.equals(str)) {
            View findViewById11 = view2.findViewById(R.id.wifi_layout);
            findViewById11.setVisibility(View.VISIBLE);
            ImageView imageView11 = (ImageView) findViewById11.findViewById(R.id.bookmark_img);
            if (z) {
                imageView11.setImageResource(R.drawable.i_bookmark_select);
            }
            this.mTypeTxt.setText("Wifi");
            this.mProductTypeImg.setImageResource(R.drawable.i_wifi);
            this.mScannedTxt.setText(this.scannedResultManager.wifiResultContent(this.parsedResult));
        }
    }

    public static /* synthetic */ void lambda$setViewVisible$11(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, View view2) {
        if (!isNetworkStatusAvialable(scannedBarcodeInfoFragment.activity)) {
            Toast.makeText(scannedBarcodeInfoFragment.activity, "Please check your internet connection..!", 0).show();
        } else if (scannedBarcodeInfoFragment.isValidUrl(scannedBarcodeInfoFragment.mScannedTxt.getText().toString())) {
            try {
                scannedBarcodeInfoFragment.activity.startActivity(new Intent(scannedBarcodeInfoFragment.activity, WebviewActivity.class).putExtra("SEARCH_URL", scannedBarcodeInfoFragment.mScannedTxt.getText().toString()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void getBookmarkImageView(View view2) {
        view2.setVisibility(View.VISIBLE);
        ImageView imageView = (ImageView) view2.findViewById(R.id.bookmark_img);
        if (this.checkBookmarked) {
            imageView.setImageResource(R.drawable.i_bookmark_select);
        }
    }

    private void setViewVisible(String str, View view2, Bundle bundle) {
        Bitmap bitmap;
        Bitmap bitmap2;
        Bitmap bitmap3;
        Bitmap bitmap4;
        Bitmap bitmap5;
        Bitmap bitmap6;
        Bitmap bitmap7;
        Bitmap bitmap8;
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            String string = bundle.getString(Constants.SCANNED_TXT);
            view2.findViewById(R.id.address_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Address Book");
            this.mProductTypeImg.setImageResource(R.drawable.i_add);
            this.parsedResult = ResultParser.parseResult(new Result(string, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.scannedResultManager.addressResultContent(this.parsedResult));
            String string2 = bundle.getString(Constants.CUSTOM_QR_PATH);
            if (string2 != null) {
                bitmap8 = new ImageSaver(this.activity).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(new File(string2).getName()).load();
            } else {
                bitmap8 = CodeUtils.createBarCode(string, BarcodeFormat.QR_CODE, 500, 500);
            }
            this.mScannedImg.setImageBitmap(bitmap8);
            this.saveBitmap = bitmap8;
            getBookmarkImageView(view2.findViewById(R.id.address_layout));
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            view2.findViewById(R.id.calender_layout).setVisibility(View.VISIBLE);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.mTypeTxt.setText("Calender");
            this.mProductTypeImg.setImageResource(R.drawable.i_cal1);
            this.mProductTypeImg.setBackground(getResources().getDrawable(R.drawable.bg_calender));
            this.mScannedTxt.setText(this.scannedResultManager.calenderResultContent(this.parsedResult));
            getBookmarkImageView(view2.findViewById(R.id.calender_layout));
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            String string3 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string3, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            String string4 = bundle.getString(Constants.CUSTOM_QR_PATH);
            if (string4 != null) {
                bitmap7 = new ImageSaver(this.activity).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(new File(string4).getName()).load();
            } else {
                bitmap7 = CodeUtils.createBarCode(string3, BarcodeFormat.QR_CODE, 500, 500);
            }
            view2.findViewById(R.id.email_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Mail");
            this.mProductTypeImg.setImageResource(R.drawable.i_email);
            this.mScannedImg.setImageBitmap(bitmap7);
            this.saveBitmap = bitmap7;
            getBookmarkImageView(view2.findViewById(R.id.email_layout));
        } else if (Constants.TYPE_GEO.equals(str)) {
            String string5 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string5, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            String string6 = bundle.getString(Constants.CUSTOM_QR_PATH);
            if (string6 != null) {
                bitmap6 = new ImageSaver(this.activity).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(new File(string6).getName()).load();
            } else {
                bitmap6 = CodeUtils.createBarCode(string5, BarcodeFormat.QR_CODE, 500, 500);
            }
            view2.findViewById(R.id.geo_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Geo Location");
            this.mProductTypeImg.setImageResource(R.drawable.i_loc);
            this.mScannedImg.setImageBitmap(bitmap6);
            this.saveBitmap = bitmap6;
            getBookmarkImageView(view2.findViewById(R.id.geo_layout));
        } else if ("ISBN".equals(str)) {
            String string7 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string7, null, null, BarcodeFormat.EAN_13));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode = CodeUtils.createBarCode(string7, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            view2.findViewById(R.id.isbn_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("ISBN");
            this.mProductTypeImg.setImageResource(R.drawable.i_isbn);
            webView();
            this.mScannedImg.setImageBitmap(createBarCode);
            this.saveBitmap = createBarCode;
            getBookmarkImageView(view2.findViewById(R.id.isbn_layout));
        } else if (Constants.TYPE_PRODUCT.equals(str)) {
            String string8 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string8, null, null, BarcodeFormat.EAN_13));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            Bitmap createBarCode2 = CodeUtils.createBarCode(string8, BarcodeFormat.EAN_13, 500, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
            view2.findViewById(R.id.product_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Product");
            this.mProductTypeImg.setImageResource(R.drawable.i_product);
            webView();
            this.mScannedImg.setImageBitmap(createBarCode2);
            this.saveBitmap = createBarCode2;
            getBookmarkImageView(view2.findViewById(R.id.product_layout));
        } else if (Constants.TYPE_SMS.equals(str)) {
            String string9 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string9, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.scannedResultManager.smsResultContent(this.parsedResult));
            String string10 = bundle.getString(Constants.CUSTOM_QR_PATH);
            if (string10 != null) {
                bitmap5 = new ImageSaver(this.activity).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(new File(string10).getName()).load();
            } else {
                bitmap5 = CodeUtils.createBarCode(string9, BarcodeFormat.QR_CODE, 500, 500);
            }
            view2.findViewById(R.id.sms_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText(Constants.TYPE_SMS);
            this.mProductTypeImg.setImageResource(R.drawable.i_msgs);
            this.mScannedImg.setImageBitmap(bitmap5);
            this.saveBitmap = bitmap5;
            getBookmarkImageView(view2.findViewById(R.id.sms_layout));
        } else if (Constants.TYPE_TEL.equals(str)) {
            String string11 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string11, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.scannedResultManager.telResultContent(this.parsedResult));
            String string12 = bundle.getString(Constants.CUSTOM_QR_PATH);
            if (string12 != null) {
                bitmap4 = new ImageSaver(this.activity).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(new File(string12).getName()).load();
            } else {
                bitmap4 = CodeUtils.createBarCode(string11, BarcodeFormat.QR_CODE, 500, 500);
            }
            view2.findViewById(R.id.contact_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Contact");
            this.mProductTypeImg.setImageResource(R.drawable.i_call);
            this.mScannedImg.setImageBitmap(bitmap4);
            this.saveBitmap = bitmap4;
            getBookmarkImageView(view2.findViewById(R.id.contact_layout));
        } else if (Constants.TYPE_TEXT.equals(str)) {
            String string13 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string13, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            String string14 = bundle.getString(Constants.CUSTOM_QR_PATH);
            if (string14 != null) {
                bitmap3 = new ImageSaver(this.activity).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(new File(string14).getName()).load();
            } else {
                bitmap3 = CodeUtils.createBarCode(string13, BarcodeFormat.QR_CODE, 500, 500);
            }
            view2.findViewById(R.id.product_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Text");
            this.mProductTypeImg.setImageResource(R.drawable.i_text);
            webView();
            this.mScannedImg.setImageBitmap(bitmap3);
            this.saveBitmap = bitmap3;
            getBookmarkImageView(view2.findViewById(R.id.product_layout));
        } else if (Constants.TYPE_URI.equals(str)) {
            String string15 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string15, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.parsedResult.getDisplayResult());
            TextView textView = this.mScannedTxt;
            textView.setPaintFlags(textView.getPaintFlags() | 8);
            this.mScannedTxt.setTextColor(getResources().getColor(R.color.blue));
            this.mScannedTxt.setOnClickListener(new View.OnClickListener() {
                public final void onClick(View view) {
                    ScannedBarcodeInfoFragment.lambda$setViewVisible$12(ScannedBarcodeInfoFragment.this, view);
                }
            });
            String string16 = bundle.getString(Constants.CUSTOM_QR_PATH);
            if (string16 != null) {
                bitmap2 = new ImageSaver(this.activity).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(new File(string16).getName()).load();
            } else {
                bitmap2 = CodeUtils.createBarCode(string15, BarcodeFormat.QR_CODE, 500, 500);
            }
            view2.findViewById(R.id.product_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("URL");
            this.mProductTypeImg.setImageResource(R.drawable.i_url);
            webView();
            this.mScannedImg.setImageBitmap(bitmap2);
            this.saveBitmap = bitmap2;
            getBookmarkImageView(view2.findViewById(R.id.product_layout));
        } else if (Constants.TYPE_WIFI.equals(str)) {
            String string17 = bundle.getString(Constants.SCANNED_TXT);
            this.mTimeTxt.setText(getFormattedDate(bundle.getString(Constants.SCANNED_TIME)));
            this.parsedResult = ResultParser.parseResult(new Result(string17, null, null, BarcodeFormat.QR_CODE));
            this.mScannedTxt.setText(this.scannedResultManager.wifiResultContent(this.parsedResult));
            String string18 = bundle.getString(Constants.CUSTOM_QR_PATH);
            if (string18 != null) {
                bitmap = new ImageSaver(this.activity).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(new File(string18).getName()).load();
            } else {
                bitmap = CodeUtils.createBarCode(string17, BarcodeFormat.QR_CODE, 500, 500);
            }
            view2.findViewById(R.id.wifi_layout).setVisibility(View.VISIBLE);
            this.mTypeTxt.setText("Wifi");
            this.mProductTypeImg.setImageResource(R.drawable.i_wifi);
            this.mScannedImg.setImageBitmap(bitmap);
            this.saveBitmap = bitmap;
            getBookmarkImageView(view2.findViewById(R.id.wifi_layout));
        }
    }

    public static /* synthetic */ void lambda$setViewVisible$12(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, View view2) {
        if (!isNetworkStatusAvialable(scannedBarcodeInfoFragment.activity)) {
            Toast.makeText(scannedBarcodeInfoFragment.activity, "Please check your internet connection..!", 0).show();
        } else if (scannedBarcodeInfoFragment.isValidUrl(scannedBarcodeInfoFragment.mScannedTxt.getText().toString())) {
            try {
                scannedBarcodeInfoFragment.activity.startActivity(new Intent(scannedBarcodeInfoFragment.activity, WebviewActivity.class).putExtra("SEARCH_URL", scannedBarcodeInfoFragment.mScannedTxt.getText().toString()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                Activity activity2 = scannedBarcodeInfoFragment.activity;
                Intent intent = new Intent(scannedBarcodeInfoFragment.activity, WebviewActivity.class);
                activity2.startActivity(intent.putExtra("SEARCH_URL", "https://www.google.com/search?q=" + scannedBarcodeInfoFragment.mScannedTxt.getText().toString()));
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    private String getFormattedDate(String str) {
        return new SimpleDateFormat("dd MMM yyyy,  hh:mm a", Locale.ENGLISH).format(new Date(new Timestamp(Long.parseLong(str)).getTime()));
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(ButtonClickEvent buttonClickEvent) {
        buttonClick(buttonClickEvent.getView());
    }

    /* access modifiers changed from: private */
    public void shareMultiple(List<File> list, Context context) {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND_MULTIPLE");
        intent.putExtra("android.intent.extra.SUBJECT", "Here are some files.");
        intent.setType("image/*");
        ArrayList arrayList = new ArrayList();
        for (File absolutePath : list) {
            arrayList.add(Uri.fromFile(new File(absolutePath.getAbsolutePath())));
        }
        intent.putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList);
        context.startActivity(intent);
    }

    private void buttonClick(View view2) {
        switch (view2.getId()) {
            case R.id.address_add_layout:
                this.scannedResultManager.addressBookResult(this.parsedResult, 0);
                break;
            case R.id.address_dial_layout:
                this.scannedResultManager.addressBookResult(this.parsedResult, 2);
                break;
            case R.id.address_mail_layout:
                this.scannedResultManager.addressBookResult(this.parsedResult, 3);
                break;
            case R.id.address_view_layout:
                this.scannedResultManager.addressBookResult(this.parsedResult, 1);
                break;
            case R.id.bookmark_layout:
                String str = this.generateItem;
                if (str != null && str.equals("GenerateItem")) {
                    final ImageView imageView = (ImageView) view2.findViewById(R.id.bookmark_img);
                    if (getGenBookmarkSize(this.resultTypeSelected) <= 0) {
                        Single.fromCallable(new Callable() {
                            public final Object call() {
                                return Boolean.valueOf(ScannedBarcodeInfoFragment.this.insertBookMarkGenData(ScannedBarcodeInfoFragment.this.generateBookmarkDataEntity));
                            }
                        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer() {
                            public final void accept(Object obj) {
                                ScannedBarcodeInfoFragment.lambda$buttonClick$14(ScannedBarcodeInfoFragment.this, imageView, (Boolean) obj);
                            }
                        }, $$Lambda$ScannedBarcodeInfoFragment$q6Jr3JMsWRJNnQ1Wrg9YD7dd18.INSTANCE);
                        break;
                    } else {
                        this.scanDatabase.scanDataDao().deleteGenItemBookmark(this.resultTypeSelected);
                        Toast makeText = Toast.makeText(this.activity.getApplicationContext(), "Removed Bookmarked", 0);
                        makeText.setGravity(17, 0, 0);
                        makeText.show();
                        imageView.setImageResource(R.drawable.i_bookmark1);
                        break;
                    }
                } else {
                    final ImageView imageView2 = (ImageView) view2.findViewById(R.id.bookmark_img);
                    if (getBookmarkSize(this.resultTypeSelected) <= 0) {
                        Single.fromCallable(new Callable() {
                            public final Object call() {
                                return Boolean.valueOf(ScannedBarcodeInfoFragment.this.insertBookMarkScanData(ScannedBarcodeInfoFragment.this.scanDataBookmarkEntity));
                            }
                        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer() {
                            public final void accept(Object obj) {
                                ScannedBarcodeInfoFragment.lambda$buttonClick$17(ScannedBarcodeInfoFragment.this, imageView2, (Boolean) obj);
                            }
                        }, $$Lambda$ScannedBarcodeInfoFragment$Dy4Cm_81MNquMfaR76g5iCV26_A.INSTANCE);
                        break;
                    } else {
                        this.scanDatabase.scanDataDao().deleteItemBookmark(this.resultTypeSelected);
                        Toast makeText2 = Toast.makeText(this.activity.getApplicationContext(), "Removed Bookmarked", 0);
                        makeText2.setGravity(17, 0, 0);
                        makeText2.show();
                        imageView2.setImageResource(R.drawable.i_bookmark1);
                        break;
                    }
                }
            case R.id.cal_event_layout:
                this.scannedResultManager.calenderResult(this.parsedResult);
                break;
            case R.id.contact_add_layout:
                this.scannedResultManager.contactResult(this.parsedResult, 1);
                break;
            case R.id.contact_dial_layout:
                this.scannedResultManager.contactResult(this.parsedResult, 0);
                break;
            case R.id.copy_layout:
                ClipboardManager clipboardManager = (ClipboardManager) this.activity.getSystemService("clipboard");
                ClipData newPlainText = ClipData.newPlainText("label", this.mScannedTxt.getText().toString());
                if (clipboardManager != null) {
                    clipboardManager.setPrimaryClip(newPlainText);
                    Toast makeText3 = Toast.makeText(this.activity.getApplicationContext(), "Copied to clipboard", 0);
                    makeText3.setGravity(17, 0, 0);
                    makeText3.show();
                    break;
                } else {
                    return;
                }
            case R.id.email_add_layout:
                this.scannedResultManager.emailResult(this.parsedResult, 1);
                break;
            case R.id.email_send_layout:
                this.scannedResultManager.emailResult(this.parsedResult, 0);
                break;
            case R.id.geo_direction_layout:
                this.scannedResultManager.geoResult(this.parsedResult, 1);
                break;
            case R.id.geo_map_layout:
                this.scannedResultManager.geoResult(this.parsedResult, 0);
                break;
            case R.id.isbn_book_layout:
                this.scannedResultManager.isbnResult(this.parsedResult, 1);
                break;
            case R.id.isbn_search_layout:
                this.scannedResultManager.isbnResult(this.parsedResult, 0);
                break;
            case R.id.search_layout:
                if (!isValidUrl(this.mScannedTxt.getText().toString())) {
                    try {
                        Activity activity2 = this.activity;
                        Intent intent = new Intent(this.activity, WebviewActivity.class);
                        activity2.startActivity(intent.putExtra("SEARCH_URL", "https://www.google.com/search?q=" + this.mScannedTxt.getText().toString()));
                        break;
                    } catch (Exception e) {
                        e.printStackTrace();
                        break;
                    }
                } else {
                    try {
                        this.activity.startActivity(new Intent(this.activity, WebviewActivity.class).putExtra("SEARCH_URL", this.mScannedTxt.getText().toString()));
                        break;
                    } catch (Exception e2) {
                        e2.printStackTrace();
                        break;
                    }
                }
            case R.id.share_layout:
                Permissions.check((Context) this.activity, "android.permission.WRITE_EXTERNAL_STORAGE", (String) null, (PermissionHandler) new PermissionHandler() {
                    public void onGranted() {
                        new ImageSaver(ScannedBarcodeInfoFragment.this.activity).setFileName("scanned_image.jpg").setDirectoryName(Constants.SAVE_DIR_NAME).setExternal(true).save(ScannedBarcodeInfoFragment.this.saveBitmap);
                        File filePath = new ImageSaver(ScannedBarcodeInfoFragment.this.activity).setFileName("scanned_image.jpg").setDirectoryName(Constants.SAVE_DIR_NAME).setExternal(true).getFilePath();
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(filePath);
                        ScannedBarcodeInfoFragment scannedBarcodeInfoFragment = ScannedBarcodeInfoFragment.this;
                        scannedBarcodeInfoFragment.shareMultiple(arrayList, scannedBarcodeInfoFragment.activity);
                    }
                });
                break;
            case R.id.sms_send_layout:
                this.scannedResultManager.smsResult(this.parsedResult, 0);
                break;
            case R.id.wifi_connect_layout:
                this.scannedResultManager.wifiResult(this.parsedResult);
                break;
        }
    }

    public static /* synthetic */ void lambda$buttonClick$14(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, ImageView imageView, Boolean bool) {
        Toast makeText = Toast.makeText(scannedBarcodeInfoFragment.activity.getApplicationContext(), "Item Bookmarked", Toast.LENGTH_SHORT);
        makeText.setGravity(17, 0, 0);
        makeText.show();
        imageView.setImageResource(R.drawable.i_bookmark_select);
    }

    public static /* synthetic */ void lambda$buttonClick$17(ScannedBarcodeInfoFragment scannedBarcodeInfoFragment, ImageView imageView, Boolean bool) {
        Toast makeText = Toast.makeText(scannedBarcodeInfoFragment.activity.getApplicationContext(), "Item Bookmarked", Toast.LENGTH_SHORT);
        makeText.setGravity(17, 0, 0);
        makeText.show();
        imageView.setImageResource(R.drawable.i_bookmark_select);
    }

    private boolean isValidUrl(String str) {
        return Patterns.WEB_URL.matcher(str.toLowerCase()).matches();
    }

    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    private void loadWebPage(String str) {
        this.mWebView.loadUrl(str);
        this.mWebProBar.setVisibility(0);
        this.mWebView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                webView.loadUrl(str);
                ScannedBarcodeInfoFragment.this.mWebProBar.setVisibility(View.VISIBLE);
                return false;
            }

            public void onPageFinished(WebView webView, String str) {
                ScannedBarcodeInfoFragment.this.mWebView.loadUrl("javascript:MyApp.resize(document.body.getBoundingClientRect().height)");
                super.onPageFinished(webView, str);
                ScannedBarcodeInfoFragment.this.mWebProBar.setVisibility(View.GONE);
                ScannedBarcodeInfoFragment.this.mWebCardLayout.setVisibility(View.VISIBLE);
            }
        });
        this.mWebView.addJavascriptInterface(this, "MyApp");
    }

    @JavascriptInterface
    public void resize(final float f) {
        this.activity.runOnUiThread(new Runnable() {
            public final void run() {
                ScannedBarcodeInfoFragment.this.mWebView.setLayoutParams(new LinearLayout.LayoutParams(ScannedBarcodeInfoFragment.this.getResources().getDisplayMetrics().widthPixels, (int) (f * ScannedBarcodeInfoFragment.this.getResources().getDisplayMetrics().density)));
            }
        });
    }

    private Bitmap getImage(Context context, String str) {
        return new ImageSaver(context).setDirectoryName(Constants.SAVE_DIR_NAME).setFileName(str).load();
    }

    public void onDestroy() {
        WebView webView = this.mWebView;
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }

    private void showBanner() {
        final AdView mAdView = new AdView(getActivity());
        mAdView.setAdSize(getAdSize());
        mAdView.setAdUnitId(Splash_Activity.adModel.getAdMobBanner());
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                if (adMobView != null) {
                    adMobView.removeAllViews();
                }
                adMobView.addView(mAdView);
            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        if (adMobView != null) {
            adMobView.removeAllViews();
        }
    }

    private com.google.android.gms.ads.AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = getActivity().getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(getActivity(), adWidth);
    }
}
