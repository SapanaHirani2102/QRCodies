package topcreator.qrcode.barcode.scanner.reader.holder;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.model.BarcodeSelectFilterItemModel;
import topcreator.qrcode.barcode.scanner.reader.model.GenerateTypeModel;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;

import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import org.greenrobot.eventbus.EventBus;

public class BarcodeGenerateTypeFilterHolder extends BaseItemHolder<GenerateTypeModel> {
    TextView detailTxt;
    ImageView typeImg;
    TextView typeTxt;

    public BarcodeGenerateTypeFilterHolder(View view) {
        super(view);
        this.typeImg = (ImageView) view.findViewById(R.id.type_img);
        this.detailTxt = (TextView) view.findViewById(R.id.scan_txt);
        this.typeTxt = (TextView) view.findViewById(R.id.scan_type_txt);
        }

    public void bindData(final GenerateTypeModel generateTypeModel, int i, int i2) {
        super.bindData(generateTypeModel, i, i2);

        this.typeImg.setImageResource(generateTypeModel.getItemImage());
        TextView textView = this.detailTxt;
        textView.setText("Generate " + generateTypeModel.getItemTxt() + " Barcode");
        this.typeTxt.setText(generateTypeModel.getItemTxt());
        this.itemView.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                BarcodeGenerateTypeFilterHolder.lambda$bindData$0(BarcodeGenerateTypeFilterHolder.this, generateTypeModel, view);
            }
        });
        if (i + 1 == i2) {
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMargins(0, 0, 0, 100);
            this.itemView.setLayoutParams(layoutParams);
        }
    }

    public static /* synthetic */ void lambda$bindData$0(BarcodeGenerateTypeFilterHolder barcodeGenerateTypeFilterHolder, GenerateTypeModel generateTypeModel, View view) {
        TinyDB instance = TinyDB.getInstance(barcodeGenerateTypeFilterHolder.itemView.getContext());
        instance.putInt(Constants.ADS_COUNT, instance.getInt(Constants.ADS_COUNT) + 1);
        EventBus.getDefault().post(new BarcodeSelectFilterItemModel(generateTypeModel.getDetailType()));
    }
}
