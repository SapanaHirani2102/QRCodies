package topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.result;

import android.app.Activity;
import topcreator.qrcode.barcode.scanner.reader.R;
import com.google.zxing.client.result.ParsedResult;
import com.google.zxing.client.result.TelParsedResult;

public final class TelResultHandler extends ResultHandler {
    public int getButtonCount() {
        return 0;
    }

    public int getButtonText(int i) {
        return 0;
    }

    public int getDisplayTitle() {
        return R.string.result_tel;
    }

    public TelResultHandler(Activity activity, ParsedResult parsedResult) {
        super(activity, parsedResult);
    }

    public void handleButtonPress(int i) {
        TelParsedResult telParsedResult = (TelParsedResult) getResult();
        switch (i) {
            case 0:
                dialPhoneFromUri(telParsedResult.getTelURI());
                getActivity().finish();
                return;
            case 1:
                addPhoneOnlyContact(new String[]{telParsedResult.getNumber()}, null);
                return;
            default:
                return;
        }
    }

    public CharSequence getDisplayContents() {
        return formatPhone(getResult().getDisplayResult().replace("\r", ""));
    }
}
