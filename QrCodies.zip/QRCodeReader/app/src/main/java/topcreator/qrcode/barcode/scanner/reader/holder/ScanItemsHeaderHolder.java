package topcreator.qrcode.barcode.scanner.reader.holder;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.adapter.BaseRecyclerAdapter;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ScanItemsHeaderHolder extends BaseItemHolder<String> {
    BaseRecyclerAdapter<ScanDataEntity, ScanItemsHolder> mAdapter;
    private RecyclerView mScannedRv;
    String month;
    ScanDatabase scanDatabase;
    TextView timeTxt;
    String year;

    public ScanItemsHeaderHolder(View view) {
        super(view);
        this.timeTxt = (TextView) view.findViewById(R.id.time_line_txt_header);
        this.mScannedRv = (RecyclerView) view.findViewById(R.id.items_recycler_view);
        this.scanDatabase = ScanDatabase.getInstance(view.getContext());
    }

    public void bindData(String str, int i, int i2) {
        super.bindData(str, i, i2);

        if (str.equals(Constants.DATE_TYPE_DAY)) {
            this.timeTxt.setVisibility(View.VISIBLE);
            this.timeTxt.setText(str);
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, ScanItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getTodayScannedDataList());
        } else if (str.equals(Constants.DATE_TYPE_MONTH)) {
            this.timeTxt.setVisibility(View.VISIBLE);
            this.timeTxt.setText(str);
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, ScanItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getMonthScannedDataList());
        } else if (str.equals(Constants.DATE_TYPE_YESTERDAY)) {
            this.timeTxt.setVisibility(View.VISIBLE);
            this.timeTxt.setText(str);
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, ScanItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getYesterdayScannedDataList());
        } else if (str.equals(Constants.DATE_TYPE_WEEK)) {
            this.timeTxt.setVisibility(View.VISIBLE);
            this.timeTxt.setText(str);
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, ScanItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getWeekScannedDataList());
        } else {
            this.timeTxt.setVisibility(View.VISIBLE);
            this.timeTxt.setText(str);
            String[] splitDate = splitDate(str);
            if (splitDate.length > 1) {
                int monthIndex = getMonthIndex(splitDate[0]);
                if (monthIndex <= 9) {
                    this.month = "0" + monthIndex;
                } else {
                    this.month = String.valueOf(monthIndex);
                }
                this.year = splitDate[1];
            }
            this.mAdapter = new BaseRecyclerAdapter<>(R.layout.scanned_items, ScanItemsHolder.class);
            this.mScannedRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedRv.setAdapter(this.mAdapter);
            this.mAdapter.setData(getScannedDataList(this.month, this.year));
        }
        if (i + 1 == i2) {
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMargins(0, 0, 0, 100);
            this.itemView.setLayoutParams(layoutParams);
        }
    }

    private int getMonthIndex(String str) {
        try {
            Date parse = new SimpleDateFormat("MMM", Locale.ENGLISH).parse(str);
            Calendar instance = Calendar.getInstance();
            instance.setTime(parse);
            return instance.get(2) + 1;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    private String[] splitDate(String str) {
        return str.split("-");
    }

    private List<ScanDataEntity> getScannedDataList(String str, String str2) {
        List<ScanDataEntity> genericDataList = this.scanDatabase.scanDataDao().getGenericDataList(str, str2);
        Collections.reverse(genericDataList);
        return genericDataList;
    }

    private List<ScanDataEntity> getTodayScannedDataList() {
        List<ScanDataEntity> dayData = this.scanDatabase.scanDataDao().getDayData();
        ArrayList arrayList = new ArrayList();
        if (dayData.size() >= 10) {
            for (int i = 0; i < dayData.size(); i++) {
                if (i == 9) {
                    arrayList.add(dayData.get(i));
                }
                arrayList.add(dayData.get(i));
            }
            Collections.reverse(arrayList);
            return arrayList;
        }
        Collections.reverse(dayData);
        return dayData;
    }

    private List<ScanDataEntity> getMonthScannedDataList() {
        List<ScanDataEntity> monthData = this.scanDatabase.scanDataDao().getMonthData();
        ArrayList arrayList = new ArrayList();
        if (monthData.size() >= 10) {
            for (int i = 0; i < monthData.size(); i++) {
                if (i == 9) {
                    arrayList.add(monthData.get(i));
                }
                arrayList.add(monthData.get(i));
            }
            Collections.reverse(arrayList);
            return arrayList;
        }
        Collections.reverse(monthData);
        return monthData;
    }

    private List<ScanDataEntity> getYesterdayScannedDataList() {
        List<ScanDataEntity> yesterdayDataList = this.scanDatabase.scanDataDao().getYesterdayDataList();
        ArrayList arrayList = new ArrayList();
        if (yesterdayDataList.size() >= 10) {
            for (int i = 0; i < yesterdayDataList.size(); i++) {
                if (i == 9) {
                    arrayList.add(yesterdayDataList.get(i));
                }
                arrayList.add(yesterdayDataList.get(i));
            }
            Collections.reverse(arrayList);
            return arrayList;
        }
        Collections.reverse(yesterdayDataList);
        return yesterdayDataList;
    }

    private List<ScanDataEntity> getWeekScannedDataList() {
        List<ScanDataEntity> weekData = this.scanDatabase.scanDataDao().getWeekData();
        ArrayList arrayList = new ArrayList();
        if (weekData.size() >= 10) {
            for (int i = 0; i < weekData.size(); i++) {
                if (i == 9) {
                    arrayList.add(weekData.get(i));
                }
                arrayList.add(weekData.get(i));
            }
            Collections.reverse(arrayList);
            return arrayList;
        }
        Collections.reverse(weekData);
        return weekData;
    }
}
