package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.util.Log;
import io.reactivex.functions.Consumer;

/* renamed from: topcreator.qrcode.barcode.scanner.reader.fragments.-$$Lambda$ScannedBarcodeInfoFragment$q6Jr3JMsW-RJNnQ1Wrg9YD7dd18  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$ScannedBarcodeInfoFragment$q6Jr3JMsWRJNnQ1Wrg9YD7dd18 implements Consumer {
    public static final /* synthetic */ $$Lambda$ScannedBarcodeInfoFragment$q6Jr3JMsWRJNnQ1Wrg9YD7dd18 INSTANCE = new $$Lambda$ScannedBarcodeInfoFragment$q6Jr3JMsWRJNnQ1Wrg9YD7dd18();

    private /* synthetic */ $$Lambda$ScannedBarcodeInfoFragment$q6Jr3JMsWRJNnQ1Wrg9YD7dd18() {
    }

    public final void accept(Object obj) {
        Log.e("Data Inserted", "barcodeResult: " + ((Throwable) obj).getMessage());
    }
}
