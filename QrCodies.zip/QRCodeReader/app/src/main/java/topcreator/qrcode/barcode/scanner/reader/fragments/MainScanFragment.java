package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.hardware.Camera;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SeekBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.result.FinalResultsHandler;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.events.StopScanEvent;
import topcreator.qrcode.barcode.scanner.reader.model.ScanDataModel;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import com.google.android.gms.samples.vision.barcodereader.BarcodeCapture;
import com.google.android.gms.samples.vision.barcodereader.BarcodeGraphic;
import com.google.android.gms.vision.barcode.Barcode;
//import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.zxing.client.android.BeepManager;

import io.reactivex.disposables.Disposable;

import java.util.ArrayList;
import java.util.List;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import xyz.belvi.mobilevisionbarcodescanner.BarcodeRetriever;

public class MainScanFragment extends Fragment implements BarcodeRetriever {
    private static final int RC_BARCODE_CAPTURE = 9001;
    /* access modifiers changed from: private */
    public String TAG = "MainScanFragment";
    private Activity activity;
    BarcodeCapture barcodeCapture;
    private BeepManager beepManager;
    private Disposable disposable = null;
    private FinalResultsHandler finalResultsHandler;
    boolean isAutoFocus;
    private boolean isAutoFocusImage = false;
    private boolean isBeepImage = false;
    boolean isBeepSound;
    boolean isCopyClipboard;
    private boolean isFlashImage = false;
    private boolean isSound = false;
    private boolean isVibration = false;
    private ImageView mBeepCheck;
    private ImageView mDrawerMenuImg;
    private ImageView mFlashCheck;
    private ImageView mFocusCheck;
    /* access modifiers changed from: private */
    public SeekBar mZoomSb;
    private ArrayList<ScanDataModel> scanDataModelList;
    private ScanDatabase scanDatabase;
    private TinyDB tinyDB;

    public void onInterstitialAdClose() {
    }

    public void onInterstitialAdFailed() {
    }

    public void onInterstitialAdLoaded() {
    }

    public void onPermissionRequestDenied() {
    }

    public void onRetrievedFailed(String str) {
    }

    public void onRetrievedMultiple(Barcode barcode, List<BarcodeGraphic> list) {
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (MainActivity) context;
        }
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_main, viewGroup, false);
        this.activity.getWindow().setFlags(1024, 1024);
        this.mZoomSb = (SeekBar) inflate.findViewById(R.id.zoom_sb);
        this.mZoomSb.getProgressDrawable().setColorFilter(-1, PorterDuff.Mode.SRC_IN);
        this.mZoomSb.getThumb().setColorFilter(-1, PorterDuff.Mode.SRC_IN);
        this.mFlashCheck = (ImageView) inflate.findViewById(R.id.flash_check);
        this.mFocusCheck = (ImageView) inflate.findViewById(R.id.focus_check);
        this.mBeepCheck = (ImageView) inflate.findViewById(R.id.beep_check);
        this.scanDatabase = ScanDatabase.getInstance(this.activity);
        this.finalResultsHandler = new FinalResultsHandler(this.activity);
        this.tinyDB = TinyDB.getInstance(this.activity);
        this.isVibration = this.tinyDB.getBoolean(Constants.SETTING_VIBRATION);
        this.isSound = this.tinyDB.getBoolean(Constants.SETTING_SOUND);
        if (this.isSound) {
            this.mBeepCheck.setImageDrawable(getResources().getDrawable(R.drawable.i_speaker1));
        } else {
            this.mBeepCheck.setImageDrawable(getResources().getDrawable(R.drawable.i_speaker_off));
        }
        this.scanDataModelList = new ArrayList<>();
        this.isBeepSound = TinyDB.getInstance(this.activity).getBoolean("key_beep");
        this.isCopyClipboard = TinyDB.getInstance(this.activity).getBoolean("key_copy_clipboard");
        this.isAutoFocus = TinyDB.getInstance(this.activity).getBoolean("key_use_auto_focus");
        this.barcodeCapture = (BarcodeCapture) getChildFragmentManager().findFragmentById(R.id.barcode);
        this.barcodeCapture.setRetrieval(this);
        this.barcodeCapture.setSupportMultipleScan(false).setShowDrawRect(true).shouldAutoFocus(true);
        this.mZoomSb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (MainScanFragment.this.barcodeCapture != null) {
                    Camera retrieveCamera = MainScanFragment.this.barcodeCapture.retrieveCamera();
                    if (retrieveCamera != null) {
                        try {
                            Camera.Parameters parameters = retrieveCamera.getParameters();
                            int maxZoom = parameters.getMaxZoom();
                            MainScanFragment.this.mZoomSb.setMax(maxZoom);
                            if (parameters.isZoomSupported() && i >= 0 && i < maxZoom) {
                                parameters.setZoom(i);
                            }
                            retrieveCamera.setParameters(parameters);
                        } catch (Exception e) {
                            String access$100 = MainScanFragment.this.TAG;
                            Log.e(access$100, "onProgressChanged: " + e.getMessage());
                        }
                    }
                }
            }
        });

        this.mFlashCheck.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainScanFragment.lambda$onCreateView$1(MainScanFragment.this, view);
            }
        });
        this.mBeepCheck.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainScanFragment.lambda$onCreateView$2(MainScanFragment.this, view);
            }
        });
        this.mFocusCheck.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainScanFragment.lambda$onCreateView$3(MainScanFragment.this, view);
            }
        });
        return inflate;
    }

    public static /* synthetic */ void lambda$onCreateView$1(MainScanFragment mainScanFragment, View view) {
        if (mainScanFragment.barcodeCapture != null) {
            if (mainScanFragment.isFlashImage) {
                try {
                    mainScanFragment.mFlashCheck.setImageDrawable(mainScanFragment.getResources().getDrawable(R.drawable.ic_flash_off));
                    mainScanFragment.barcodeCapture.setShowFlash(false);
                    mainScanFragment.barcodeCapture.refresh(false);
                    mainScanFragment.isFlashImage = false;
                } catch (Exception e) {
                    String str = mainScanFragment.TAG;
                    Log.e(str, "onCreateView: " + e.getMessage());
                }
            } else {
                try {
                    mainScanFragment.mFlashCheck.setImageDrawable(mainScanFragment.getResources().getDrawable(R.drawable.ic_flash));
                    mainScanFragment.barcodeCapture.setShowFlash(true);
                    mainScanFragment.barcodeCapture.refresh(false);
                    mainScanFragment.isFlashImage = true;
                } catch (Exception e2) {
                    String str2 = mainScanFragment.TAG;
                    Log.e(str2, "onCreateView: " + e2.getMessage());
                }
            }
        }
    }

    public static /* synthetic */ void lambda$onCreateView$2(MainScanFragment mainScanFragment, View view) {
        if (mainScanFragment.isBeepImage) {
            mainScanFragment.mBeepCheck.setImageDrawable(mainScanFragment.getResources().getDrawable(R.drawable.i_speaker_off));
            mainScanFragment.tinyDB.putBoolean(Constants.SETTING_SOUND, false);
            mainScanFragment.isBeepImage = false;
            return;
        }
        mainScanFragment.mBeepCheck.setImageDrawable(mainScanFragment.getResources().getDrawable(R.drawable.i_speaker1));
        mainScanFragment.tinyDB.putBoolean(Constants.SETTING_SOUND, true);
        mainScanFragment.isBeepImage = true;
    }

    public static /* synthetic */ void lambda$onCreateView$3(MainScanFragment mainScanFragment, View view) {
        if (mainScanFragment.barcodeCapture != null) {
            if (mainScanFragment.isAutoFocusImage) {
                try {
                    mainScanFragment.mFocusCheck.setImageDrawable(mainScanFragment.getResources().getDrawable(R.drawable.ic_focus));
                    mainScanFragment.barcodeCapture.shouldAutoFocus(true);
                    mainScanFragment.barcodeCapture.refresh(true);
                    mainScanFragment.isAutoFocusImage = false;
                    if (mainScanFragment.mZoomSb != null) {
                        mainScanFragment.mZoomSb.setProgress(0);
                    }
                } catch (Exception e) {
                    String str = mainScanFragment.TAG;
                    Log.e(str, "onCreateView: " + e.getMessage());
                }
            } else {
                try {
                    mainScanFragment.mFocusCheck.setImageDrawable(mainScanFragment.getResources().getDrawable(R.drawable.ic_focus_off));
                    mainScanFragment.barcodeCapture.shouldAutoFocus(false);
                    mainScanFragment.barcodeCapture.refresh(true);
                    mainScanFragment.isAutoFocusImage = true;
                    if (mainScanFragment.mZoomSb != null) {
                        mainScanFragment.mZoomSb.setProgress(0);
                    }
                } catch (Exception e2) {
                    String str2 = mainScanFragment.TAG;
                    Log.e(str2, "onCreateView: " + e2.getMessage());
                }
            }
        }
    }

    private void vibration() {
        Vibrator vibrator = (Vibrator) this.activity.getSystemService("vibrator");
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(500, -1));
        } else {
            vibrator.vibrate(500);
        }
    }

    private void scanSound() {
        try {
            final ToneGenerator toneGenerator = new ToneGenerator(3, 100);
            toneGenerator.startTone(94, 150);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                public void run() {
                    Log.d(MainScanFragment.this.TAG, "ToneGenerator released");
                    toneGenerator.release();
                }
            }, 200);
        } catch (Exception e) {
            String str = this.TAG;
            Log.d(str, "Exception while playing sound:" + e);
        }
    }

    private boolean insertScanData(ScanDataEntity scanDataEntity) {
        this.scanDatabase.scanDataDao().insert(scanDataEntity);
        return true;
    }

    private void ScannedResultProcess(Barcode barcode) {
        this.barcodeCapture.stopScanning();
        this.isVibration = this.tinyDB.getBoolean(Constants.SETTING_VIBRATION);
        this.isSound = this.tinyDB.getBoolean(Constants.SETTING_SOUND);
        if (this.isSound) {
            scanSound();
        }
        if (this.isVibration) {
            vibration();
        }
        int i = barcode.format;
        this.tinyDB.putString(Constants.BARCODE_RAW_VALUE, barcode.rawValue);
        this.tinyDB.putInt(Constants.BARCODE_VALUE, barcode.format);
        ScannedBarcodeInfoFragment scannedBarcodeInfoFragment = new ScannedBarcodeInfoFragment();
        FragmentTransaction beginTransaction = ((MainActivity) this.activity).getSupportFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.fragment_layout, scannedBarcodeInfoFragment);
        beginTransaction.commitAllowingStateLoss();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(StopScanEvent stopScanEvent) {
        if (stopScanEvent.isCheckStatus()) {
            BarcodeCapture barcodeCapture2 = this.barcodeCapture;
            if (barcodeCapture2 != null) {
                barcodeCapture2.stopScanning();
                return;
            }
            return;
        }
        ((MainActivity) this.activity).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainScanFragment()).commitAllowingStateLoss();
    }

    public void onActivityResult(int i, int i2, @Nullable Intent intent) {
        super.onActivityResult(i, i2, intent);
    }

    public void onRetrieved(final Barcode barcode) {
//        FirebaseAnalytics.getInstance(this.activity).logEvent("scanned", new Bundle());
        String str = this.TAG;
        Log.d(str, "Barcode read: " + barcode.rawValue);
        this.activity.runOnUiThread(new Runnable() {
            public final void run() {
                MainScanFragment.lambda$onRetrieved$4(MainScanFragment.this, barcode);
            }
        });
    }

    public static /* synthetic */ void lambda$onRetrieved$4(MainScanFragment mainScanFragment, Barcode barcode) {
        mainScanFragment.ScannedResultProcess(barcode);
    }

    public void onBitmapScanned(SparseArray<Barcode> sparseArray) {
        Log.e("kek", "onBitmapScanned: " + sparseArray.toString());
    }

    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    public void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    public void onDestroy() {
        super.onDestroy();
        BarcodeCapture barcodeCapture2 = this.barcodeCapture;
        if (barcodeCapture2 != null) {
            barcodeCapture2.stopScanning();
        }
    }
}
