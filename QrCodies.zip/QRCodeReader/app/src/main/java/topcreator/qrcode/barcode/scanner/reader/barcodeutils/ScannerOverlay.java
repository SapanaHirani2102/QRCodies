package topcreator.qrcode.barcode.scanner.reader.barcodeutils;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.ViewGroup;
import androidx.core.content.ContextCompat;
import topcreator.qrcode.barcode.scanner.reader.R;

public class ScannerOverlay extends ViewGroup {
    private float endY;
    private int frames;
    private float left;
    private int lineColor;
    private int lineWidth;
    private int rectHeight;
    private int rectWidth;
    private boolean revAnimation;
    private float top;

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public ScannerOverlay(Context context) {
        super(context);
    }

    public ScannerOverlay(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ScannerOverlay(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, R.styleable.ScannerOverlay, 0, 0);
        this.rectWidth = obtainStyledAttributes.getInteger(4, getResources().getInteger(R.integer.scanner_rect_width));
        this.rectHeight = obtainStyledAttributes.getInteger(3, getResources().getInteger(R.integer.scanner_rect_height));
        this.lineColor = obtainStyledAttributes.getColor(0, ContextCompat.getColor(context, R.color.scanner_line));
        this.lineWidth = obtainStyledAttributes.getInteger(2, getResources().getInteger(R.integer.line_width));
        this.frames = obtainStyledAttributes.getInteger(1, getResources().getInteger(R.integer.line_width));
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        setMeasuredDimension(i, i2);
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        this.left = (float) ((i - dpToPx(this.rectWidth)) / 2);
        this.top = (float) ((i2 - dpToPx(this.rectHeight)) / 2);
        this.endY = this.top;
        super.onSizeChanged(i, i2, i3, i4);
    }

    public int dpToPx(int i) {
        return Math.round(((float) i) * (getResources().getDisplayMetrics().xdpi / 160.0f));
    }

    /* access modifiers changed from: protected */
    public void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        float f = (float) 0;
        canvas.drawRoundRect(new RectF(this.left, this.top, ((float) dpToPx(this.rectWidth)) + this.left, ((float) dpToPx(this.rectHeight)) + this.top), f, f, paint);
        Paint paint2 = new Paint();
        paint2.setColor(this.lineColor);
        paint2.setStrokeWidth(Float.valueOf((float) this.lineWidth).floatValue());
        float f2 = this.endY;
        float dpToPx = this.top + ((float) dpToPx(this.rectHeight));
        int i = this.frames;
        if (f2 >= dpToPx + ((float) i)) {
            this.revAnimation = true;
        } else if (this.endY == this.top + ((float) i)) {
            this.revAnimation = false;
        }
        if (this.revAnimation) {
            this.endY -= (float) this.frames;
        } else {
            this.endY += (float) this.frames;
        }
        float f3 = this.left;
        canvas.drawLine(f3, this.endY, f3 + ((float) dpToPx(this.rectWidth)), this.endY, paint2);
        invalidate();
    }
}
