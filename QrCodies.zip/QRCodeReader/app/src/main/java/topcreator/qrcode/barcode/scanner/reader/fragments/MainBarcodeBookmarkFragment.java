package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.adapter.ViewPagerAdapter;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import com.google.android.material.tabs.TabLayout;

public class MainBarcodeBookmarkFragment extends Fragment {
    private Activity activity;
    ViewPagerAdapter adapter;
    private ImageView mMainBookmarkFilterImg;
    private ImageView mMainFilterImg;
    private TabLayout mMainHistoryTab;
    private ViewPager mMainHistoryVp;
    /* access modifiers changed from: private */
    public int[] navIcons = {R.drawable.uic_qr_icon_non, R.drawable.uic_barcode_icon_non, R.drawable.uic_history_business_card_non};
    /* access modifiers changed from: private */
    public int[] navIconsActive = {R.drawable.uic_qr_icon, R.drawable.uic_barcode_icon, R.drawable.uic_history_business_card};
    private int[] navLabels = {R.string.history_tab_scan, R.string.history_tab_generate, R.string.history_tab_card};
    private TinyDB tinyDB;

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (MainActivity) context;
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_main_bookmark_history, viewGroup, false);
        initView(inflate);
        Bundle arguments = getArguments();
        if (arguments != null) {
            setupViewPager(this.mMainHistoryVp, arguments);
            iconTabLayout();
        } else {
            setupViewPager(this.mMainHistoryVp);
            iconTabLayout();
        }
        this.mMainFilterImg.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainBarcodeBookmarkFragment.lambda$onCreateView$0(MainBarcodeBookmarkFragment.this, view);
            }
        });
        return inflate;
    }

    public static /* synthetic */ void lambda$onCreateView$0(MainBarcodeBookmarkFragment mainBarcodeBookmarkFragment, View view) {
        ResultTypeFilterFragment resultTypeFilterFragment = new ResultTypeFilterFragment();
        Bundle bundle = new Bundle();
        bundle.putString(Constants.FILTER_TYPE_LIST, Constants.TYPE_BOOKMARK);
        resultTypeFilterFragment.setArguments(bundle);
        ((MainActivity) mainBarcodeBookmarkFragment.activity).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, resultTypeFilterFragment).commitAllowingStateLoss();
        mainBarcodeBookmarkFragment.tinyDB.putString(Constants.FILTER_TYPE_FRAGMENT, "bookmarkFilter");
    }

    private void initView(View view) {
        this.tinyDB = TinyDB.getInstance(this.activity);
        this.mMainHistoryVp = (ViewPager) view.findViewById(R.id.main_bookmark_vp);
        this.mMainHistoryTab = (TabLayout) view.findViewById(R.id.main_bookmark_tab);
        this.mMainFilterImg = (ImageView) view.findViewById(R.id.main_filter_img);
        this.mMainBookmarkFilterImg = (ImageView) view.findViewById(R.id.main_bookmark_filter_img);

    }

    private void setupViewPager(ViewPager viewPager, Bundle bundle) {
        ScannedBarcodeBookmarkFragment scannedBarcodeBookmarkFragment = new ScannedBarcodeBookmarkFragment();
        scannedBarcodeBookmarkFragment.setArguments(bundle);
        GenerateBarcodeBookmarkFragment generateBarcodeBookmarkFragment = new GenerateBarcodeBookmarkFragment();
        generateBarcodeBookmarkFragment.setArguments(bundle);
        CardBookmarkFragment cardBookmarkFragment = new CardBookmarkFragment();
        cardBookmarkFragment.setArguments(bundle);
        this.adapter = new ViewPagerAdapter(((MainActivity) this.activity).getSupportFragmentManager());
        this.adapter.addFragment(scannedBarcodeBookmarkFragment, "MBFONE");
        this.adapter.addFragment(generateBarcodeBookmarkFragment, "MBFTWO");
        this.adapter.addFragment(cardBookmarkFragment, "MBTWO");
        viewPager.setAdapter(this.adapter);
        viewPager.setSaveFromParentEnabled(false);
        viewPager.setOffscreenPageLimit(3);
        this.mMainHistoryTab.setupWithViewPager(viewPager);
    }

    private void setupViewPager(ViewPager viewPager) {
        this.adapter = new ViewPagerAdapter(((MainActivity) this.activity).getSupportFragmentManager());
        this.adapter.addFragment(new ScannedBarcodeBookmarkFragment(), "MBONE");
        this.adapter.addFragment(new GenerateBarcodeBookmarkFragment(), "MBTWO");
        this.adapter.addFragment(new CardBookmarkFragment(), "MBTWO");
        viewPager.setAdapter(this.adapter);
        viewPager.setSaveFromParentEnabled(false);
        viewPager.setOffscreenPageLimit(3);
        this.mMainHistoryTab.setupWithViewPager(viewPager);
    }

    private void iconTabLayout() {
        for (int i = 0; i < this.mMainHistoryTab.getTabCount(); i++) {
            LinearLayout linearLayout = (LinearLayout) LayoutInflater.from(this.activity).inflate(R.layout.nav_item_layout, null);
            TextView textView = (TextView) linearLayout.findViewById(R.id.nav_label);
            ImageView imageView = (ImageView) linearLayout.findViewById(R.id.nav_icon);
            textView.setText(getResources().getString(this.navLabels[i]));
            if (i == 0) {
                textView.setTextColor(getResources().getColor(R.color.white));
                imageView.setImageResource(this.navIconsActive[i]);
            } else {
                imageView.setImageResource(this.navIcons[i]);
            }
            TabLayout.Tab tabAt = this.mMainHistoryTab.getTabAt(i);
            if (tabAt != null) {
                tabAt.setCustomView((View) linearLayout);
            }
        }
        this.mMainHistoryTab.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            public void onTabReselected(TabLayout.Tab tab) {
            }

            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                if (customView != null) {
                    ((TextView) customView.findViewById(R.id.nav_label)).setTextColor(MainBarcodeBookmarkFragment.this.getResources().getColor(R.color.white));
                    ((ImageView) customView.findViewById(R.id.nav_icon)).setImageResource(MainBarcodeBookmarkFragment.this.navIconsActive[tab.getPosition()]);
                }
            }

            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                if (customView != null) {
                    ((TextView) customView.findViewById(R.id.nav_label)).setTextColor(MainBarcodeBookmarkFragment.this.getResources().getColor(R.color.non_selected_tab));
                    ((ImageView) customView.findViewById(R.id.nav_icon)).setImageResource(MainBarcodeBookmarkFragment.this.navIcons[tab.getPosition()]);
                }
            }
        });
    }

    public void onDestroy() {
        super.onDestroy();
        for (Fragment remove : ((MainActivity) this.activity).getSupportFragmentManager().getFragments()) {
            ((MainActivity) this.activity).getSupportFragmentManager().beginTransaction().remove(remove).commitAllowingStateLoss();
        }
    }
}
