package topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.result;

import android.app.Activity;
import topcreator.qrcode.barcode.scanner.reader.R;
import com.google.zxing.client.result.GeoParsedResult;
import com.google.zxing.client.result.ParsedResult;

public final class GeoResultHandler extends ResultHandler {
    public int getButtonCount() {
        return 0;
    }

    public int getButtonText(int i) {
        return 0;
    }

    public int getDisplayTitle() {
        return R.string.result_geo;
    }

    public GeoResultHandler(Activity activity, ParsedResult parsedResult) {
        super(activity, parsedResult);
    }

    public void handleButtonPress(int i) {
        GeoParsedResult geoParsedResult = (GeoParsedResult) getResult();
        switch (i) {
            case 0:
                openMap(geoParsedResult.getGeoURI());
                return;
            case 1:
                getDirections(geoParsedResult.getLatitude(), geoParsedResult.getLongitude());
                return;
            default:
                return;
        }
    }
}
