package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.adapter.ViewPagerAdapter;
import topcreator.qrcode.barcode.scanner.reader.splashexit.Splash_Activity;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import com.google.android.material.tabs.TabLayout;

public class MainBarcodeHistotyFragment extends Fragment {
    private Activity activity;
    ViewPagerAdapter adapter;
    private Handler handler;
    /* access modifiers changed from: private */
    public ProgressBar mLoadingPb;
    private ImageView mMainBookmarkFilterImg;
    private ImageView mMainFilterImg;
    private TabLayout mMainHistoryTab;
    /* access modifiers changed from: private */
    public ViewPager mMainHistoryVp;
    /* access modifiers changed from: private */
    public int[] navIcons = {R.drawable.uic_qr_icon_non, R.drawable.uic_barcode_icon_non, R.drawable.uic_history_business_card_non};
    /* access modifiers changed from: private */
    public int[] navIconsActive = {R.drawable.uic_qr_icon, R.drawable.uic_barcode_icon, R.drawable.uic_history_business_card};
    private int[] navLabels = {R.string.history_tab_scan, R.string.history_tab_generate, R.string.history_tab_card};
    private Runnable runnable;
    private TinyDB tinyDB;
    private FrameLayout adMobView;

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (MainActivity) context;
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.fragment_main_barcode_histoty, viewGroup, false);
        initView(inflate);

        adMobView = (FrameLayout) inflate.findViewById(R.id.adMobView);
        showBanner();

        ProgressBar progressBar = this.mLoadingPb;
        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
        final Bundle arguments = getArguments();
        if (arguments != null) {
            this.handler = new Handler();
            this.runnable = new Runnable() {
                public void run() {
                    if (mLoadingPb != null) {
                        mLoadingPb.setVisibility(View.GONE);
                    }
                    MainBarcodeHistotyFragment mainBarcodeHistotyFragment = MainBarcodeHistotyFragment.this;
                    mainBarcodeHistotyFragment.setupViewPager(mainBarcodeHistotyFragment.mMainHistoryVp, arguments);
                    iconTabLayout();
                }
            };
            this.handler.postDelayed(this.runnable, 1500);
        } else {
            this.handler = new Handler();
            this.runnable = new Runnable() {
                public void run() {
                    if (mLoadingPb != null) {
                        mLoadingPb.setVisibility(View.GONE);
                    }
                    MainBarcodeHistotyFragment mainBarcodeHistotyFragment = MainBarcodeHistotyFragment.this;
                    mainBarcodeHistotyFragment.setupViewPager(mainBarcodeHistotyFragment.mMainHistoryVp);
                    iconTabLayout();
                }
            };
            this.handler.postDelayed(this.runnable, 1500);
        }
        this.mMainFilterImg.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                MainBarcodeHistotyFragment.lambda$onCreateView$0(MainBarcodeHistotyFragment.this, view);
            }
        });
        this.mMainBookmarkFilterImg.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                ((MainActivity) activity).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainBarcodeBookmarkFragment()).commitAllowingStateLoss();
            }
        });
        return inflate;
    }

    public static /* synthetic */ void lambda$onCreateView$0(MainBarcodeHistotyFragment mainBarcodeHistotyFragment, View view) {
        ((MainActivity) mainBarcodeHistotyFragment.activity).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new ResultTypeFilterFragment()).commitAllowingStateLoss();
        mainBarcodeHistotyFragment.tinyDB.putString(Constants.FILTER_TYPE_FRAGMENT, "historyFilter");
    }

    private void initView(View view) {
        this.tinyDB = TinyDB.getInstance(this.activity);
        this.mMainHistoryVp = (ViewPager) view.findViewById(R.id.main_history_vp);
        this.mMainHistoryTab = (TabLayout) view.findViewById(R.id.main_history_tab);
        this.mMainFilterImg = (ImageView) view.findViewById(R.id.main_filter_img);
        this.mMainBookmarkFilterImg = (ImageView) view.findViewById(R.id.main_bookmark_filter_img);
        this.mLoadingPb = (ProgressBar) view.findViewById(R.id.loading_pb);
    }

    /* access modifiers changed from: private */
    public void setupViewPager(ViewPager viewPager, Bundle bundle) {
        ScannedBarcodeHistoryFragment scannedBarcodeHistoryFragment = new ScannedBarcodeHistoryFragment();
        scannedBarcodeHistoryFragment.setArguments(bundle);
        GenerateBarcodeHistoryFragment generateBarcodeHistoryFragment = new GenerateBarcodeHistoryFragment();
        generateBarcodeHistoryFragment.setArguments(bundle);
        CardHistoryFragment cardHistoryFragment = new CardHistoryFragment();
        cardHistoryFragment.setArguments(bundle);
        this.adapter = new ViewPagerAdapter(((MainActivity) this.activity).getSupportFragmentManager());
        this.adapter.addFragment(scannedBarcodeHistoryFragment, "MHFONE");
        this.adapter.addFragment(generateBarcodeHistoryFragment, "MHFTWO");
        this.adapter.addFragment(cardHistoryFragment, "MHFTWO");
        viewPager.setAdapter(this.adapter);
        viewPager.setSaveFromParentEnabled(false);
        viewPager.setOffscreenPageLimit(3);
        this.mMainHistoryTab.setupWithViewPager(viewPager);
    }

    /* access modifiers changed from: private */
    public void setupViewPager(ViewPager viewPager) {
        this.adapter = new ViewPagerAdapter(((MainActivity) this.activity).getSupportFragmentManager());
        this.adapter.addFragment(new ScannedBarcodeHistoryFragment(), "MHONE");
        this.adapter.addFragment(new GenerateBarcodeHistoryFragment(), "MHTWO");
        this.adapter.addFragment(new CardHistoryFragment(), "MHTHREE");
        viewPager.setAdapter(this.adapter);
        viewPager.setSaveFromParentEnabled(false);
        viewPager.setOffscreenPageLimit(3);
        this.mMainHistoryTab.setupWithViewPager(viewPager);
    }

    /* access modifiers changed from: private */
    public void iconTabLayout() {
        for (int i = 0; i < this.mMainHistoryTab.getTabCount(); i++) {
            LinearLayout linearLayout = (LinearLayout) LayoutInflater.from(this.activity).inflate(R.layout.nav_item_layout, null);
            TextView textView = (TextView) linearLayout.findViewById(R.id.nav_label);
            ImageView imageView = (ImageView) linearLayout.findViewById(R.id.nav_icon);
            textView.setText(getResources().getString(this.navLabels[i]));
            if (i == 0) {
                textView.setTextColor(getResources().getColor(R.color.white));
                imageView.setImageResource(this.navIconsActive[i]);
            } else {
                imageView.setImageResource(this.navIcons[i]);
            }
            TabLayout.Tab tabAt = this.mMainHistoryTab.getTabAt(i);
            if (tabAt != null) {
                tabAt.setCustomView((View) linearLayout);
            }
        }
        this.mMainHistoryTab.addOnTabSelectedListener((TabLayout.OnTabSelectedListener) new TabLayout.OnTabSelectedListener() {
            public void onTabReselected(TabLayout.Tab tab) {
            }

            public void onTabSelected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                if (customView != null) {
                    ((TextView) customView.findViewById(R.id.nav_label)).setTextColor(getResources().getColor(R.color.white));
                    ((ImageView) customView.findViewById(R.id.nav_icon)).setImageResource(navIconsActive[tab.getPosition()]);
                }
            }

            public void onTabUnselected(TabLayout.Tab tab) {
                View customView = tab.getCustomView();
                if (customView != null) {
                    ((TextView) customView.findViewById(R.id.nav_label)).setTextColor(getResources().getColor(R.color.non_selected_tab));
                    ((ImageView) customView.findViewById(R.id.nav_icon)).setImageResource(navIcons[tab.getPosition()]);
                }
            }
        });
    }

    public void onDestroy() {
        super.onDestroy();
        for (Fragment next : ((MainActivity) this.activity).getSupportFragmentManager().getFragments()) {
            if ((next instanceof ScannedBarcodeHistoryFragment) || (next instanceof GenerateBarcodeHistoryFragment) || (next instanceof CardHistoryFragment)) {
                ((MainActivity) this.activity).getSupportFragmentManager().beginTransaction().remove(next).commitAllowingStateLoss();
            }
        }
        Handler handler2 = this.handler;
        if (handler2 != null) {
            Runnable runnable2 = this.runnable;
            if (runnable2 != null) {
                handler2.removeCallbacks(runnable2);
            }
        }
    }

    private void showBanner() {
        final AdView mAdView = new AdView(getActivity());
        mAdView.setAdSize(getAdSize());
        mAdView.setAdUnitId(Splash_Activity.adModel.getAdMobBanner());
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                if (adMobView != null) {
                    adMobView.removeAllViews();
                }
                adMobView.addView(mAdView);
            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        if (adMobView != null) {
            adMobView.removeAllViews();
        }
    }

    private com.google.android.gms.ads.AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = getActivity().getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(getActivity(), adWidth);
    }
}
