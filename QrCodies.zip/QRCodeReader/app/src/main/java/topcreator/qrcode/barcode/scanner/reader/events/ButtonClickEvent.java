package topcreator.qrcode.barcode.scanner.reader.events;

import android.view.View;

public class ButtonClickEvent {
    private View view;

    public ButtonClickEvent(View view2) {
        this.view = view2;
    }

    public View getView() {
        return this.view;
    }
}
