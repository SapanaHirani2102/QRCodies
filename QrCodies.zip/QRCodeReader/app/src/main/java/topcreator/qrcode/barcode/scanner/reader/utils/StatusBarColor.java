package topcreator.qrcode.barcode.scanner.reader.utils;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import androidx.core.content.ContextCompat;

public class StatusBarColor {
    public static void darkenStatusBar(Activity activity, int i) {
        if (Build.VERSION.SDK_INT >= 21) {
            activity.getWindow().setStatusBarColor(ContextCompat.getColor(activity, i));
        }
    }

    private static int darkenColor(int i) {
        float[] fArr = new float[3];
        Color.colorToHSV(i, fArr);
        fArr[2] = fArr[2] * 0.8f;
        return Color.HSVToColor(fArr);
    }
}
