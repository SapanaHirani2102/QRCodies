package topcreator.qrcode.barcode.scanner.reader.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.activities.MainActivity;
import topcreator.qrcode.barcode.scanner.reader.adapter.BaseRecyclerAdapter;
import topcreator.qrcode.barcode.scanner.reader.database.CardDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDataEntity;
import topcreator.qrcode.barcode.scanner.reader.database.ScanDatabase;
import topcreator.qrcode.barcode.scanner.reader.holder.CardFilterItemsHeaderHolder;
import topcreator.qrcode.barcode.scanner.reader.holder.CardItemsHeaderHolder;
import topcreator.qrcode.barcode.scanner.reader.holder.GenerateItemsHeaderHolder;
import topcreator.qrcode.barcode.scanner.reader.holder.ScanItemsHolder;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.TinyDB;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CardHistoryFragment extends Fragment  {
    private Activity activity;
    private String filterType = "all";
    BaseRecyclerAdapter<ScanDataEntity, ScanItemsHolder> mAdapter;
    BaseRecyclerAdapter<String, GenerateItemsHeaderHolder> mAdapterHeader;
    private TextView mEmptyTxt;
    private RecyclerView mScannedHeaderRv;
    private RecyclerView mScannedRv;
    private List<ScanDataEntity> myOptions = new ArrayList();
    private String requestType;
    ScanDatabase scanDatabase;
    private TinyDB tinyDB;


    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof Activity) {
            this.activity = (MainActivity) context;
        }
    }

    @Nullable
    public View onCreateView(@NonNull LayoutInflater layoutInflater, @Nullable ViewGroup viewGroup, @Nullable Bundle bundle) {
        View inflate = layoutInflater.inflate(R.layout.activity_scanned_barcode_items, viewGroup, false);
        this.activity.getWindow().clearFlags(1024);
        this.tinyDB = TinyDB.getInstance(this.activity);
        this.mScannedRv = (RecyclerView) inflate.findViewById(R.id.scanned_rv);
        this.mScannedHeaderRv = (RecyclerView) inflate.findViewById(R.id.scanned_rv_header);
        this.mEmptyTxt = (TextView) inflate.findViewById(R.id.empty_txt);
        this.scanDatabase = ScanDatabase.getInstance(this.activity);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyyy", Locale.ENGLISH);
        simpleDateFormat.format(new Date());
        simpleDateFormat2.format(new Date());
        simpleDateFormat3.format(new Date());
        Bundle arguments = getArguments();
        if (arguments != null) {
            this.requestType = "filterItemSelected";
            this.filterType = arguments.getString(Constants.FILTER_TYPE);
            this.tinyDB.putString(Constants.FILTER_TYPE_SP, this.filterType);
            this.tinyDB.putString(Constants.FILTER_TYPE_BACK, this.requestType);
            this.mScannedHeaderRv.setVisibility(View.VISIBLE);
            if (!this.filterType.equals(Constants.TYPE_URI) && !this.filterType.equals(Constants.TYPE_EMAIL_ADDRESS)) {
                String str = this.filterType;
            }
            this.mAdapterHeader = new BaseRecyclerAdapter<>(R.layout.scanned_items_header, CardFilterItemsHeaderHolder.class);
            this.mScannedHeaderRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedHeaderRv.setAdapter(this.mAdapterHeader);
            this.mAdapterHeader.setData(filterTypeData(this.filterType));
        } else {
            this.requestType = "filterItemNotSelected";
            this.tinyDB.putString(Constants.FILTER_TYPE_BACK, this.requestType);
            this.mScannedHeaderRv.setVisibility(View.VISIBLE);
            this.mAdapterHeader = new BaseRecyclerAdapter<>(R.layout.scanned_items_header, CardItemsHeaderHolder.class);
            this.mScannedHeaderRv.setLayoutManager(new StaggeredGridLayoutManager(1, 1));
            this.mScannedHeaderRv.setAdapter(this.mAdapterHeader);
            this.mAdapterHeader.setData(filterData());
        }
        return inflate;
    }

    private List<CardDataEntity> getNonDuplicate() {
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        List<CardDataEntity> cardAllNonDuplicate = this.scanDatabase.scanDataDao().getCardAllNonDuplicate();
        if (cardAllNonDuplicate.size() == 0) {
            this.mEmptyTxt.setVisibility(View.VISIBLE);
        }
        Collections.sort(cardAllNonDuplicate, new Comparator() {
            public final int compare(Object obj, Object obj2) {
                return CardHistoryFragment.lambda$getNonDuplicate$0(simpleDateFormat, (CardDataEntity) obj, (CardDataEntity) obj2);
            }
        });
        Collections.reverse(cardAllNonDuplicate);
        return cardAllNonDuplicate;
    }

    static /* synthetic */ int lambda$getNonDuplicate$0(SimpleDateFormat simpleDateFormat, CardDataEntity cardDataEntity, CardDataEntity cardDataEntity2) {
        try {
            return simpleDateFormat.parse(cardDataEntity.getTime()).compareTo(simpleDateFormat.parse(cardDataEntity2.getTime()));
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private List<CardDataEntity> getNonFilterDuplicate(String str) {
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        List<CardDataEntity> allCardFilterNonDuplicate = this.scanDatabase.scanDataDao().getAllCardFilterNonDuplicate(str);
        if (allCardFilterNonDuplicate.size() == 0) {
            this.mEmptyTxt.setVisibility(View.VISIBLE);
        }
        Collections.sort(allCardFilterNonDuplicate, new Comparator() {
                      public final int compare(Object obj, Object obj2) {
                return CardHistoryFragment.lambda$getNonFilterDuplicate$1(simpleDateFormat, (CardDataEntity) obj, (CardDataEntity) obj2);
            }
        });
        Collections.reverse(allCardFilterNonDuplicate);
        return allCardFilterNonDuplicate;
    }

    static /* synthetic */ int lambda$getNonFilterDuplicate$1(SimpleDateFormat simpleDateFormat, CardDataEntity cardDataEntity, CardDataEntity cardDataEntity2) {
        try {
            return simpleDateFormat.parse(cardDataEntity.getTime()).compareTo(simpleDateFormat.parse(cardDataEntity2.getTime()));
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private String[] splitDate(String str) {
        return str.split("-");
    }

    private String getMonth(int i) {
        return new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}[i];
    }

    private List<ScanDataEntity> getScannedDataList() {
        List<ScanDataEntity> allWords = this.scanDatabase.scanDataDao().getAllWords();
        Collections.reverse(allWords);
        return allWords;
    }

    private List<ScanDataEntity> getListFilerByType(String str) {
        List<ScanDataEntity> scannedDataList = getScannedDataList();
        ArrayList arrayList = new ArrayList();
        for (ScanDataEntity next : scannedDataList) {
            if (next.getScannedType().equals(str)) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    private List<String> filterData() {
        List<CardDataEntity> nonDuplicate = getNonDuplicate();
        ArrayList arrayList = new ArrayList();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM-yyyy", Locale.ENGLISH);
        new SimpleDateFormat("yyyy", Locale.ENGLISH);
        new SimpleDateFormat("MMM", Locale.ENGLISH);
        Calendar instance = Calendar.getInstance();
        instance.set(7, 1);
        try {
            Date parse = simpleDateFormat.parse(simpleDateFormat.format(instance.getTime()));
            instance.set(7, 7);
            Date parse2 = simpleDateFormat.parse(simpleDateFormat.format(instance.getTime()));
            Calendar instance2 = Calendar.getInstance();
            String format = simpleDateFormat.format(instance2.getTime());
            String format2 = simpleDateFormat2.format(instance2.getTime());
            instance2.add(5, -1);
            String format3 = simpleDateFormat.format(instance2.getTime());
            for (CardDataEntity time : nonDuplicate) {
                String format4 = simpleDateFormat.format(new Date(new Timestamp(Long.parseLong(time.getTime())).getTime()));
                Date parse3 = simpleDateFormat.parse(format4);
                if (!format4.contains(format2)) {
                    if (!arrayList.contains(getMonth(Integer.parseInt(splitDate(format4)[1]) - 1) + "-" + splitDate(format4)[2])) {
                        arrayList.add(getMonth(Integer.parseInt(splitDate(format4)[1]) - 1) + "-" + splitDate(format4)[2]);
                    }
                } else if (format4.equals(format)) {
                    arrayList.add(Constants.DATE_TYPE_DAY);
                } else if (format4.equals(format3)) {
                    arrayList.add(Constants.DATE_TYPE_YESTERDAY);
                } else if (parse3.getTime() < parse.getTime() || parse3.getTime() > parse2.getTime()) {
                    if (!arrayList.contains(Constants.DATE_TYPE_MONTH)) {
                        arrayList.add(Constants.DATE_TYPE_MONTH);
                    }
                } else if (!arrayList.contains(Constants.DATE_TYPE_WEEK)) {
                    arrayList.add(Constants.DATE_TYPE_WEEK);
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    private List<String> filterTypeData(String str) {
        List<CardDataEntity> nonFilterDuplicate = getNonFilterDuplicate(str);
        ArrayList arrayList = new ArrayList();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("MM-yyyy", Locale.ENGLISH);
        new SimpleDateFormat("yyyy", Locale.ENGLISH);
        new SimpleDateFormat("MMM", Locale.ENGLISH);
        Calendar instance = Calendar.getInstance();
        instance.set(7, 1);
        try {
            Date parse = simpleDateFormat.parse(simpleDateFormat.format(instance.getTime()));
            instance.set(7, 7);
            Date parse2 = simpleDateFormat.parse(simpleDateFormat.format(instance.getTime()));
            Calendar instance2 = Calendar.getInstance();
            String format = simpleDateFormat.format(instance2.getTime());
            String format2 = simpleDateFormat2.format(instance2.getTime());
            instance2.add(5, -1);
            String format3 = simpleDateFormat.format(instance2.getTime());
            for (CardDataEntity time : nonFilterDuplicate) {
                String format4 = simpleDateFormat.format(new Date(new Timestamp(Long.parseLong(time.getTime())).getTime()));
                Date parse3 = simpleDateFormat.parse(format4);
                if (!format4.contains(format2)) {
                    if (!arrayList.contains(getMonth(Integer.parseInt(splitDate(format4)[1]) - 1) + "-" + splitDate(format4)[2])) {
                        arrayList.add(getMonth(Integer.parseInt(splitDate(format4)[1]) - 1) + "-" + splitDate(format4)[2]);
                    }
                } else if (format4.equals(format)) {
                    arrayList.add(Constants.DATE_TYPE_DAY);
                } else if (format4.equals(format3)) {
                    arrayList.add(Constants.DATE_TYPE_YESTERDAY);
                } else if (parse3.getTime() < parse.getTime() || parse3.getTime() > parse2.getTime()) {
                    if (!arrayList.contains(Constants.DATE_TYPE_MONTH)) {
                        arrayList.add(Constants.DATE_TYPE_MONTH);
                    }
                } else if (!arrayList.contains(Constants.DATE_TYPE_WEEK)) {
                    arrayList.add(Constants.DATE_TYPE_WEEK);
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    private List<ScanDataEntity> getScannedTimeDataList(String str, String str2, String str3, String str4) {
        List<ScanDataEntity> genericTimeDataList = this.scanDatabase.scanDataDao().getGenericTimeDataList(str, str2, str3, str4);
        Collections.reverse(genericTimeDataList);
        return genericTimeDataList;
    }

    public void onInterstitialAdClose() {
        ((MainActivity) this.activity).getSupportFragmentManager().beginTransaction().replace(R.id.fragment_layout, new MainScanFragment()).commitAllowingStateLoss();
    }
}
