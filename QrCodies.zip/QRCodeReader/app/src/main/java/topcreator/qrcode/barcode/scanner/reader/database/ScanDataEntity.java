package topcreator.qrcode.barcode.scanner.reader.database;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "scan_data")
public class ScanDataEntity {
    private String date;
    private String result;
    @NonNull
    @PrimaryKey
    private String scannedCode;
    private String scannedImg;
    private String scannedType;
    private String sqlDate;
    private String time;

    public ScanDataEntity(String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.scannedCode = str;
        this.scannedType = str2;
        this.scannedImg = str3;
        this.time = str4;
        this.date = str5;
        this.result = str6;
        this.sqlDate = str7;
    }

    public ScanDataEntity() {

    }

    public String getDate() {
        return this.date;
    }

    public void setDate(String str) {
        this.date = str;
    }

    public String getSqlDate() {
        return this.sqlDate;
    }

    public void setSqlDate(String str) {
        this.sqlDate = str;
    }

    public String getScannedCode() {
        return this.scannedCode;
    }

    public void setScannedCode(String str) {
        this.scannedCode = str;
    }

    public String getScannedType() {
        return this.scannedType;
    }

    public void setScannedType(String str) {
        this.scannedType = str;
    }

    public String getScannedImg() {
        return this.scannedImg;
    }

    public void setScannedImg(String str) {
        this.scannedImg = str;
    }

    public String getTime() {
        return this.time;
    }

    public void setTime(String str) {
        this.time = str;
    }

    public String getResult() {
        return this.result;
    }

    public void setResult(String str) {
        this.result = str;
    }
}
