package topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.book;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.HttpHelper;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.Intents;
import topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.LocaleManager;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class SearchBookContentsActivity extends Activity {
    /* access modifiers changed from: private */
    public static final Pattern GT_ENTITY_PATTERN = Pattern.compile("&gt;");
    /* access modifiers changed from: private */
    public static final Pattern LT_ENTITY_PATTERN = Pattern.compile("&lt;");
    /* access modifiers changed from: private */
    public static final Pattern QUOTE_ENTITY_PATTERN = Pattern.compile("&#39;");
    /* access modifiers changed from: private */
    public static final Pattern QUOT_ENTITY_PATTERN = Pattern.compile("&quot;");
    /* access modifiers changed from: private */
    public static final String TAG = "SearchBookContentsActivity";
    /* access modifiers changed from: private */
    public static final Pattern TAG_PATTERN = Pattern.compile("<.*?>");
    private final View.OnClickListener buttonListener = new View.OnClickListener() {
        public void onClick(View view) {
            SearchBookContentsActivity.this.launchSearch();
        }
    };
    /* access modifiers changed from: private */
    public TextView headerView;
    private String isbn;
    private final View.OnKeyListener keyListener = new View.OnKeyListener() {
        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            if (i != 66 || keyEvent.getAction() != 0) {
                return false;
            }
            SearchBookContentsActivity.this.launchSearch();
            return true;
        }
    };
    private AsyncTask<String, ?, ?> networkTask;
    /* access modifiers changed from: private */
    public View queryButton;
    /* access modifiers changed from: private */
    public EditText queryTextView;
    /* access modifiers changed from: private */
    public ListView resultListView;

    private final class NetworkTask extends AsyncTask<String, Object, JSONObject> {
        private NetworkTask() {
        }

        /* access modifiers changed from: protected */
        public JSONObject doInBackground(String... strArr) {
            String str;
            try {
                String str2 = strArr[0];
                String str3 = strArr[1];
                if (LocaleManager.isBookSearchUrl(str3)) {
                    String substring = str3.substring(str3.indexOf(61) + 1);
                    str = "http://www.google.com/books?id=" + substring + "&jscmd=SearchWithinVolume2&q=" + str2;
                } else {
                    str = "http://www.google.com/books?vid=isbn" + str3 + "&jscmd=SearchWithinVolume2&q=" + str2;
                }
                return new JSONObject(HttpHelper.downloadViaHttp(str, HttpHelper.ContentType.JSON).toString());
            } catch (IOException | JSONException e) {
                Log.w(SearchBookContentsActivity.TAG, "Error accessing book search", e);
                return null;
            }
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(JSONObject jSONObject) {
            if (jSONObject == null) {
                SearchBookContentsActivity.this.headerView.setText(R.string.msg_sbc_failed);
            } else {
                handleSearchResults(jSONObject);
            }
            SearchBookContentsActivity.this.queryTextView.setEnabled(true);
            SearchBookContentsActivity.this.queryTextView.selectAll();
            SearchBookContentsActivity.this.queryButton.setEnabled(true);
        }

        private void handleSearchResults(JSONObject jSONObject) {
            try {
                int i = jSONObject.getInt("number_of_results");
                TextView access$300 = SearchBookContentsActivity.this.headerView;
                access$300.setText(SearchBookContentsActivity.this.getString(R.string.msg_sbc_results) + " : " + i);
                if (i > 0) {
                    JSONArray jSONArray = jSONObject.getJSONArray("search_results");
                    SearchBookContentsResult.setQuery(SearchBookContentsActivity.this.queryTextView.getText().toString());
                    ArrayList arrayList = new ArrayList(i);
                    for (int i2 = 0; i2 < i; i2++) {
                        arrayList.add(parseResult(jSONArray.getJSONObject(i2)));
                    }
                    SearchBookContentsActivity.this.resultListView.setOnItemClickListener(new BrowseBookListener(SearchBookContentsActivity.this, arrayList));
                    return;
                }
                if ("false".equals(jSONObject.optString("searchable"))) {
                    SearchBookContentsActivity.this.headerView.setText(R.string.msg_sbc_book_not_searchable);
                }
                SearchBookContentsActivity.this.resultListView.setAdapter(null);
            } catch (JSONException e) {
                Log.w(SearchBookContentsActivity.TAG, "Bad JSON from book search", e);
                SearchBookContentsActivity.this.resultListView.setAdapter(null);
                SearchBookContentsActivity.this.headerView.setText(R.string.msg_sbc_failed);
            }
        }

        private SearchBookContentsResult parseResult(JSONObject jSONObject) {
            String str;
            String str2;
            boolean z = false;
            try {
                String string = jSONObject.getString("page_id");
                String optString = jSONObject.optString("page_number");
                String optString2 = jSONObject.optString("snippet_text");
                if (optString == null || optString.isEmpty()) {
                    str = "";
                } else {
                    str = SearchBookContentsActivity.this.getString(R.string.msg_sbc_page) + ' ' + optString;
                }
                if (optString2 != null && !optString2.isEmpty()) {
                    z = true;
                }
                if (z) {
                    str2 = SearchBookContentsActivity.QUOT_ENTITY_PATTERN.matcher(SearchBookContentsActivity.QUOTE_ENTITY_PATTERN.matcher(SearchBookContentsActivity.GT_ENTITY_PATTERN.matcher(SearchBookContentsActivity.LT_ENTITY_PATTERN.matcher(SearchBookContentsActivity.TAG_PATTERN.matcher(optString2).replaceAll("")).replaceAll("<")).replaceAll(">")).replaceAll("'")).replaceAll("\"");
                } else {
                    str2 = '(' + SearchBookContentsActivity.this.getString(R.string.msg_sbc_snippet_unavailable) + ')';
                }
                return new SearchBookContentsResult(string, str, str2, z);
            } catch (JSONException e) {
                Log.w(SearchBookContentsActivity.TAG, e);
                return new SearchBookContentsResult(SearchBookContentsActivity.this.getString(R.string.msg_sbc_no_page_returned), "", "", false);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public String getISBN() {
        return this.isbn;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = getIntent();
        if (intent == null || !Intents.SearchBookContents.ACTION.equals(intent.getAction())) {
            finish();
            return;
        }
        this.isbn = intent.getStringExtra("ISBN");
        String str = this.isbn;
        if (str == null) {
            finish();
            return;
        }
        if (LocaleManager.isBookSearchUrl(str)) {
            setTitle(getString(R.string.sbc_name));
        } else {
            setTitle(getString(R.string.sbc_name) + ": ISBN " + this.isbn);
        }
        this.resultListView.addHeaderView(this.headerView);
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        this.queryTextView.selectAll();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        AsyncTask<String, ?, ?> asyncTask = this.networkTask;
        if (asyncTask != null) {
            asyncTask.cancel(true);
            this.networkTask = null;
        }
        super.onPause();
    }

    /* access modifiers changed from: private */
    public void launchSearch() {
        String obj = this.queryTextView.getText().toString();
        if (obj != null && !obj.isEmpty()) {
            AsyncTask<String, ?, ?> asyncTask = this.networkTask;
            if (asyncTask != null) {
                asyncTask.cancel(true);
            }
            this.networkTask = new NetworkTask();
            this.networkTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{obj, this.isbn});
            this.headerView.setText(R.string.msg_sbc_searching_book);
            this.resultListView.setAdapter(null);
            this.queryTextView.setEnabled(false);
            this.queryButton.setEnabled(false);
        }
    }
}
