package topcreator.qrcode.barcode.scanner.reader.utils;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;

import androidx.core.view.ViewCompat;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.util.Hashtable;

public class CreateDCode1 {
    public static Bitmap CreateOneDCode(String str, BarcodeFormat barcodeFormat, int i, int i2, int i3, int i4) {
        try {
            BitMatrix encode = new MultiFormatWriter().encode(str, barcodeFormat, i, i2);
            int width = encode.getWidth();
            int height = encode.getHeight();
            int[] iArr = new int[(width * height)];
            for (int i5 = 0; i5 < height; i5++) {
                for (int i6 = 0; i6 < width; i6++) {
                    if (encode.get(i6, i5)) {
                        iArr[(i5 * width) + i6] = i3;
                    } else {
                        iArr[(i5 * width) + i6] = i4;
                    }
                }
            }
            Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            createBitmap.setPixels(iArr, 0, i, 0, 0, i, i2);
            return createBitmap;
        } catch (Exception unused) {
            return null;
        }
    }

    public static Bitmap CreateOneDCode(String str, BarcodeFormat barcodeFormat, int i, int i2) {
        try {
            return CreateOneDCode(str, barcodeFormat, i, i2, ViewCompat.MEASURED_STATE_MASK, ViewCompat.MEASURED_SIZE_MASK);
        } catch (Exception unused) {
            return null;
        }
    }

    public static Bitmap CreateQRCode(String str, int i, int i2, int i3) throws WriterException {
        Hashtable hashtable = new Hashtable();
        hashtable.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        hashtable.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hashtable.put(EncodeHintType.MARGIN, 1);
        BitMatrix encode = new MultiFormatWriter().encode(str, BarcodeFormat.QR_CODE, i, i, hashtable);
        int width = encode.getWidth();
        int height = encode.getHeight();
        int[] iArr = new int[(width * height)];
        for (int i4 = 0; i4 < height; i4++) {
            for (int i5 = 0; i5 < width; i5++) {
                if (encode.get(i5, i4)) {
                    iArr[(i4 * width) + i5] = i2;
                } else {
                    iArr[(i4 * width) + i5] = i3;
                }
            }
        }
        Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        createBitmap.setPixels(iArr, 0, i, 0, 0, i, i);
        return createBitmap;
    }

    public static Bitmap CreateQRCode(String str, int i) {
        try {
            return CreateQRCode(str, i, ViewCompat.MEASURED_STATE_MASK, ViewCompat.MEASURED_SIZE_MASK);
        } catch (Exception unused) {
            return null;
        }
    }

    private static int checkParam(BitMatrix bitMatrix, Rect rect) {
        int i;
        int width = bitMatrix.getWidth();
        int height = bitMatrix.getHeight();
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        while (true) {
            i = 1;
            if (i3 >= height) {
                break;
            }
            int i6 = i5;
            int i7 = i4;
            int i8 = i3;
            int i9 = 0;
            while (i9 < width) {
                if (bitMatrix.get(i9, i8)) {
                    i6 = i9;
                    i7 = i8;
                    i9 = width;
                    i8 = height;
                }
                i9++;
            }
            i3 = i8 + 1;
            i4 = i7;
            i5 = i6;
        }
        int i10 = width - 1;
        int i11 = 0;
        while (i10 >= 0) {
            if (bitMatrix.get(i10, i4)) {
                i11 = i10;
                i10 = -1;
            }
            i10--;
        }
        int i12 = height - 1;
        while (i12 >= 0) {
            if (bitMatrix.get(i5, i12)) {
                i2 = i12;
                i12 = -1;
            }
            i12--;
        }
//        while (true) {
        int i13 = i5 + i;
        int i14 = i4 + i;
        while (!(i13 > i11 || i14 > i2 || !bitMatrix.get(i13, i14))) {
//                rect.left = i5;
//                rect.top = i4;
//                rect.right = i11;
//                rect.bottom = i2;
//            } else {
            i++;
            i13 = i5 + i;
            i14 = i4 + i;
        }
//        }
        rect.left = i5;
        rect.top = i4;
        rect.right = i11;
        rect.bottom = i2;
        return i;
    }

    public static Bitmap CreateQRCodeDot(String str, int i, int i2, int i3) {
        int i4 = i2;
        int i5 = i3;
        try {
            Hashtable hashtable = new Hashtable();
            hashtable.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hashtable.put(EncodeHintType.CHARACTER_SET, "utf-8");
            hashtable.put(EncodeHintType.MARGIN, 0);
            BitMatrix encode = new MultiFormatWriter().encode(str, BarcodeFormat.QR_CODE, i, i, hashtable);
            Rect rect = new Rect();
            int checkParam = checkParam(encode, rect);
            int width = encode.getWidth();
            int height = encode.getHeight();
            Paint paint = new Paint();
            if (i4 != -1 && i5 == -1) {
                paint.setColor(i4);
            } else if (i5 != -1) {
                LinearGradient linearGradient = new LinearGradient(0.0f, 0.0f, 0.0f, (float) height, i2, i3, Shader.TileMode.MIRROR);
                paint.setShader(linearGradient);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setAntiAlias(true);
            int i6 = checkParam / 2;
            int i7 = rect.top + i6;
            Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            for (int i8 = rect.left + i6; i8 <= rect.right; i8 += checkParam) {
                for (int i9 = i7; i9 <= rect.bottom; i9 += checkParam) {
                    if (encode.get(i8, i9)) {
                        canvas.drawCircle((float) i8, (float) i9, (float) i6, paint);
                    }
                }
            }
            return createBitmap;
        } catch (Exception unused) {
            return null;
        }
    }

    public static Bitmap CreateQRCodeBitmap(String str, int i, Bitmap[] bitmapArr, Bitmap bitmap) {
        int i2;
        BitMatrix bitMatrix;
        int i3;
        Bitmap bitmap2;
        Bitmap[] bitmapArr2 = bitmapArr;
        if (bitmapArr2 == null || bitmapArr2.length == 0) {
            return null;
        }
        try {
            int length = bitmapArr2.length;
            Hashtable hashtable = new Hashtable();
            hashtable.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hashtable.put(EncodeHintType.CHARACTER_SET, "utf-8");
            int i4 = 0;
            hashtable.put(EncodeHintType.MARGIN, 0);
            BitMatrix encode = new MultiFormatWriter().encode(str, BarcodeFormat.QR_CODE, i, i, hashtable);
            Rect rect = new Rect();
            int checkParam = checkParam(encode, rect);
            int width = encode.getWidth();
            int height = encode.getHeight();
            Paint paint = new Paint();
            int i5 = 1;
            paint.setAntiAlias(true);
            int i6 = checkParam / 2;
            int i7 = rect.left + i6;
            int i8 = rect.top + i6;
            Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            int i9 = checkParam * 7;
            while (i7 <= rect.right) {
                int i10 = i8;
                while (i10 <= rect.bottom) {
                    if (encode.get(i7, i10)) {
                        if ((i7 > rect.left + i9 || i10 > rect.top + i9) && (i7 < rect.right - i9 || i10 > rect.top + i9)) {
                            if (i7 <= rect.left + i9) {
                                if (i10 < rect.bottom - i9) {
                                }
                            }
                            if (length == i5) {
                                bitmap2 = bitmapArr2[i4];
                                i2 = i6;
                            } else {
                                double random = Math.random();
                                i2 = i6;
                                double d = (double) length;
                                Double.isNaN(d);
                                int i11 = (int) (d * random);
                                if (i11 >= length) {
                                    i11 = length - 1;
                                }
                                bitmap2 = bitmapArr2[i11];
                            }
                            i3 = length;
                            bitMatrix = encode;
                            canvas.drawBitmap(bitmap2, new Rect(i4, i4, bitmap2.getWidth(), bitmap2.getHeight()), new RectF((float) (i7 - i2), (float) (i10 - i2), (float) (i7 + i2), (float) (i10 + i2)), paint);
                        }
                        bitmap2 = bitmap;
                        i2 = i6;
                        i3 = length;
                        bitMatrix = encode;
                        canvas.drawBitmap(bitmap2, new Rect(i4, i4, bitmap2.getWidth(), bitmap2.getHeight()), new RectF((float) (i7 - i2), (float) (i10 - i2), (float) (i7 + i2), (float) (i10 + i2)), paint);
                    } else {
                        i3 = length;
                        bitMatrix = encode;
                        i2 = i6;
                    }
                    i10 += checkParam;
                    i6 = i2;
                    length = i3;
                    encode = bitMatrix;
                    bitmapArr2 = bitmapArr;
                    i4 = 0;
                    i5 = 1;
                }
                int i12 = length;
                BitMatrix bitMatrix2 = encode;
                int i13 = i6;
                i7 += checkParam;
                bitmapArr2 = bitmapArr;
                i4 = 0;
                i5 = 1;
            }
            return createBitmap;
        } catch (Exception unused) {
            return null;
        }
    }

    public static Bitmap CreateQRCodeSDot(String str, int i, int i2, int i3) {
        int i4;
        int i5 = i2;
        int i6 = i3;
        try {
            Hashtable hashtable = new Hashtable();
            hashtable.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hashtable.put(EncodeHintType.CHARACTER_SET, "utf-8");
            hashtable.put(EncodeHintType.MARGIN, 0);
            BitMatrix encode = new MultiFormatWriter().encode(str, BarcodeFormat.QR_CODE, i, i, hashtable);
            Rect rect = new Rect();
            int checkParam = checkParam(encode, rect);
            int width = encode.getWidth();
            int height = encode.getHeight();
            Paint paint = new Paint();
            if (i5 != -1 && i6 == -1) {
                paint.setColor(i5);
            } else if (i6 != -1) {
                LinearGradient linearGradient = new LinearGradient(0.0f, 0.0f, 0.0f, (float) height, i2, i3, Shader.TileMode.MIRROR);
                paint.setShader(linearGradient);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setAntiAlias(true);
            int i7 = checkParam * 7;
            int i8 = checkParam / 2;
            int i9 = rect.top + i8;
            Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(createBitmap);
            for (int i10 = rect.left + i8; i10 <= rect.right; i10 += checkParam) {
                for (int i11 = i9; i11 <= rect.bottom; i11 += checkParam) {
                    if (encode.get(i10, i11)) {
                        if ((i10 > rect.left + i7 || i11 > rect.top + i7) && (i10 < rect.right - i7 || i11 > rect.top + i7)) {
                            if (i10 <= rect.left + i7) {
                                if (i11 < rect.bottom - i7) {
                                }
                            }
                            double d = (double) i8;
                            Double.isNaN(d);
                            i4 = (int) (((Math.random() * 0.5d) + 0.75d) * d);
                            canvas.drawCircle((float) i10, (float) i11, (float) i4, paint);
                        }
                        i4 = i8;
                        canvas.drawCircle((float) i10, (float) i11, (float) i4, paint);
                    }
                }
            }
            return createBitmap;
        } catch (Exception unused) {
            return null;
        }
    }

    public static Bitmap CreateQRCodePolygon(String str, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        BitMatrix bitMatrix;
        int i7;
        int i8;
        Rect rect;
        int i9 = i3;
        int i10 = i4;
        int i11 = i2;
        int i12 = i11 < 3 ? 3 : i11;
        try {
            Hashtable hashtable = new Hashtable();
            hashtable.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hashtable.put(EncodeHintType.CHARACTER_SET, "utf-8");
            hashtable.put(EncodeHintType.MARGIN, 0);
            BitMatrix encode = new MultiFormatWriter().encode(str, BarcodeFormat.QR_CODE, i, i, hashtable);
            Rect rect2 = new Rect();
            int checkParam = checkParam(encode, rect2);
            int width = encode.getWidth();
            int height = encode.getHeight();
            Paint paint = new Paint();
            if (i9 != -1 && i10 == -1) {
                paint.setColor(i9);
            } else if (i10 != -1) {
                LinearGradient linearGradient = new LinearGradient(0.0f, 0.0f, 0.0f, (float) height, i3, i4, Shader.TileMode.MIRROR);
                paint.setShader(linearGradient);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setAntiAlias(true);
            int i13 = checkParam / 2;
            int i14 = rect2.left + i13;
            int i15 = rect2.top + i13;
            Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            double d = (double) i12;
            Double.isNaN(d);
            double d2 = 6.283185307179586d / d;
            Canvas canvas = new Canvas(createBitmap);
            int i16 = checkParam * 7;
            int i17 = i14;
            while (i17 <= rect2.right) {
                int i18 = i15;
                while (i18 <= rect2.bottom) {
                    if (encode.get(i17, i18)) {
                        if ((i17 > rect2.left + i16 || i18 > rect2.top + i16) && (i17 < rect2.right - i16 || i18 > rect2.top + i16)) {
                            if (i17 <= rect2.left + i16) {
                                if (i18 < rect2.bottom - i16) {
                                }
                            }
                            i8 = i18;
                            bitMatrix = encode;
                            int i19 = i17;
                            Path path = new Path();
                            path.moveTo((float) i19, (float) (i8 - i13));
                            int i20 = 1;
                            while (i20 < i12) {
                                double d3 = (double) i19;
                                double d4 = (double) i20;
                                Double.isNaN(d4);
                                double d5 = (d4 * d2) - 1.5707963267948966d;
                                double cos = Math.cos(d5);
                                int i21 = i12;
                                int i22 = i19;
                                double d6 = (double) i13;
                                Double.isNaN(d6);
                                Double.isNaN(d3);
                                float f = (float) ((int) (d3 + (cos * d6)));
                                Rect rect3 = rect2;
                                int i23 = checkParam;
                                double d7 = (double) i8;
                                double sin = Math.sin(d5);
                                Double.isNaN(d6);
                                Double.isNaN(d7);
                                path.lineTo(f, (float) ((int) (d7 + (sin * d6))));
                                i20++;
                                i12 = i21;
                                i19 = i22;
                                rect2 = rect3;
                                checkParam = i23;
                            }
                            i6 = i12;
                            i5 = i19;
                            rect = rect2;
                            i7 = checkParam;
                            path.close();
                            canvas.drawPath(path, paint);
                        }
                        i8 = i18;
                        bitMatrix = encode;
                        canvas.drawRect((float) (i17 - i13), (float) (i18 - i13), (float) (i17 + i13), (float) (i18 + i13), paint);
                        i6 = i12;
                        i5 = i17;
                        rect = rect2;
                        i7 = checkParam;
                    } else {
                        i8 = i18;
                        i5 = i17;
                        i6 = i12;
                        bitMatrix = encode;
                        rect = rect2;
                        i7 = checkParam;
                    }
                    i18 = i8 + i7;
                    encode = bitMatrix;
                    i12 = i6;
                    i17 = i5;
                    rect2 = rect;
                    checkParam = i7;
                }
                int i24 = i12;
                BitMatrix bitMatrix2 = encode;
                Rect rect4 = rect2;
                i17 += checkParam;
            }
            return createBitmap;
        } catch (Exception unused) {
            return null;
        }
    }

    public static Bitmap CreateQRCodeStar(String str, int i, int i2, int i3, int i4) {
        int i5;
        Rect rect;
        int i6;
        BitMatrix bitMatrix;
        int i7;
        int i8;
        Bitmap bitmap;
        int i9;
        Canvas canvas;
        int i10 = i3;
        int i11 = i4;
        int i12 = i2;
        int i13 = i12 < 3 ? 3 : i12;
        try {
            Hashtable hashtable = new Hashtable();
            hashtable.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hashtable.put(EncodeHintType.CHARACTER_SET, "utf-8");
            hashtable.put(EncodeHintType.MARGIN, 0);
            BitMatrix encode = new MultiFormatWriter().encode(str, BarcodeFormat.QR_CODE, i, i, hashtable);
            Rect rect2 = new Rect();
            int checkParam = checkParam(encode, rect2);
            int width = encode.getWidth();
            int height = encode.getHeight();
            Paint paint = new Paint();
            if (i10 != -1 && i11 == -1) {
                paint.setColor(i10);
            } else if (i11 != -1) {
                LinearGradient linearGradient = new LinearGradient(0.0f, 0.0f, 0.0f, (float) height, i3, i4, Shader.TileMode.MIRROR);
                paint.setShader(linearGradient);
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setAntiAlias(true);
            int i14 = checkParam / 2;
            int i15 = checkParam / 4;
            int i16 = rect2.left + i14;
            int i17 = rect2.top + i14;
            Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            double d = (double) i13;
            Double.isNaN(d);
            double d2 = 6.283185307179586d / d;
            Canvas canvas2 = new Canvas(createBitmap);
            int i18 = checkParam * 7;
            int i19 = i16;
            while (i19 <= rect2.right) {
                int i20 = i17;
                while (i20 <= rect2.bottom) {
                    if (encode.get(i19, i20)) {
                        if ((i19 > rect2.left + i18 || i20 > rect2.top + i18) && (i19 < rect2.right - i18 || i20 > rect2.top + i18)) {
                            if (i19 <= rect2.left + i18) {
                                if (i20 < rect2.bottom - i18) {
                                }
                            }
                            int i21 = i20;
                            bitMatrix = encode;
                            int i22 = i19;
                            Path path = new Path();
                            path.moveTo((float) i22, (float) (i21 - i14));
                            double d3 = (double) i22;
                            double cos = Math.cos(-0.7853981633974483d);
                            double d4 = (double) i15;
                            Double.isNaN(d4);
                            Double.isNaN(d3);
                            i5 = i22;
                            Rect rect3 = rect2;
                            float f = (float) ((int) (d3 + (cos * d4)));
                            i9 = checkParam;
                            double d5 = (double) i21;
                            double sin = Math.sin(-0.7853981633974483d);
                            Double.isNaN(d4);
                            Double.isNaN(d5);
                            rect = rect3;
                            i6 = i21;
                            path.lineTo(f, (float) ((int) (d5 + (sin * d4))));
                            int i23 = 1;
                            while (i23 < i13) {
                                int i24 = i13;
                                double d6 = (double) i23;
                                Double.isNaN(d6);
                                double d7 = d6 * d2;
                                double d8 = d7 - 1.5707963267948966d;
                                double cos2 = Math.cos(d8);
                                Bitmap bitmap2 = createBitmap;
                                Canvas canvas3 = canvas2;
                                double d9 = (double) i14;
                                Double.isNaN(d9);
                                Double.isNaN(d3);
                                int i25 = i24;
                                int i26 = i14;
                                float f2 = (float) ((int) (d3 + (cos2 * d9)));
                                double sin2 = Math.sin(d8);
                                Double.isNaN(d9);
                                Double.isNaN(d5);
                                path.lineTo(f2, (float) ((int) (d5 + (sin2 * d9))));
                                double d10 = d7 - 0.7853981633974483d;
                                double cos3 = Math.cos(d10);
                                Double.isNaN(d4);
                                Double.isNaN(d3);
                                float f3 = (float) ((int) ((cos3 * d4) + d3));
                                double sin3 = Math.sin(d10);
                                Double.isNaN(d4);
                                Double.isNaN(d5);
                                path.lineTo(f3, (float) ((int) ((sin3 * d4) + d5)));
                                i23++;
                                createBitmap = bitmap2;
                                canvas2 = canvas3;
                                i14 = i26;
                                i13 = i25;
                            }
                            i8 = i14;
                            i7 = i13;
                            bitmap = createBitmap;
                            path.close();
                            canvas = canvas2;
                            canvas.drawPath(path, paint);
                        }
                        bitMatrix = encode;
                        canvas2.drawRect((float) (i19 - i14), (float) (i20 - i14), (float) (i19 + i14), (float) (i20 + i14), paint);
                        i6 = i20;
                        i8 = i14;
                        i7 = i13;
                        i5 = i19;
                        rect = rect2;
                        i9 = checkParam;
                        bitmap = createBitmap;
                        canvas = canvas2;
                    } else {
                        i6 = i20;
                        i5 = i19;
                        i8 = i14;
                        i7 = i13;
                        bitMatrix = encode;
                        rect = rect2;
                        i9 = checkParam;
                        bitmap = createBitmap;
                        canvas = canvas2;
                    }
                    i20 = i6 + i9;
                    encode = bitMatrix;
                    rect2 = rect;
                    i19 = i5;
                    canvas2 = canvas;
                    checkParam = i9;
                    createBitmap = bitmap;
                    i14 = i8;
                    i13 = i7;
                }
                int i27 = i14;
                int i28 = i13;
                BitMatrix bitMatrix2 = encode;
                Rect rect4 = rect2;
                Bitmap bitmap3 = createBitmap;
                Canvas canvas4 = canvas2;
                i19 += checkParam;
            }
            return createBitmap;
        } catch (Exception unused) {
            return null;
        }
    }

    public static Bitmap CreateQRCodeSmooth(String str, int i, float f, int i2, int i3) {
        Canvas canvas;
        boolean z;
        Paint paint;
        boolean z2;
        int i4;
        boolean z3;
        Rect rect;
        BitMatrix bitMatrix;
        int i5;
        Canvas canvas2;
        Paint paint2;
        boolean z4;
        int i6;
        int i7 = i2;
        int i8 = i3;
        try {
            Hashtable hashtable = new Hashtable();
            hashtable.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hashtable.put(EncodeHintType.CHARACTER_SET, "utf-8");
            hashtable.put(EncodeHintType.MARGIN, 0);
            BitMatrix encode = new MultiFormatWriter().encode(str, BarcodeFormat.QR_CODE, i, i, hashtable);
            Rect rect2 = new Rect();
            int checkParam = checkParam(encode, rect2);
            int width = encode.getWidth();
            int height = encode.getHeight();
            Paint paint3 = new Paint();
            if (i7 != -1 && i8 == -1) {
                paint3.setColor(i7);
            } else if (i8 != -1) {
                LinearGradient linearGradient2 = new LinearGradient(0.0f, 0.0f, 0.0f, (float) height, i2, i3, Shader.TileMode.MIRROR);
                paint3.setShader(linearGradient2);
            }
            paint3.setStyle(Paint.Style.FILL);
            paint3.setAntiAlias(true);
            Paint paint4 = new Paint();
            paint4.setColor(-1);
            paint4.setStyle(Paint.Style.FILL);
            paint4.setAntiAlias(true);
            int i9 = checkParam / 2;
            int i10 = (int) (((float) i9) * f);
            int i11 = rect2.left + i9;
            int i12 = rect2.top + i9;
            Bitmap createBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas3 = new Canvas(createBitmap);
            while (i11 <= rect2.right) {
                int i13 = i12;
                while (i13 <= rect2.bottom) {
                    int i14 = i11 - i9;
                    int i15 = i13 - i9;
                    int i16 = i11 + i9;
                    int i17 = i13 + i9;
                    int i18 = i11 - checkParam;
                    int i19 = i9;
                    int i20 = i11 + checkParam;
                    int i21 = i12;
                    int i22 = i13 - checkParam;
                    Bitmap bitmap = createBitmap;
                    int i23 = i13 + checkParam;
                    int i24 = checkParam;
                    if (i18 >= rect2.left) {
                        z = encode.get(i18, i13);
                        canvas = canvas3;
                    } else {
                        canvas = canvas3;
                        z = false;
                    }
                    if (i22 >= rect2.top) {
                        z2 = encode.get(i11, i22);
                        paint = paint3;
                    } else {
                        paint = paint3;
                        z2 = false;
                    }
                    if (i20 <= rect2.right) {
                        z3 = encode.get(i20, i13);
                        i4 = i17;
                    } else {
                        i4 = i17;
                        z3 = false;
                    }
                    boolean z5 = i23 <= rect2.bottom ? encode.get(i11, i23) : false;
                    int i25 = i11;
                    if (encode.get(i11, i13)) {
                        boolean z6 = (i18 < rect2.left || i22 < rect2.top) ? false : encode.get(i18, i22);
                        boolean z7 = (i20 > rect2.right || i22 < rect2.top) ? false : encode.get(i20, i22);
                        boolean z8 = (i20 > rect2.right || i23 > rect2.bottom) ? false : encode.get(i20, i23);
                        boolean z9 = (i18 < rect2.left || i23 > rect2.bottom) ? false : encode.get(i18, i23);
                        Path path = new Path();
                        if (z6 || z2 || z) {
                            i5 = i23;
                            bitMatrix = encode;
                            rect = rect2;
                            z4 = z;
                            path.moveTo((float) i14, (float) i15);
                        } else {
                            float f2 = (float) i14;
                            i5 = i23;
                            path.moveTo(f2, (float) (i15 + i10));
                            bitMatrix = encode;
                            int i26 = i10 * 2;
                            rect = rect2;
                            z4 = z;
                            path.arcTo(new RectF(f2, (float) i15, (float) (i14 + i26), (float) (i15 + i26)), -180.0f, 90.0f, false);
                        }
                        if (z7 || z2 || z3) {
                            path.lineTo((float) i16, (float) i15);
                        } else {
                            float f3 = (float) i15;
                            path.lineTo((float) (i16 - i10), f3);
                            int i27 = i10 * 2;
                            path.arcTo(new RectF((float) (i16 - i27), f3, (float) i16, (float) (i15 + i27)), -90.0f, 90.0f, false);
                        }
                        if (z8 || z5 || z3) {
                            i6 = i4;
                            path.lineTo((float) i16, (float) i6);
                        } else {
                            float f4 = (float) i16;
                            path.lineTo(f4, (float) (i4 - i10));
                            int i28 = i10 * 2;
                            i6 = i4;
                            path.arcTo(new RectF((float) (i16 - i28), (float) (i4 - i28), f4, (float) i6), 0.0f, 90.0f, false);
                        }
                        if (z9 || z5 || z4) {
                            path.lineTo((float) i14, (float) i6);
                        } else {
                            float f5 = (float) i6;
                            path.lineTo((float) (i14 + i10), f5);
                            int i29 = i10 * 2;
                            path.arcTo(new RectF((float) i14, (float) (i6 - i29), (float) (i14 + i29), f5), 90.0f, 90.0f, false);
                        }
                        path.close();
                        canvas2 = canvas;
                        paint2 = paint;
                        canvas2.drawPath(path, paint2);
                    } else {
                        canvas2 = canvas;
                        int i30 = i4;
                        i5 = i23;
                        bitMatrix = encode;
                        rect = rect2;
                        boolean z10 = z;
                        paint2 = paint;
                        if (z2 && z10) {
                            Path path2 = new Path();
                            float f6 = (float) i14;
                            path2.moveTo(f6, (float) (i15 + i10));
                            float f7 = (float) i15;
                            path2.lineTo(f6, f7);
                            path2.lineTo((float) (i14 + i10), f7);
                            int i31 = i10 * 2;
                            path2.arcTo(new RectF(f6, f7, (float) (i14 + i31), (float) (i31 + i15)), -90.0f, -90.0f, false);
                            path2.close();
                            canvas2.drawPath(path2, paint2);
                        }
                        if (z2 && z3) {
                            Path path3 = new Path();
                            float f8 = (float) i15;
                            path3.moveTo((float) (i16 - i10), f8);
                            float f9 = (float) i16;
                            path3.lineTo(f9, f8);
                            path3.lineTo(f9, (float) (i15 + i10));
                            int i32 = i10 * 2;
                            path3.arcTo(new RectF((float) (i16 - i32), f8, f9, (float) (i15 + i32)), 0.0f, -90.0f, false);
                            path3.close();
                            canvas2.drawPath(path3, paint2);
                        }
                        if (z5 && z3) {
                            Path path4 = new Path();
                            float f10 = (float) i16;
                            path4.moveTo(f10, (float) (i30 - i10));
                            float f11 = (float) i30;
                            path4.lineTo(f10, f11);
                            path4.lineTo((float) (i16 - i10), f11);
                            int i33 = i10 * 2;
                            path4.arcTo(new RectF((float) (i16 - i33), (float) (i30 - i33), f10, f11), 90.0f, -90.0f, false);
                            path4.close();
                            canvas2.drawPath(path4, paint2);
                        }
                        if (z5 && z10) {
                            Path path5 = new Path();
                            float f12 = (float) i30;
                            path5.moveTo((float) (i14 + i10), f12);
                            float f13 = (float) i14;
                            path5.lineTo(f13, f12);
                            path5.lineTo(f13, (float) (i30 - i10));
                            int i34 = i10 * 2;
                            path5.arcTo(new RectF(f13, (float) (i30 - i34), (float) (i14 + i34), f12), 180.0f, -90.0f, false);
                            path5.close();
                            canvas2.drawPath(path5, paint2);
                        }
                    }
                    i12 = i21;
                    createBitmap = bitmap;
                    paint3 = paint2;
                    canvas3 = canvas2;
                    checkParam = i24;
                    i11 = i25;
                    i13 = i5;
                    encode = bitMatrix;
                    rect2 = rect;
                    i9 = i19;
                }
                int i35 = i9;
                Bitmap bitmap2 = createBitmap;
                BitMatrix bitMatrix2 = encode;
                Rect rect3 = rect2;
                Paint paint5 = paint3;
                canvas3 = canvas3;
                i11 += checkParam;
                i9 = i35;
                i12 = i12;
            }
            return createBitmap;
        } catch (Exception unused) {
            return null;
        }
    }

    public static Bitmap withIcon(Bitmap bitmap, Bitmap bitmap2, float f) {
        try {
            Canvas canvas = new Canvas(bitmap);
            int width = bitmap.getWidth();
            int height = bitmap.getHeight();
            int width2 = bitmap2.getWidth();
            int height2 = bitmap2.getHeight();
            Rect rect = new Rect();
            rect.left = 0;
            rect.top = 0;
            rect.right = width2;
            rect.bottom = height2;
            float f2 = (float) width;
            float f3 = f2 * f;
            float f4 = (float) height;
            float f5 = f * f4;
            RectF rectF = new RectF();
            rectF.left = (f2 - f3) / 2.0f;
            rectF.top = (f4 - f5) / 2.0f;
            rectF.right = rectF.left + f3;
            rectF.bottom = rectF.top + f5;
            canvas.drawBitmap(bitmap2, rect, rectF, new Paint());
        } catch (Exception unused) {
        }
        return bitmap;
    }
}
