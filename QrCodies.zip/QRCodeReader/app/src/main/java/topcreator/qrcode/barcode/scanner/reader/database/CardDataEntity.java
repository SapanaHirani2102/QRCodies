package topcreator.qrcode.barcode.scanner.reader.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "card_data")
public class CardDataEntity {
    private String bPathImg;
    @PrimaryKey(autoGenerate = true)
    private int cardId;
    private String cardName;
    private int cardNumber;
    private String cardType;
    private String fPathImg;
    private String sqlDate;
    private String time;

    public CardDataEntity(String str, String str2, String str3, int i, String str4, String str5, String str6) {
        this.cardName = str;
        this.time = str2;
        this.sqlDate = str3;
        this.cardNumber = i;
        this.fPathImg = str4;
        this.bPathImg = str5;
        this.cardType = str6;
    }

    public CardDataEntity() {
    }

    public String getCardType() {
        return this.cardType;
    }

    public void setCardType(String str) {
        this.cardType = str;
    }

    public int getCardId() {
        return this.cardId;
    }

    public void setCardId(int i) {
        this.cardId = i;
    }

    public String getCardName() {
        return this.cardName;
    }

    public void setCardName(String str) {
        this.cardName = str;
    }

    public String getTime() {
        return this.time;
    }

    public void setTime(String str) {
        this.time = str;
    }

    public String getSqlDate() {
        return this.sqlDate;
    }

    public void setSqlDate(String str) {
        this.sqlDate = str;
    }

    public int getCardNumber() {
        return this.cardNumber;
    }

    public void setCardNumber(int i) {
        this.cardNumber = i;
    }

    public String getFPathImg() {
        return this.fPathImg;
    }

    public void setFPathImg(String str) {
        this.fPathImg = str;
    }

    public String getBPathImg() {
        return this.bPathImg;
    }

    public void setBPathImg(String str) {
        this.bPathImg = str;
    }
}
