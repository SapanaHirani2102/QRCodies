package topcreator.qrcode.barcode.scanner.reader.barcodeutils.android.result;

import android.app.Activity;
import topcreator.qrcode.barcode.scanner.reader.R;
import com.google.zxing.client.result.EmailAddressParsedResult;
import com.google.zxing.client.result.ParsedResult;

public final class EmailAddressResultHandler extends ResultHandler {
    public int getButtonCount() {
        return 0;
    }

    public int getButtonText(int i) {
        return 0;
    }

    public int getDisplayTitle() {
        return R.string.result_email_address;
    }

    public EmailAddressResultHandler(Activity activity, ParsedResult parsedResult) {
        super(activity, parsedResult);
    }

    public void handleButtonPress(int i) {
        EmailAddressParsedResult emailAddressParsedResult = (EmailAddressParsedResult) getResult();
        switch (i) {
            case 0:
                sendEmail(emailAddressParsedResult.getTos(), emailAddressParsedResult.getCCs(), emailAddressParsedResult.getBCCs(), emailAddressParsedResult.getSubject(), emailAddressParsedResult.getBody());
                return;
            case 1:
                addEmailOnlyContact(emailAddressParsedResult.getTos(), null);
                return;
            default:
                return;
        }
    }
}
