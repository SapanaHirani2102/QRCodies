package topcreator.qrcode.barcode.scanner.reader.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {ScanDataEntity.class, ScanDataBookmarkEntity.class, GenerateDataEntity.class, GenerateBookmarkDataEntity.class, CardDataEntity.class, CardBookmarkDataEntity.class}, exportSchema = false, version = 7)
public abstract class ScanDatabase extends RoomDatabase {
    private static final Migration MIGRATION_2_7 = new Migration(2, 7) {
        public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
            try {
                supportSQLiteDatabase.execSQL("ALTER TABLE generate_data  ADD COLUMN generateImgPath TEXT");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    private static final Migration MIGRATION_3_7 = new Migration(3, 7) {
        public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
            try {
                supportSQLiteDatabase.execSQL("ALTER TABLE generate_data  ADD COLUMN generateImgPath TEXT");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    private static final Migration MIGRATION_4_7 = new Migration(4, 7) {
        public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
            try {
                supportSQLiteDatabase.execSQL("ALTER TABLE generate_data  ADD COLUMN generateImgPath TEXT");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    private static final Migration MIGRATION_5_7 = new Migration(5, 7) {
        public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
            try {
                supportSQLiteDatabase.execSQL("ALTER TABLE generate_data  ADD COLUMN generateImgPath TEXT");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    private static final Migration MIGRATION_6_7 = new Migration(6, 7) {
        public void migrate(SupportSQLiteDatabase supportSQLiteDatabase) {
            try {
                supportSQLiteDatabase.execSQL("ALTER TABLE generate_data  ADD COLUMN generateImgPath TEXT");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    private static ScanDatabase dataBase;

    public abstract ScanDataDao scanDataDao();

    public static ScanDatabase getInstance(Context context) {
        if (dataBase == null) {
            dataBase = buildDatabaseInstance(context);
        }
        return dataBase;
    }

    private static ScanDatabase buildDatabaseInstance(Context context) {
        return (ScanDatabase) Room.databaseBuilder(context, ScanDatabase.class, "scan_database").addMigrations(MIGRATION_6_7, MIGRATION_5_7, MIGRATION_4_7, MIGRATION_3_7, MIGRATION_2_7).allowMainThreadQueries().build();
    }
}
