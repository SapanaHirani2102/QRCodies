package topcreator.qrcode.barcode.scanner.reader.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import topcreator.qrcode.barcode.scanner.reader.R;
import topcreator.qrcode.barcode.scanner.reader.splashexit.BaseSplashActivity;
import topcreator.qrcode.barcode.scanner.reader.utils.Constants;
import topcreator.qrcode.barcode.scanner.reader.utils.TextValidator;
import com.google.android.gms.measurement.api.AppMeasurementSdk;

public class GenerateInfoActivity extends AppCompatActivity {
    private String cardType = Constants.CARD_TYPE;
    private boolean finalCheck = false;
    private Bundle globalBundle;
    private EditText mAddressETxt;
    private ImageView mBackGeneImg;
    private EditText mCompETxt;
    private EditText mEmailETxt;
    private EditText mEmailGenContentTxt;
    private EditText mEmailGenSubTxt;
    private EditText mEmailGenTxt;
    private EditText mFNameETxt;
    private EditText mGenePassTxt;
    private EditText mGeneUrlTxt;
    private TextView mGenerateBtn;
    private EditText mGeoGenLongTxt;
    private EditText mGeoLatTxt;
    private EditText mGeoNameTxt;
    private EditText mIsbnGenCodeTxt;
    private EditText mIsbnGenTxt;
    private EditText mIsbnPriceCodeTxt;
    private EditText mJobETxt;
    private EditText mLNameETxt;
    private EditText mMobileETxt;
    private EditText mPhoneETxt;
    private EditText mProGenCodeTxt;
    private EditText mProGenPriceTxt;
    private EditText mProGenTxt;
    private EditText mSmsGenContentTxt;
    private EditText mSmsGenNameTxt;
    private EditText mSmsGenTxt;
    private EditText mTelGenTxt;
    private EditText mTelNamneTxt;
    private EditText mTxtGenTxt;
    private EditText mUrlGenNameTxt;
    private EditText mWebETxt;
    private CheckBox mWifiGenCheck;
    private EditText mWifiGenNameTxt;
    private Spinner mWifiGenSpinner;
    private String type = "";

    public static void start(Context context, Bundle bundle) {
        Intent intent = new Intent(context, GenerateInfoActivity.class);
        intent.putExtra(Constants.GENERATE_INFO, bundle);
        context.startActivity(intent);
        BaseSplashActivity.showadd();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_generate_info);
        statusBarSet();
//        StatusBarColor.darkenStatusBar(this, R.color.colorAccent);
        initView();
        Bundle bundleExtra = getIntent().getBundleExtra(Constants.GENERATE_INFO);
        if (bundleExtra != null) {
            this.type = bundleExtra.getString(Constants.FILTER_TYPE);
            this.globalBundle = bundleExtra;
            setLayoutVisible(this.type);
        }

        this.mGenerateBtn.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                sendGenerateData(type);
            }
        });
        this.mBackGeneImg.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                finish();
            }
        });

    }

    private void statusBarSet() {
        if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
            setWindowFlag(this, 67108864, true);
        }
        if (Build.VERSION.SDK_INT >= 19) {
            getWindow().getDecorView().setSystemUiVisibility(1280);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            setWindowFlag(this, 67108864, false);
            getWindow().setStatusBarColor(getResources().getColor(R.color.status_bar_color));
        }
    }

    public static void setWindowFlag(Activity activity, int i, boolean z) {
        Window window = activity.getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        if (z) {
            attributes.flags = i | attributes.flags;
        } else {
            attributes.flags = (i ^ -1) & attributes.flags;
        }
        window.setAttributes(attributes);
    }

    private void checkValidation(EditText editText, final String str, String str2) {
        editText.setOnFocusChangeListener(new TextValidator(editText) {
            public void validate(EditText editText, String str, boolean z) {
                if (str.equals(str) && !z) {
                    editText.setError("Invalid URL");
                }
            }
        });
    }

    private boolean isValidUrl(String str) {
        return Patterns.WEB_URL.matcher(str.toLowerCase()).matches();
    }

    private boolean isValidEmail(String str) {
        return Patterns.EMAIL_ADDRESS.matcher(str.toLowerCase()).matches();
    }

    private void initView() {
        this.mGenerateBtn = (TextView) findViewById(R.id.generate_btn);
        this.mGeneUrlTxt = (EditText) findViewById(R.id.gene_url_txt);
        this.mUrlGenNameTxt = (EditText) findViewById(R.id.url_gen_name_txt);
        this.mTelGenTxt = (EditText) findViewById(R.id.tel_gen_txt);
        this.mTxtGenTxt = (EditText) findViewById(R.id.txt_gen_txt);
        this.mWifiGenNameTxt = (EditText) findViewById(R.id.wifi_gen_name_txt);
        this.mGeoLatTxt = (EditText) findViewById(R.id.geo_lat_txt);
        this.mGeoGenLongTxt = (EditText) findViewById(R.id.geo_gen_long_txt);
        this.mGeoNameTxt = (EditText) findViewById(R.id.geo_name_txt);
        this.mIsbnGenCodeTxt = (EditText) findViewById(R.id.isbn_gen_code_txt);
        this.mProGenTxt = (EditText) findViewById(R.id.pro_gen_txt);
        this.mGenePassTxt = (EditText) findViewById(R.id.gene_pass_txt);
        this.mIsbnGenTxt = (EditText) findViewById(R.id.isbn_gen_txt);
        this.mEmailGenContentTxt = (EditText) findViewById(R.id.email_gen_content_txt);
        this.mSmsGenTxt = (EditText) findViewById(R.id.sms_gen_txt);
        this.mSmsGenContentTxt = (EditText) findViewById(R.id.sms_gen_content_txt);
        this.mEmailGenTxt = (EditText) findViewById(R.id.email_gen_txt);
        this.mProGenCodeTxt = (EditText) findViewById(R.id.pro_gen_code_txt);
        this.mEmailGenSubTxt = (EditText) findViewById(R.id.email_gen_sub_txt);
        this.mWifiGenSpinner = (Spinner) findViewById(R.id.wifi_gen_spinner);
        this.mWifiGenCheck = (CheckBox) findViewById(R.id.wifi_gen_check);
        this.mFNameETxt = (EditText) findViewById(R.id.fName_eTxt);
        this.mWebETxt = (EditText) findViewById(R.id.web_eTxt);
        this.mLNameETxt = (EditText) findViewById(R.id.lName_eTxt);
        this.mCompETxt = (EditText) findViewById(R.id.comp_eTxt);
        this.mMobileETxt = (EditText) findViewById(R.id.mobile_eTxt);
        this.mJobETxt = (EditText) findViewById(R.id.job_eTxt);
        this.mEmailETxt = (EditText) findViewById(R.id.email_eTxt);
        this.mPhoneETxt = (EditText) findViewById(R.id.phone_eTxt);
        this.mAddressETxt = (EditText) findViewById(R.id.address_eTxt);
        this.mIsbnPriceCodeTxt = (EditText) findViewById(R.id.isbn_price_code_txt);
        this.mProGenPriceTxt = (EditText) findViewById(R.id.pro_gen_price_txt);
        this.mSmsGenNameTxt = (EditText) findViewById(R.id.sms_gen_name_txt);
        this.mTelNamneTxt = (EditText) findViewById(R.id.tel_namne_txt);
        this.mBackGeneImg = (ImageView) findViewById(R.id.back_gene_img);
    }

    /* access modifiers changed from: private */
    public void sendGenerateData(String str) {
        double d;
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            String trim = this.mFNameETxt.getText().toString().trim();
            String trim2 = this.mLNameETxt.getText().toString().trim();
            String trim3 = this.mWebETxt.getText().toString().trim();
            String trim4 = this.mCompETxt.getText().toString().trim();
            String trim5 = this.mMobileETxt.getText().toString().trim();
            String trim6 = this.mJobETxt.getText().toString().trim();
            String trim7 = this.mEmailETxt.getText().toString().trim();
            String trim8 = this.mPhoneETxt.getText().toString().trim();
            String trim9 = this.mAddressETxt.getText().toString().trim();
            Bundle bundle = new Bundle();
            if (trim.equals("") || trim2.equals("") || trim3.equals("") || trim4.equals("") || trim5.equals("") || trim6.equals("") || trim7.equals("") || trim8.equals("") || trim9.equals("")) {
                Toast makeText = Toast.makeText(getApplicationContext(), "Please fill the required filed!", Toast.LENGTH_SHORT);
                makeText.setGravity(17, 0, 0);
                makeText.show();
            } else if (!isValidUrl(trim3)) {
                this.mWebETxt.setError("Enter valid URL");
            } else if (!isValidEmail(trim7)) {
                this.mEmailETxt.setError("Enter valid Email");
            } else {
                String str2 = "BEGIN:VCARD\nVERSION:3.0\nN:" + trim2 + ";" + trim + "\nFN:" + trim + " " + trim2 + "\nORG:" + trim4 + "\nTITLE:" + trim6 + "\nADR:;;" + trim9 + "\nTEL;WORK;VOICE:" + trim8 + "\nTEL;CELL:" + trim5 + "\nEMAIL;WORK;INTERNET:" + trim7 + "\nURL:" + trim3 + "\nEND:VCARD";
                String string = this.globalBundle.getString(Constants.GENERATE_TYPE);
                if (string == null) {
                    bundle.putString(Constants.FILTER_TYPE, str);
                    bundle.putString(Constants.GENERATE_URL_NAME, str2);
                    AdvanceQrActivity.start(this, bundle);
                } else if (string.equals(Constants.CARD_TYPE)) {
                    bundle.putString(AppMeasurementSdk.ConditionalUserProperty.NAME, trim + " " + trim2);
                    bundle.putString("company", trim4);
                    bundle.putString("mobile", trim5);
                    bundle.putString("phone", trim8);
                    bundle.putString("job", trim6);
                    bundle.putString("web", trim3);
                    bundle.putString("email", trim7);
                    bundle.putString("address", trim9);
                    bundle.putString(Constants.GENERATE_URL_NAME, str2);
                    String string2 = this.globalBundle.getString(Constants.CARD_TYPE);
                    bundle.putInt("position", this.globalBundle.getInt(Constants.CARD_POSITION));
                    bundle.putString(Constants.CARD_TYPE, string2);
                    bundle.putString(Constants.GENERATE_TYPE, Constants.CARD_TYPE);
                    AdvanceQrActivity.start(this, bundle);
                }
            }
        } else if (!Constants.TYPE_CALENDAR.equals(str)) {
            if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
                Bundle bundle2 = new Bundle();
                String trim10 = this.mEmailGenTxt.getText().toString().trim();
                String trim11 = this.mEmailGenContentTxt.getText().toString().trim();
                String trim12 = this.mEmailGenSubTxt.getText().toString().trim();
                if (trim11.equals("") || trim10.equals("") || trim12.equals("")) {
                    Toast makeText2 = Toast.makeText(getApplicationContext(), "Please fill the required filed!", Toast.LENGTH_SHORT);
                    makeText2.setGravity(17, 0, 0);
                    makeText2.show();
                } else if (!isValidEmail(trim10)) {
                    this.mEmailGenTxt.setError("Enter valid email");
                } else {
                    String string3 = this.globalBundle.getString(Constants.GENERATE_TYPE);
                    if (string3 == null) {
                        bundle2.putString(Constants.FILTER_TYPE, str);
                        bundle2.putString(Constants.GENERATE_URL_NAME, this.mEmailGenTxt.getText().toString().trim());
                        bundle2.putString(Constants.GENERATE_URL_LINK, this.mEmailGenContentTxt.getText().toString().trim());
                        bundle2.putString(Constants.GENERATE_EMAIL_LINK, this.mEmailGenSubTxt.getText().toString().trim());
                        AdvanceQrActivity.start(this, bundle2);
                    } else if (string3.equals(Constants.CARD_TYPE)) {
                        bundle2.putString(AppMeasurementSdk.ConditionalUserProperty.NAME, this.mEmailGenTxt.getText().toString().trim());
                        bundle2.putString("company", this.mEmailGenSubTxt.getText().toString().trim());
                        bundle2.putString("web", this.mEmailGenContentTxt.getText().toString().trim());
                        bundle2.putString(Constants.GENERATE_URL_NAME, this.mEmailGenTxt.getText().toString().trim());
                        String string4 = this.globalBundle.getString(Constants.CARD_TYPE);
                        bundle2.putInt("position", this.globalBundle.getInt(Constants.CARD_POSITION));
                        bundle2.putString(Constants.CARD_TYPE, string4);
                        bundle2.putString(Constants.GENERATE_TYPE, Constants.CARD_TYPE);
                        AdvanceQrActivity.start(this, bundle2);
                    }
                }
            } else if (Constants.TYPE_GEO.equals(str)) {
                Bundle bundle3 = new Bundle();
                String trim13 = this.mGeoLatTxt.getText().toString().trim();
                String trim14 = this.mGeoGenLongTxt.getText().toString().trim();
                String trim15 = this.mGeoNameTxt.getText().toString().trim();
                boolean equals = trim14.equals("");
                double d2 = 0.0d;
                if (equals || trim13.equals("")) {
                    d = 0.0d;
                } else {
                    d2 = Double.parseDouble(trim13);
                    d = Double.parseDouble(trim14);
                }
                if (trim14.equals("") || trim13.equals("") || trim15.equals("")) {
                    Toast makeText3 = Toast.makeText(getApplicationContext(), "Please fill the required filed!", Toast.LENGTH_SHORT);
                    makeText3.setGravity(17, 0, 0);
                    makeText3.show();
                } else if (d2 > 99.0d || d2 < -99.0d) {
                    this.mGeoLatTxt.setError("Value must be under -99 to 99");
                } else if (d > 180.0d || d < -180.0d) {
                    this.mGeoGenLongTxt.setError("Value must be under -180 to 180");
                } else {
                    String string5 = this.globalBundle.getString(Constants.GENERATE_TYPE);
                    if (string5 == null) {
                        bundle3.putString(Constants.FILTER_TYPE, str);
                        bundle3.putString(Constants.GENERATE_URL_NAME, this.mGeoLatTxt.getText().toString().trim());
                        bundle3.putString(Constants.GENERATE_URL_LINK, this.mGeoGenLongTxt.getText().toString().trim());
                        AdvanceQrActivity.start(this, bundle3);
                    } else if (string5.equals(Constants.CARD_TYPE)) {
                        bundle3.putString(AppMeasurementSdk.ConditionalUserProperty.NAME, "Latitude : " + this.mGeoLatTxt.getText().toString().trim());
                        bundle3.putString("company", "Longitude : " + this.mGeoGenLongTxt.getText().toString().trim());
                        bundle3.putString("web", trim15);
                        bundle3.putString(Constants.GENERATE_URL_NAME, this.mEmailGenTxt.getText().toString().trim());
                        String string6 = this.globalBundle.getString(Constants.CARD_TYPE);
                        bundle3.putInt("position", this.globalBundle.getInt(Constants.CARD_POSITION));
                        bundle3.putString(Constants.CARD_TYPE, string6);
                        bundle3.putString(Constants.GENERATE_TYPE, Constants.CARD_TYPE);
                        AdvanceQrActivity.start(this, bundle3);
                    }
                }
            } else if ("ISBN".equals(str)) {
                Bundle bundle4 = new Bundle();
                if (this.mIsbnGenTxt.getText().toString().trim().equals("") || this.mIsbnGenCodeTxt.getText().toString().trim().equals("")) {
                    Toast makeText4 = Toast.makeText(getApplicationContext(), "Please fill the required filed!", Toast.LENGTH_SHORT);
                    makeText4.setGravity(17, 0, 0);
                    makeText4.show();
                } else if (this.mIsbnGenCodeTxt.getText().toString().length() < 12) {
                    this.mIsbnGenCodeTxt.setError("Product code should be 12 digits long, but got ");
                } else {
                    String string7 = this.globalBundle.getString(Constants.GENERATE_TYPE);
                    if (string7 == null) {
                        bundle4.putString(Constants.FILTER_TYPE, str);
                        bundle4.putString(Constants.GENERATE_URL_NAME, this.mIsbnGenTxt.getText().toString().trim());
                        bundle4.putString(Constants.GENERATE_URL_LINK, this.mIsbnGenCodeTxt.getText().toString().trim());
                        GenerateResultActivity.start(this, bundle4);
                    } else if (string7.equals(Constants.CARD_TYPE)) {
                        bundle4.putString(AppMeasurementSdk.ConditionalUserProperty.NAME, this.mIsbnGenTxt.getText().toString().trim());
                        bundle4.putString("company", this.mIsbnGenCodeTxt.getText().toString().trim());
                        bundle4.putString("web", "Price : " + this.mIsbnPriceCodeTxt.getText().toString().trim());
                        String string8 = this.globalBundle.getString(Constants.CARD_TYPE);
                        bundle4.putInt("position", this.globalBundle.getInt(Constants.CARD_POSITION));
                        bundle4.putString(Constants.CARD_TYPE, string8);
                        GenerateCardResultActivity.start(this, bundle4);
                    }
                }
            } else if (Constants.TYPE_PRODUCT.equals(str)) {
                Bundle bundle5 = new Bundle();
                if (this.mProGenTxt.getText().toString().trim().equals("") || this.mProGenCodeTxt.getText().toString().trim().equals("")) {
                    Toast makeText5 = Toast.makeText(getApplicationContext(), "Please fill the required filed!", Toast.LENGTH_SHORT);
                    makeText5.setGravity(17, 0, 0);
                    makeText5.show();
                } else if (this.mProGenCodeTxt.getText().toString().length() < 12) {
                    this.mProGenCodeTxt.setError("Product code should be 12 digits long, but got ");
                } else {
                    String string9 = this.globalBundle.getString(Constants.GENERATE_TYPE);
                    if (string9 == null) {
                        bundle5.putString(Constants.FILTER_TYPE, str);
                        bundle5.putString(Constants.GENERATE_URL_NAME, this.mProGenTxt.getText().toString().trim());
                        bundle5.putString(Constants.GENERATE_URL_LINK, this.mProGenCodeTxt.getText().toString().trim());
                        GenerateResultActivity.start(this, bundle5);
                    } else if (string9.equals(Constants.CARD_TYPE)) {
                        bundle5.putString(AppMeasurementSdk.ConditionalUserProperty.NAME, this.mProGenTxt.getText().toString().trim());
                        bundle5.putString("company", this.mProGenCodeTxt.getText().toString().trim());
                        bundle5.putString("web", "Price : " + this.mProGenPriceTxt.getText().toString().trim());
                        String string10 = this.globalBundle.getString(Constants.CARD_TYPE);
                        bundle5.putInt("position", this.globalBundle.getInt(Constants.CARD_POSITION));
                        bundle5.putString(Constants.CARD_TYPE, string10);
                        GenerateCardResultActivity.start(this, bundle5);
                    }
                }
            } else if (Constants.TYPE_SMS.equals(str)) {
                Bundle bundle6 = new Bundle();
                String trim16 = this.mSmsGenTxt.getText().toString().trim();
                if (this.mSmsGenContentTxt.getText().toString().trim().equals("") || trim16.equals("")) {
                    Toast makeText6 = Toast.makeText(getApplicationContext(), "Please fill the required filed!", Toast.LENGTH_SHORT);
                    makeText6.setGravity(17, 0, 0);
                    makeText6.show();
                    return;
                }
                String string11 = this.globalBundle.getString(Constants.GENERATE_TYPE);
                if (string11 == null) {
                    bundle6.putString(Constants.FILTER_TYPE, str);
                    bundle6.putString(Constants.GENERATE_URL_NAME, this.mSmsGenTxt.getText().toString());
                    bundle6.putString(Constants.GENERATE_URL_LINK, this.mSmsGenContentTxt.getText().toString());
                    AdvanceQrActivity.start(this, bundle6);
                } else if (string11.equals(Constants.CARD_TYPE)) {
                    bundle6.putString(AppMeasurementSdk.ConditionalUserProperty.NAME, this.mSmsGenTxt.getText().toString().trim());
                    bundle6.putString("company", this.mSmsGenContentTxt.getText().toString().trim());
                    bundle6.putString("web", this.mSmsGenNameTxt.getText().toString().trim());
                    String string12 = this.globalBundle.getString(Constants.CARD_TYPE);
                    bundle6.putInt("position", this.globalBundle.getInt(Constants.CARD_POSITION));
                    bundle6.putString(Constants.CARD_TYPE, string12);
                    bundle6.putString(Constants.GENERATE_TYPE, Constants.CARD_TYPE);
                    AdvanceQrActivity.start(this, bundle6);
                }
            } else if (Constants.TYPE_TEL.equals(str)) {
                Bundle bundle7 = new Bundle();
                if (this.mTelGenTxt.getText().toString().trim().equals("")) {
                    Toast makeText7 = Toast.makeText(getApplicationContext(), "Please fill the required filed!", Toast.LENGTH_SHORT);
                    makeText7.setGravity(17, 0, 0);
                    makeText7.show();
                    return;
                }
                String string13 = this.globalBundle.getString(Constants.GENERATE_TYPE);
                if (string13 == null) {
                    bundle7.putString(Constants.FILTER_TYPE, str);
                    bundle7.putString(Constants.GENERATE_URL_NAME, this.mTelGenTxt.getText().toString().trim());
                    bundle7.putString(Constants.GENERATE_URL_LINK, this.mTelNamneTxt.getText().toString().trim());
                    AdvanceQrActivity.start(this, bundle7);
                } else if (string13.equals(Constants.CARD_TYPE)) {
                    bundle7.putString(AppMeasurementSdk.ConditionalUserProperty.NAME, this.mTelGenTxt.getText().toString().trim());
                    bundle7.putString("company", this.mTelNamneTxt.getText().toString().trim());
                    String string14 = this.globalBundle.getString(Constants.CARD_TYPE);
                    bundle7.putInt("position", this.globalBundle.getInt(Constants.CARD_POSITION));
                    bundle7.putString(Constants.CARD_TYPE, string14);
                    bundle7.putString(Constants.GENERATE_TYPE, Constants.CARD_TYPE);
                    AdvanceQrActivity.start(this, bundle7);
                }
            } else if (Constants.TYPE_TEXT.equals(str)) {
                String trim17 = this.mTxtGenTxt.getText().toString().trim();
                Bundle bundle8 = new Bundle();
                if (trim17.equals("")) {
                    Toast makeText8 = Toast.makeText(getApplicationContext(), "Please fill the required filed!", Toast.LENGTH_SHORT);
                    makeText8.setGravity(17, 0, 0);
                    makeText8.show();
                    return;
                }
                String string15 = this.globalBundle.getString(Constants.GENERATE_TYPE);
                if (string15 == null) {
                    bundle8.putString(Constants.FILTER_TYPE, str);
                    bundle8.putString(Constants.GENERATE_URL_NAME, this.mTxtGenTxt.getText().toString());
                    bundle8.putString(Constants.GENERATE_URL_LINK, this.mTxtGenTxt.getText().toString());
                    AdvanceQrActivity.start(this, bundle8);
                } else if (string15.equals(Constants.CARD_TYPE)) {
                    bundle8.putString(AppMeasurementSdk.ConditionalUserProperty.NAME, this.mTxtGenTxt.getText().toString().trim());
                    String string16 = this.globalBundle.getString(Constants.CARD_TYPE);
                    bundle8.putInt("position", this.globalBundle.getInt(Constants.CARD_POSITION));
                    bundle8.putString(Constants.CARD_TYPE, string16);
                    bundle8.putString(Constants.GENERATE_TYPE, Constants.CARD_TYPE);
                    AdvanceQrActivity.start(this, bundle8);
                }
            } else if (Constants.TYPE_URI.equals(str)) {
                Bundle bundle9 = new Bundle();
                String trim18 = this.mUrlGenNameTxt.getText().toString().trim();
                String trim19 = this.mGeneUrlTxt.getText().toString().trim();
                if (trim19.equals("") || trim18.equals("")) {
                    Toast makeText9 = Toast.makeText(getApplicationContext(), "Please fill the required filed!", Toast.LENGTH_SHORT);
                    makeText9.setGravity(17, 0, 0);
                    makeText9.show();
                } else if (!isValidUrl(trim19)) {
                    this.mGeneUrlTxt.setError("Enter valid url");
                } else {
                    String string17 = this.globalBundle.getString(Constants.GENERATE_TYPE);
                    if (string17 == null) {
                        bundle9.putString(Constants.FILTER_TYPE, str);
                        bundle9.putString(Constants.GENERATE_URL_NAME, this.mUrlGenNameTxt.getText().toString().trim());
                        bundle9.putString(Constants.GENERATE_URL_LINK, this.mGeneUrlTxt.getText().toString().trim());
                        AdvanceQrActivity.start(this, bundle9);
                    } else if (string17.equals(Constants.CARD_TYPE)) {
                        bundle9.putString(AppMeasurementSdk.ConditionalUserProperty.NAME, this.mUrlGenNameTxt.getText().toString().trim());
                        bundle9.putString("company", this.mGeneUrlTxt.getText().toString().trim());
                        String string18 = this.globalBundle.getString(Constants.CARD_TYPE);
                        bundle9.putInt("position", this.globalBundle.getInt(Constants.CARD_POSITION));
                        bundle9.putString(Constants.CARD_TYPE, string18);
                        bundle9.putString(Constants.GENERATE_TYPE, Constants.CARD_TYPE);
                        AdvanceQrActivity.start(this, bundle9);
                    }
                }
            } else if (Constants.TYPE_WIFI.equals(str)) {
                Bundle bundle10 = new Bundle();
                String trim20 = this.mWifiGenNameTxt.getText().toString().trim();
                if (this.mGenePassTxt.getText().toString().trim().equals("") || trim20.equals("")) {
                    Toast makeText10 = Toast.makeText(getApplicationContext(), "Please fill the required filed!", Toast.LENGTH_SHORT);
                    makeText10.setGravity(17, 0, 0);
                    makeText10.show();
                    return;
                }
                String string19 = this.globalBundle.getString(Constants.GENERATE_TYPE);
                if (string19 == null) {
                    bundle10.putString(Constants.FILTER_TYPE, str);
                    bundle10.putString(Constants.GENERATE_URL_NAME, this.mWifiGenNameTxt.getText().toString().trim());
                    bundle10.putString(Constants.GENERATE_URL_LINK, this.mGenePassTxt.getText().toString().trim());
                    bundle10.putString(Constants.GENERATE_WIFI_NET, this.mWifiGenSpinner.getSelectedItem().toString().trim());
                    bundle10.putString(Constants.GENERATE_WIFI_HIDE, String.valueOf(this.mWifiGenCheck.isChecked()));
                    AdvanceQrActivity.start(this, bundle10);
                } else if (string19.equals(Constants.CARD_TYPE)) {
                    bundle10.putString(AppMeasurementSdk.ConditionalUserProperty.NAME, "SSID : " + this.mWifiGenNameTxt.getText().toString().trim());
                    bundle10.putString("company", this.mGenePassTxt.getText().toString().trim());
                    bundle10.putString("mobile", "TYPE : " + this.mWifiGenSpinner.getSelectedItem().toString().trim());
                    bundle10.putString("phone", String.valueOf(this.mWifiGenCheck.isChecked()));
                    String string20 = this.globalBundle.getString(Constants.CARD_TYPE);
                    bundle10.putInt("position", this.globalBundle.getInt(Constants.CARD_POSITION));
                    bundle10.putString(Constants.CARD_TYPE, string20);
                    bundle10.putString(Constants.GENERATE_TYPE, Constants.CARD_TYPE);
                    AdvanceQrActivity.start(this, bundle10);
                }
            }
        }
    }

    private void setLayoutVisible(String str) {
        if (Constants.TYPE_ADDRESSBOOK.equals(str)) {
            findViewById(R.id.gen_card_info).setVisibility(View.VISIBLE);
        } else if (Constants.TYPE_CALENDAR.equals(str)) {
            findViewById(R.id.calender_layout).setVisibility(View.VISIBLE);
        } else if (Constants.TYPE_EMAIL_ADDRESS.equals(str)) {
            findViewById(R.id.gen_email_layout).setVisibility(View.VISIBLE);
        } else if (Constants.TYPE_GEO.equals(str)) {
            findViewById(R.id.gen_geo_layout).setVisibility(View.VISIBLE);
        } else if (Constants.TYPE_ISBN.equals(str)) {
            findViewById(R.id.gen_isbn_layout).setVisibility(View.VISIBLE);
        } else if (Constants.TYPE_PRODUCT.equals(str)) {
            findViewById(R.id.gen_pro_layout).setVisibility(View.VISIBLE);
        } else if (Constants.TYPE_SMS.equals(str)) {
            findViewById(R.id.gen_sms_layout).setVisibility(View.VISIBLE);
        } else if (Constants.TYPE_TEL.equals(str)) {
            findViewById(R.id.gen_tel_layout).setVisibility(View.VISIBLE);
        } else if (Constants.TYPE_TEXT.equals(str)) {
            findViewById(R.id.gen_text_layout).setVisibility(View.VISIBLE);
        } else if (Constants.TYPE_URI.equals(str)) {
            findViewById(R.id.gen_url_layout).setVisibility(View.VISIBLE);
        } else if (Constants.TYPE_WIFI.equals(str)) {
            findViewById(R.id.gen_wifi_layout).setVisibility(View.VISIBLE);
            this.mWifiGenSpinner.setAdapter(new ArrayAdapter(this, 17367049, new String[]{"WEP", "WPA/WPA2", "non"}));
        }
    }

}
